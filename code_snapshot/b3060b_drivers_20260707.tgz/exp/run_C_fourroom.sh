#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp; OUT=$EXP/C_hier_new; LOGS=$OUT/logs_fourroom; mkdir -p $LOGS $OUT/runs_fourroom
VENV=/root/tdmpc_glass/venv; [ -d /root/tdmpc_glass/.venv ] && VENV=/root/tdmpc_glass/.venv
STEPS=${STEPS:-400000}
run(){ local g=$1 arm=$2 seed=$3
  setsid bash -c "cd $EXP && source $VENV/bin/activate && CUDA_VISIBLE_DEVICES=$g XLA_PYTHON_CLIENT_MEM_FRACTION=0.25 python feudal_maze.py --arm $arm --maze fourroom --seed $seed --steps $STEPS --out_dir $OUT/runs_fourroom >> $LOGS/${arm}_s${seed}.log 2>&1" </dev/null & }
echo "[fourroom] start $(date)" > $LOGS/driver.log
# GPU2=flat, GPU3=feudal; seeds 0,1,2 sequential per gpu
for s in 0 1 2; do
  run 2 flat $s; run 3 feudal $s
  wait
done
echo "FOURROOM_DONE $(date)" >> $LOGS/driver.log
