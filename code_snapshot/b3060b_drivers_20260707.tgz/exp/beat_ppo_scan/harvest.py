#!/usr/bin/env python3
# Harvest beat_ppo_scan results from disk. Run on the box that holds the artifacts.
import os, re, glob, json, sys
mode = sys.argv[1] if len(sys.argv)>1 else "both"
def nearest(curve, target):
    # curve: list of (step,val). return (step,val) with step closest to target (<= preferred within 20%)
    if not curve: return None
    best=min(curve, key=lambda p: abs(p[0]-target))
    return best
def harvest_ppo():
    LOGS="/root/tdmpc_glass/exp/beat_ppo_scan/ppo_logs"
    out={}
    for lg in sorted(glob.glob(f"{LOGS}/*_seed*.log")):
        name=os.path.basename(lg)[:-4]
        curve=[]
        for line in open(lg,errors="ignore"):
            m=re.match(r"^\s*(\d+):\s*reward=([-\d.]+)", line)
            if m: curve.append((int(m.group(1)), float(m.group(2))))
        if not curve: 
            out[name]={"status":"no-evals-yet"}; continue
        last=curve[-1]
        ceil=max(curve, key=lambda p:p[1])
        row={"n_evals":len(curve),"last_step":last[0],"last_reward":last[1],
             "ceiling_reward":ceil[1],"ceiling_step":ceil[0],
             "at_2M":nearest(curve,2_000_000),"at_3M":nearest(curve,3_000_000),
             "at_5M":nearest(curve,5_000_000)}
        out[name]=row
    return out
def harvest_tdmpc():
    BASE="/root/helios-rl/exp/tdmpc_glass"
    out={}
    for d in sorted(glob.glob(f"{BASE}/*_beatppo")):
        env=os.path.basename(d).replace("_beatppo","")
        for csv in sorted(glob.glob(f"{d}/seed_*.csv")):
            seed=os.path.basename(csv).replace("seed_","").replace(".csv","")
            rows=[]
            with open(csv,errors="ignore") as f:
                hdr=f.readline().strip().split(",")
                for line in f:
                    p=line.strip().split(",")
                    if len(p)<4: continue
                    try: step=int(float(p[0])); rew=float(p[1]); et=p[2]
                    except: continue
                    rows.append((step,rew,et))
            # prefer mppi eval_type; else all
            ets=set(r[2] for r in rows)
            use=[r for r in rows if r[2]=="mppi"] or rows
            if not use:
                out[f"{env}_seed{seed}"]={"status":"no-rows-yet","eval_types":list(ets)}; continue
            last=use[-1]; ceil=max(use,key=lambda r:r[1])
            out[f"{env}_seed{seed}"]={"eval_types":list(ets),"n":len(use),
                "last_step":last[0],"last_reward":round(last[1],3),
                "ceiling_reward":round(ceil[1],3),"ceiling_step":ceil[0],
                "at_2M":nearest([(r[0],round(r[1],3)) for r in use],2_000_000),
                "at_3M":nearest([(r[0],round(r[1],3)) for r in use],3_000_000)}
    return out
res={}
if mode in ("ppo","both"):
    try: res["PPO"]=harvest_ppo()
    except Exception as e: res["PPO"]={"err":str(e)}
if mode in ("tdmpc","both"):
    try: res["TDMPC2"]=harvest_tdmpc()
    except Exception as e: res["TDMPC2"]={"err":str(e)}
print(json.dumps(res,indent=2))
