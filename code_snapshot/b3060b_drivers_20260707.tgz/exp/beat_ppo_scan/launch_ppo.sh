#!/usr/bin/env bash
# Vanilla PPO (brax) matched-budget + full-budget ceiling runs. One GPU per env, seeds 1 then 2.
set -u
BASE=/root/tdmpc_glass/exp/beat_ppo_scan
LOGS=$BASE/ppo_logs
mkdir -p "$LOGS"
PY=/root/tdmpc_glass/venv/bin/python
RUN=/root/tdmpc_glass/exp/tdmpc_glass/baselines_ppo_sac/run_ppo.py
# env:eplen:num_timesteps:num_envs:num_eval_envs:gpu
JOBS=(
  "PandaPickCubeOrientation:150:20000000:2048:512:0"
  "LeapCubeRotateZAxis:500:100000000:4096:512:1"
  "LeapCubeReorient:1000:200000000:4096:512:2"
  "PandaRobotiqPushCube:3000:300000000:4096:512:3"
)
worker() {
  local env=$1 eplen=$2 nt=$3 nenv=$4 neval=$5 gpu=$6
  for seed in 1 2; do
    local ld=$LOGS/${env}_seed${seed}
    local lg=$LOGS/${env}_seed${seed}.log
    CUDA_VISIBLE_DEVICES=$gpu MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.85 \
      "$PY" "$RUN" --env_name "$env" --impl jax --episode_length "$eplen" \
      --num_timesteps "$nt" --num_evals 60 --num_envs "$nenv" --num_eval_envs "$neval" \
      --seed "$seed" --logdir "$ld" > "$lg" 2>&1
  done
}
for j in "${JOBS[@]}"; do
  IFS=':' read -r env eplen nt nenv neval gpu <<< "$j"
  worker "$env" "$eplen" "$nt" "$nenv" "$neval" "$gpu" &
  sleep 90   # stagger JAX compiles so GPUs don't double-book during warmup
done
wait
