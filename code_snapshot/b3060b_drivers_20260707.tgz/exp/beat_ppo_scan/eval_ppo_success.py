"""Real-success eval for VANILLA brax PPO ckpts from the beat_ppo_scan.
Loads LATEST checkpoint per run, rolls out deterministically at native episode
length, reads the ENV's native success metric. All numbers from real rollouts.

Panda envs: success = (max metrics["box_target"] >= 0.9) per episode (same field
  & threshold the TD-MPC2 harness used); also report reached_box.
LeapCubeReorient: native success_count (# reorientations). Report fraction of
  episodes with success_count>=1 AND mean success_count (cubes/episode).
"""
import os, sys, json, argparse, time, glob
sys.path.insert(0, "/root/tdmpc_glass/exp/tdmpc_glass/baselines_ppo_sac")
import jax_compat  # noqa
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ["XLA_PYTHON_CLIENT_PREALLOCATE"] = "false"
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.25")
import numpy as np
import jax, jax.numpy as jp
from mujoco_playground import registry, wrapper
from brax.training.agents.ppo import checkpoint as C
from brax.training.agents.ppo import networks as N


def latest_ckpt(run_root):
    # run_root/<timestamp>/checkpoints/<stepdir>
    cks = glob.glob(os.path.join(run_root, "*", "checkpoints", "*"))
    cks = [d for d in cks if os.path.isdir(d) and os.path.basename(d).isdigit()]
    cks.sort(key=lambda d: int(os.path.basename(d)))
    return cks[-1] if cks else None


def eval_run(env_name, run_root, steps, n, seed):
    cp = latest_ckpt(run_root)
    assert cp is not None, f"no ckpt under {run_root}"
    st_steps = int(os.path.basename(cp))
    base = registry.load(env_name, config_overrides={"impl": "jax"})
    env = wrapper.wrap_for_brax_training(base, episode_length=steps, action_repeat=1)
    reset, step = jax.jit(env.reset), jax.jit(env.step)
    infer = C.load_policy(cp, network_factory=N.make_ppo_networks, deterministic=True)
    jinfer = jax.jit(infer)
    keys = jax.random.split(jax.random.PRNGKey(seed), n)
    mode = "pick" if "PickCube" in env_name else ("push" if "Push" in env_name else "reorient")

    def run(keys):
        state = reset(keys)
        z = jp.zeros((n,))
        def body(carry, k):
            state, a, b = carry
            act = jax.vmap(jinfer)(state.obs, jax.random.split(k, n))[0]
            state = step(state, act)
            if mode == "pick":
                bt = state.metrics["box_target"]
                rb = state.info["reached_box"]
                return (state, jp.maximum(a, bt), jp.maximum(b, rb)), None
            elif mode == "push":
                sc = state.metrics["success"].astype(jp.float32)
                return (state, jp.maximum(a, sc), b), None
            else:
                sc = state.metrics["success_count"].astype(jp.float32)
                return (state, jp.maximum(a, sc), b), None
        ks = jax.random.split(jax.random.PRNGKey(seed + 1), steps)
        (state, a, b), _ = jax.lax.scan(body, (state, z, z), ks)
        return a, b

    t0 = time.time()
    a, b = jax.jit(run)(keys)
    a = np.asarray(jax.block_until_ready(a)); b = np.asarray(b)
    if mode == "push":
        row = {"env": env_name, "ckpt_step": st_steps, "n_eps": n, "steps": steps,
               "success_rate": round(float((a >= 0.5).mean()), 4),
               "eval_sec": round(time.time() - t0, 1)}
    elif mode == "pick":
        row = {"env": env_name, "ckpt_step": st_steps, "n_eps": n, "steps": steps,
               "success_rate": round(float((a >= 0.9).mean()), 4),
               "reached_rate": round(float((b > 0.5).mean()), 4),
               "mean_max_box_target": round(float(a.mean()), 4),
               "p90_max_box_target": round(float(np.percentile(a, 90)), 4),
               "eval_sec": round(time.time() - t0, 1)}
    else:
        row = {"env": env_name, "ckpt_step": st_steps, "n_eps": n, "steps": steps,
               "success_rate_ge1": round(float((a >= 1).mean()), 4),
               "mean_success_count": round(float(a.mean()), 4),
               "max_success_count": int(a.max()),
               "eval_sec": round(time.time() - t0, 1)}
    print("RESULT", row, flush=True)
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", required=True)
    ap.add_argument("--run_root", required=True)
    ap.add_argument("--steps", type=int, required=True)
    ap.add_argument("--n", type=int, default=256)
    ap.add_argument("--seed", type=int, default=1000)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    row = eval_run(args.env, args.run_root, args.steps, args.n, args.seed)
    json.dump(row, open(args.out, "w"), indent=2)


if __name__ == "__main__":
    main()
