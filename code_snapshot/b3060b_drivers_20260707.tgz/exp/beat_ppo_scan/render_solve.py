"""Render ONE successful episode of a trained brax PPO policy to frames.
Adapts eval_ppo_success.py loading/rollout. Single-env deterministic rollout;
keeps first episode whose native success metric fires; renders a window.
"""
import os, sys, json, argparse, glob, time
sys.path.insert(0, "/root/tdmpc_glass/exp/tdmpc_glass/baselines_ppo_sac")
import jax_compat  # noqa
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ["XLA_PYTHON_CLIENT_PREALLOCATE"] = "false"
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.2")
import numpy as np
import jax, jax.numpy as jp
import imageio
from mujoco_playground import registry
from brax.training.agents.ppo import checkpoint as C
from brax.training.agents.ppo import networks as N


def latest_ckpt(run_root):
    cks = glob.glob(os.path.join(run_root, "*", "checkpoints", "*"))
    cks = [d for d in cks if os.path.isdir(d) and os.path.basename(d).isdigit()]
    cks.sort(key=lambda d: int(os.path.basename(d)))
    return cks[-1] if cks else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", required=True)
    ap.add_argument("--run_root", required=True)
    ap.add_argument("--ep_len", type=int, required=True)
    ap.add_argument("--metric", required=True)       # box_target or success_count
    ap.add_argument("--thresh", type=float, required=True)
    ap.add_argument("--out_mp4", required=True)
    ap.add_argument("--max_eps", type=int, default=30)
    ap.add_argument("--pre", type=int, default=100)  # steps before first success
    ap.add_argument("--post", type=int, default=20)  # steps after
    ap.add_argument("--target_frames", type=int, default=72)
    ap.add_argument("--fps", type=int, default=12)
    ap.add_argument("--camera", default="")
    args = ap.parse_args()

    cp = latest_ckpt(args.run_root)
    assert cp, f"no ckpt {args.run_root}"
    step_n = int(os.path.basename(cp))
    print(f"[load] {args.env} ckpt step={step_n}", flush=True)

    env = registry.load(args.env, config_overrides={"impl": "jax"})
    reset = jax.jit(env.reset)
    step = jax.jit(env.step)
    infer = C.load_policy(cp, network_factory=N.make_ppo_networks, deterministic=True)
    jinfer = jax.jit(infer)

    def rollout(seed, store_from=None, store_to=None):
        # returns metric_series (np), and states list in [store_from, store_to) if given
        rng = jax.random.PRNGKey(seed)
        st = reset(rng)
        series = []
        states = []
        kseq = jax.random.split(jax.random.PRNGKey(seed + 777), args.ep_len)
        for i in range(args.ep_len):
            m = float(np.asarray(st.metrics[args.metric]))
            series.append(m)
            if store_from is not None and store_from <= i < store_to:
                states.append(st)
            act = jinfer(st.obs, kseq[i])[0]
            st = step(st, act)
        # final state metric
        series.append(float(np.asarray(st.metrics[args.metric])))
        if store_from is not None and store_from <= args.ep_len < store_to:
            states.append(st)
        return np.array(series), states

    # pass 1: find a succeeding episode + first-success step
    chosen_seed, first = None, None
    for s in range(args.max_eps):
        series, _ = rollout(s)
        mx = float(series.max())
        fired = np.where(series >= args.thresh)[0]
        print(f"  seed {s}: max {args.metric}={mx:.3f} fired={len(fired)>0}", flush=True)
        if len(fired) > 0:
            chosen_seed = s
            first = int(fired[0])
            chosen_max = mx
            break
    assert chosen_seed is not None, "no successful episode found"
    print(f"[chosen] seed={chosen_seed} first_success_step={first} "
          f"max_{args.metric}={chosen_max:.3f}", flush=True)

    lo = max(0, first - args.pre)
    hi = min(args.ep_len + 1, first + args.post + 1)
    # pass 2: re-roll deterministically, store window states
    _, states = rollout(chosen_seed, store_from=lo, store_to=hi)
    stride = max(1, len(states) // args.target_frames)
    states = states[::stride]
    print(f"[render] window [{lo},{hi}) -> {len(states)} frames (stride {stride})", flush=True)

    cam = args.camera if args.camera else None
    frames = env.render(states, height=240, width=360, camera=cam)
    frames = [np.asarray(f) for f in frames]
    framedir = args.out_mp4 + "_frames"
    os.makedirs(framedir, exist_ok=True)
    for _j, _f in enumerate(frames):
        imageio.imwrite(os.path.join(framedir, "f%04d.png" % _j), _f)
    meta = {"env": args.env, "ckpt_step": step_n, "chosen_seed": chosen_seed,
            "first_success_step": first, "metric": args.metric,
            "thresh": args.thresh, "max_metric_value": round(chosen_max, 4),
            "n_frames": len(frames), "mp4": args.out_mp4}
    print("META", json.dumps(meta), flush=True)
    json.dump(meta, open(args.out_mp4 + ".json", "w"), indent=2)


if __name__ == "__main__":
    main()
