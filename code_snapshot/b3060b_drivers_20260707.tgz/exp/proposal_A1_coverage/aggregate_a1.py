#!/usr/bin/env python3
"""Aggregate Proposal A1 coverage/return CSVs -> coverage_summary.json (+ prints).
Reads ONLY from disk. Every number traceable to a CSV row."""
import csv, json, glob, os, math
from collections import defaultdict

BASE = "/root/tdmpc_glass/helios-rl/exp/tdmpc_glass"
OUT = "/root/tdmpc_glass/exp/proposal_A1_coverage"
ARMS = {"plan": f"{BASE}/HopperHop_A1_plan", "pi": f"{BASE}/HopperHop_A1_pi"}
COVCOLS = ["mean_perdim_entropy", "proj_distinct_bins", "proj_entropy", "frac_cells"]

def load_arm(d):
    rows = []
    for f in sorted(glob.glob(f"{d}/seed_*_coverage.csv")):
        with open(f) as fh:
            for r in csv.DictReader(fh):
                rr = {"seed": int(r["seed"]), "step": int(r["step"]),
                      "pi_return": float(r["pi_return"]), "mppi_return": float(r["mppi_return"]),
                      "n_states": int(r["n_states"])}
                for c in COVCOLS:
                    rr[c] = float(r[c])
                rows.append(rr)
    return rows

def mean(x): return sum(x)/len(x) if x else float("nan")
def std(x):
    if len(x) < 2: return 0.0
    m = mean(x); return math.sqrt(sum((v-m)**2 for v in x)/(len(x)-1))

def by_step(rows, col):
    d = defaultdict(list)
    for r in rows: d[r["step"]].append(r[col])
    return {s: (mean(v), std(v), len(v)) for s, v in sorted(d.items())}

summary = {"task": "HopperHop", "config": {
    "N_ENVS": 64, "K_UPDATE": 16, "NS": 512, "H": 3, "total_steps": 80000,
    "expl_until": 2000, "eval_interval": 10000, "coverage": "20-bin per-dim hist + 12^3 random-proj grid"},
    "arms": {}}
all_rows = {}
for arm, d in ARMS.items():
    rows = load_arm(d)
    all_rows[arm] = rows
    seeds = sorted(set(r["seed"] for r in rows))
    per = {c: by_step(rows, c) for c in COVCOLS + ["pi_return", "mppi_return"]}
    summary["arms"][arm] = {"n_seeds": len(seeds), "seeds": seeds,
                            "n_rows": len(rows),
                            "per_step": {c: {str(s): {"mean": v[0], "std": v[1], "n": v[2]}
                                             for s, v in per[c].items()} for c in per}}

# ---- Test 1: planning -> coverage. Compare PLAN vs PI at matched steps. ----
t1 = {"metric_primary": "proj_distinct_bins", "per_step_delta": {}, "final": {}}
psteps = set()
for arm in ARMS:
    for r in all_rows[arm]: psteps.add(r["step"])
for c in ["proj_distinct_bins", "mean_perdim_entropy", "proj_entropy"]:
    t1.setdefault("by_metric", {})[c] = {}
    for s in sorted(psteps):
        pv = [r[c] for r in all_rows["plan"] if r["step"] == s]
        qv = [r[c] for r in all_rows["pi"] if r["step"] == s]
        if pv and qv:
            t1["by_metric"][c][str(s)] = {
                "plan_mean": mean(pv), "plan_std": std(pv), "plan_n": len(pv),
                "pi_mean": mean(qv), "pi_std": std(qv), "pi_n": len(qv),
                "delta_plan_minus_pi": mean(pv) - mean(qv)}
# final-step (max common step)
common = sorted(set(r["step"] for r in all_rows["plan"]) & set(r["step"] for r in all_rows["pi"]))
if common:
    fs = common[-1]
    for c in ["proj_distinct_bins", "mean_perdim_entropy", "proj_entropy"]:
        pv = [r[c] for r in all_rows["plan"] if r["step"] == fs]
        qv = [r[c] for r in all_rows["pi"] if r["step"] == fs]
        # crude two-sample t (Welch), n small
        def welch(a, b):
            ma, mb = mean(a), mean(b); va, vb = std(a)**2, std(b)**2
            se = math.sqrt(va/len(a) + vb/len(b)) if (a and b) else float("nan")
            return (ma-mb)/se if se and se > 0 else float("nan")
        t1["final"][c] = {"step": fs, "plan_mean": mean(pv), "plan_std": std(pv),
                          "pi_mean": mean(qv), "pi_std": std(qv),
                          "delta": mean(pv)-mean(qv), "welch_t": welch(pv, qv),
                          "plan_higher": mean(pv) > mean(qv)}
summary["test1_planning_to_coverage"] = t1

# ---- Test 2: coverage -> performance. Correlate coverage vs return across all points. ----
xs, ys = [], []
for arm in ARMS:
    for r in all_rows[arm]:
        xs.append(r["proj_distinct_bins"]); ys.append(max(r["pi_return"], r["mppi_return"]))
def pearson(x, y):
    n = len(x)
    if n < 3: return float("nan")
    mx, my = mean(x), mean(y); sx, sy = std(x), std(y)
    if sx == 0 or sy == 0: return float("nan")
    cov = sum((a-mx)*(b-my) for a, b in zip(x, y))/(n-1)
    return cov/(sx*sy)
ret_all = [max(r["pi_return"], r["mppi_return"]) for arm in ARMS for r in all_rows[arm]]
summary["test2_coverage_to_performance"] = {
    "pearson_r_distinctbins_vs_bestreturn": pearson(xs, ys),
    "n_points": len(xs),
    "return_min": min(ret_all) if ret_all else None,
    "return_max": max(ret_all) if ret_all else None,
    "return_mean": mean(ret_all) if ret_all else None,
    "note": "If returns are ~0 across the board, this correlation is uninformative (feasibility caveat)."}

with open(f"{OUT}/coverage_summary.json", "w") as fh:
    json.dump(summary, fh, indent=2)
print(json.dumps({"test1_final": t1.get("final", {}),
                  "test2": summary["test2_coverage_to_performance"],
                  "plan_seeds": summary["arms"].get("plan", {}).get("seeds"),
                  "pi_seeds": summary["arms"].get("pi", {}).get("seeds")}, indent=2))
