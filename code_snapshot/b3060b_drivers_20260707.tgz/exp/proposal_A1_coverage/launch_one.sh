#!/bin/bash
# Proposal A1: launch ONE TD-MPC2 HopperHop run for the planning-as-exploration ablation.
# Usage: launch_one.sh <MODE:plan|pi> <SEED> <GPU>
set -e
MODE=$1; SEED=$2; GPU=$3
cd /root/tdmpc_glass/helios-rl
LOG=/root/tdmpc_glass/exp/proposal_A1_coverage/run_${MODE}_s${SEED}.log
setsid env CUDA_VISIBLE_DEVICES=$GPU \
  A1_COLLECT=$MODE A1_COVERAGE=1 \
  TDMPC_NENVS=64 TDMPC_KUPDATE=16 TDMPC_EVAL_INTERVAL=10000 EVAL_NEPS=2 \
  TDMPC_GLASS_OUTPUT_TAG=A1_${MODE} \
  MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.32 \
  PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo \
  ../venv/bin/python scripts/run_benchmark.py --algos tdmpc2 --tasks HopperHop \
  --seed $SEED --total_steps 80000 --expl_until 2000 > $LOG 2>&1 &
echo "launched MODE=$MODE seed=$SEED gpu=$GPU pid=$! log=$LOG"
