#!/bin/bash
L=/root/tdmpc_glass/exp/proposal_A1_coverage/launch_full.sh
# pi_s0=1593494 (g3); plan_s0=1593488 (g0)
while kill -0 1593494 2>/dev/null; do sleep 20; done
bash $L pi 1 3
while kill -0 1593488 2>/dev/null; do sleep 20; done
bash $L pi 2 0
echo "WAVE B LAUNCHED $(date)"
