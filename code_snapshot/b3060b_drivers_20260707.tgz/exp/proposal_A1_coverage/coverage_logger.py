"""Reusable state-space coverage logger for RL exploration studies (Proposal A1).

Thesis under test: model-based PLANNING is a directed-exploration operator — an
agent that plans (MPPI) during data collection should VISIT MORE of the state
space than a policy-only agent. This logger quantifies "how much of the state
space has been visited" from a stream of visited states.

Design (host-side numpy, cheap):
  1. FIT phase: buffer an initial set of visited states, compute robust per-dim
     normalisation (median / IQR). This is done on the shared random-action warmup
     so both arms get identical, comparable binning.
  2. FREEZE: bins are fixed forever after. This makes the cumulative distinct-cell
     count a valid, monotonic, cross-arm-comparable coverage measure.
  3. ACCUMULATE (post-freeze): per-dim fixed histograms + a fixed random 3-D
     projection grid. Reported metrics:
       - mean_perdim_entropy : mean over dims of Shannon entropy of per-dim
         occupancy (nats) — how spread each coordinate is.
       - proj_distinct_bins  : # of occupied cells of the 3-D projection grid
         (cumulative) — the primary "fraction of state space visited" proxy.
       - proj_entropy        : Shannon entropy of the 3-D occupancy distribution.
       - frac_cells          : proj_distinct_bins / total_cells.
"""
import numpy as np


class CoverageLogger:
    def __init__(self, dim, n_bins=20, proj_dim=3, proj_bins=12, clipv=3.0,
                 n_fit=4000, seed=0):
        self.dim = int(dim)
        self.n_bins = int(n_bins)
        self.proj_dim = int(proj_dim)
        self.proj_bins = int(proj_bins)
        self.clipv = float(clipv)
        self.n_fit = int(n_fit)
        rng = np.random.default_rng(seed)
        P = rng.standard_normal((self.proj_dim, self.dim))
        P /= (np.linalg.norm(P, axis=1, keepdims=True) + 1e-8)
        self.P = P
        self._fit_buf = []
        self._fit_n = 0
        self.frozen = False
        self.median = None
        self.iqr = None
        self.perdim_hist = None
        self.grid_counts = None
        self.n_states = 0

    def _norm(self, X):
        u = (X - self.median) / (self.iqr + 1e-6)
        return np.clip(u, -self.clipv, self.clipv)

    @staticmethod
    def _bin_idx(u, lo, hi, nb):
        t = (u - lo) / (hi - lo)
        return np.clip((t * nb).astype(np.int64), 0, nb - 1)

    def _freeze(self):
        X = np.concatenate(self._fit_buf, axis=0)
        self.median = np.median(X, axis=0)
        q75, q25 = np.percentile(X, [75, 25], axis=0)
        self.iqr = (q75 - q25)
        self.iqr[self.iqr < 1e-6] = 1.0  # dead dims -> unit scale (all in centre bin)
        self.perdim_hist = np.zeros((self.dim, self.n_bins), dtype=np.int64)
        self.grid_counts = {}
        self.frozen = True
        self._fit_buf = []

    def update(self, X):
        X = np.asarray(X, dtype=np.float64)
        if X.ndim == 1:
            X = X[None]
        if not self.frozen:
            self._fit_buf.append(X.copy())
            self._fit_n += X.shape[0]
            if self._fit_n >= self.n_fit:
                self._freeze()
            return
        u = self._norm(X)
        idx = self._bin_idx(u, -self.clipv, self.clipv, self.n_bins)  # (N,dim)
        for d in range(self.dim):
            np.add.at(self.perdim_hist[d], idx[:, d], 1)
        y = u @ self.P.T
        v = np.tanh(y / self.clipv)
        pidx = self._bin_idx(v, -1.0, 1.0, self.proj_bins)  # (N,proj_dim)
        for row in pidx:
            k = tuple(int(z) for z in row)
            self.grid_counts[k] = self.grid_counts.get(k, 0) + 1
        self.n_states += X.shape[0]

    def snapshot(self):
        if not self.frozen or self.n_states == 0:
            return {"ready": 0, "n_states": int(self.n_states)}
        H = self.perdim_hist.astype(np.float64)
        p = H / np.clip(H.sum(axis=1, keepdims=True), 1, None)
        ent = -(p * np.log(np.where(p > 0, p, 1.0))).sum(axis=1)
        mean_perdim_entropy = float(ent.mean())
        counts = np.array(list(self.grid_counts.values()), dtype=np.float64)
        distinct = int(counts.size)
        pg = counts / counts.sum()
        proj_entropy = float(-(pg * np.log(pg)).sum())
        total_cells = self.proj_bins ** self.proj_dim
        return {
            "ready": 1,
            "n_states": int(self.n_states),
            "mean_perdim_entropy": mean_perdim_entropy,
            "proj_distinct_bins": distinct,
            "proj_entropy": proj_entropy,
            "frac_cells": float(distinct / total_cells),
        }
