#!/usr/bin/env python3
"""Aggregate Proposal A1-FULL (WalkerRun) coverage/return CSVs across the training
curve. Reads ONLY from disk. Writes coverage_curve_summary.json.
Analysis:
  warmup   : first step where the collect-policy return is clearly separable-from-floor.
  link1    : planning->coverage, PLAN vs PI per-step delta; early(pre-warmup) vs late(post).
  link2    : coverage->performance, Pearson r on post-warmup points (learning regime)."""
import csv, json, glob, math
from collections import defaultdict

BASE = "/root/tdmpc_glass/helios-rl/exp/tdmpc_glass"
OUT  = "/root/tdmpc_glass/exp/proposal_A1_coverage"
ARMS = {"plan": f"{BASE}/WalkerRun_A1full_plan", "pi": f"{BASE}/WalkerRun_A1full_pi"}
COVCOLS = ["mean_perdim_entropy", "proj_distinct_bins", "proj_entropy", "frac_cells"]
FLOOR = 50.0   # return threshold: WalkerRun random ~ a few; >50 = clearly off floor

def load_arm(d):
    rows = []
    for f in sorted(glob.glob(f"{d}/seed_*_coverage.csv")):
        with open(f) as fh:
            for r in csv.DictReader(fh):
                rr = {"seed": int(r["seed"]), "step": int(r["step"]),
                      "pi_return": float(r["pi_return"]), "mppi_return": float(r["mppi_return"]),
                      "n_states": int(r["n_states"])}
                for c in COVCOLS: rr[c] = float(r[c])
                # collect-policy return: PLAN uses mppi rollout, PI uses pi rollout
                rr["collect_return"] = rr["mppi_return"] if "plan" in d else rr["pi_return"]
                rr["best_return"] = max(rr["pi_return"], rr["mppi_return"])
                rows.append(rr)
    return rows

def mean(x): return sum(x)/len(x) if x else float("nan")
def std(x):
    if len(x) < 2: return 0.0
    m = mean(x); return math.sqrt(sum((v-m)**2 for v in x)/(len(x)-1))
def welch(a, b):
    if len(a)<2 or len(b)<2: return float("nan")
    va, vb = std(a)**2, std(b)**2
    se = math.sqrt(va/len(a)+vb/len(b))
    return (mean(a)-mean(b))/se if se>0 else float("nan")
def pearson(x, y):
    n=len(x)
    if n<3: return float("nan")
    mx,my=mean(x),mean(y); sx,sy=std(x),std(y)
    if sx==0 or sy==0: return float("nan")
    cov=sum((a-mx)*(b-my) for a,b in zip(x,y))/(n-1)
    return cov/(sx*sy)
def by_step(rows, col):
    d=defaultdict(list)
    for r in rows: d[r["step"]].append(r[col])
    return {s:(mean(v),std(v),len(v)) for s,v in sorted(d.items())}

all_rows={arm:load_arm(d) for arm,d in ARMS.items()}

# --- warmup step: first step where mean collect_return > FLOOR (per arm + overall) ---
warmup={}
for arm in ARMS:
    bs=by_step(all_rows[arm],"collect_return")
    w=None
    for s,(m,sd,n) in bs.items():
        if m>FLOOR: w=s; break
    warmup[arm]={"warmup_step":w,"collect_return_by_step":{str(s):{"mean":m,"std":sd,"n":n} for s,(m,sd,n) in bs.items()}}
# overall warmup = max of arm warmups (both must be off floor to compare fairly)
ws=[warmup[a]["warmup_step"] for a in ARMS if warmup[a]["warmup_step"] is not None]
warmup_step = max(ws) if len(ws)==len(ARMS) else (min(ws) if ws else None)

# --- link1: planning->coverage across curve ---
steps=sorted(set(r["step"] for arm in ARMS for r in all_rows[arm]))
common=sorted(set(r["step"] for r in all_rows["plan"]) & set(r["step"] for r in all_rows["pi"]))
link1={"by_metric":{}, "early_vs_late":{}}
for c in ["proj_distinct_bins","proj_entropy","mean_perdim_entropy"]:
    per={}
    for s in common:
        pv=[r[c] for r in all_rows["plan"] if r["step"]==s]
        qv=[r[c] for r in all_rows["pi"] if r["step"]==s]
        per[str(s)]={"plan_mean":mean(pv),"plan_std":std(pv),"pi_mean":mean(qv),"pi_std":std(qv),
                     "delta_plan_minus_pi":mean(pv)-mean(qv),"welch_t":welch(pv,qv),"plan_higher":mean(pv)>mean(qv)}
    link1["by_metric"][c]=per
    # early vs late split at warmup_step
    if warmup_step is not None:
        early=[s for s in common if s< warmup_step]; late=[s for s in common if s>=warmup_step]
        def arm_avg(arm,ss): return mean([r[c] for r in all_rows[arm] if r["step"] in ss])
        link1["early_vs_late"][c]={
          "warmup_step":warmup_step,
          "early_plan":arm_avg("plan",set(early)),"early_pi":arm_avg("pi",set(early)),
          "early_delta":arm_avg("plan",set(early))-arm_avg("pi",set(early)),
          "late_plan":arm_avg("plan",set(late)),"late_pi":arm_avg("pi",set(late)),
          "late_delta":arm_avg("plan",set(late))-arm_avg("pi",set(late)),
          # welch on the late-window per-step deltas: pool all late points per arm
          "late_welch_t":welch([r[c] for r in all_rows["plan"] if r["step"] in set(late)],
                               [r[c] for r in all_rows["pi"] if r["step"] in set(late)])}

# --- link2: coverage->performance (post-warmup, learning regime) ---
def corr_set(rows_pred):
    xs=[r["proj_distinct_bins"] for r in rows_pred]; ys=[r["best_return"] for r in rows_pred]
    return pearson(xs,ys), len(xs)
allrows=[r for arm in ARMS for r in all_rows[arm]]
post=[r for r in allrows if warmup_step is not None and r["step"]>=warmup_step]
r_all,n_all=corr_set(allrows); r_post,n_post=corr_set(post)
rets=[r["best_return"] for r in allrows]
link2={"pearson_all":r_all,"n_all":n_all,"pearson_postwarmup":r_post,"n_postwarmup":n_post,
       "return_min":min(rets),"return_max":max(rets),"return_mean":mean(rets),
       "note":"proj_distinct_bins vs best_return; post = steps >= overall warmup_step"}

summary={"task":"WalkerRun","config":{"N_ENVS":64,"K_UPDATE":16,"NS":512,"H":3,
         "total_steps":200000,"expl_until":2000,"eval_interval":10000,
         "coverage":"20-bin per-dim hist + 12^3 random-proj grid","floor_thresh":FLOOR},
         "n_seeds":{a:len(set(r["seed"] for r in all_rows[a])) for a in ARMS},
         "seeds":{a:sorted(set(r["seed"] for r in all_rows[a])) for a in ARMS},
         "warmup":warmup,"warmup_step_overall":warmup_step,
         "link1_planning_to_coverage":link1,"link2_coverage_to_performance":link2,
         "returns_by_step":{a:{c:{str(s):{"mean":m,"std":sd,"n":n} for s,(m,sd,n) in by_step(all_rows[a],c).items()}
                              for c in ["collect_return","best_return","pi_return","mppi_return"]} for a in ARMS},
         "coverage_by_step":{a:{c:{str(s):{"mean":m,"std":sd,"n":n} for s,(m,sd,n) in by_step(all_rows[a],c).items()}
                              for c in COVCOLS} for a in ARMS}}
with open(f"{OUT}/coverage_curve_summary.json","w") as fh: json.dump(summary,fh,indent=2)
print(json.dumps({"n_seeds":summary["n_seeds"],"warmup_step_overall":warmup_step,
                  "warmup_per_arm":{a:warmup[a]["warmup_step"] for a in ARMS},
                  "link1_early_vs_late":link1["early_vs_late"],
                  "link2":link2},indent=2))
