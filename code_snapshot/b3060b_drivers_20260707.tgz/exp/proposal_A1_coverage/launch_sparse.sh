#!/bin/bash
# Proposal A1-DECISIVE: TD-MPC2 sparse/exploration-hard task, PLAN vs PI-ONLY, coverage across curve.
# Usage: launch_sparse.sh <MODE:plan|pi> <SEED> <GPU> <TASK> <STEPS> <TAG>
set -e
MODE=$1; SEED=$2; GPU=$3; TASK=$4; STEPS=$5; TAG=$6
cd /root/tdmpc_glass/helios-rl
LOG=/root/tdmpc_glass/exp/proposal_A1_coverage/run_${TAG}_${MODE}_s${SEED}.log
setsid env CUDA_VISIBLE_DEVICES=$GPU \
  A1_COLLECT=$MODE A1_COVERAGE=1 \
  TDMPC_NENVS=64 TDMPC_KUPDATE=16 TDMPC_EVAL_INTERVAL=10000 EVAL_NEPS=2 \
  TDMPC_GLASS_OUTPUT_TAG=${TAG}_${MODE} \
  MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.30 \
  PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo \
  ../venv/bin/python scripts/run_benchmark.py --algos tdmpc2 --tasks $TASK \
  --seed $SEED --total_steps $STEPS --expl_until 2000 > $LOG 2>&1 &
echo "launched MODE=$MODE seed=$SEED gpu=$GPU task=$TASK steps=$STEPS pid=$! log=$LOG"
