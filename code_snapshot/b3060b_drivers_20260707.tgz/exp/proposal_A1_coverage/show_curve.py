import json
s=json.load(open("/root/tdmpc_glass/exp/proposal_A1_coverage/coverage_curve_summary.json"))
steps=sorted(int(k) for k in s["returns_by_step"]["plan"]["collect_return"])
print("step | plan_cR  pi_cR | plan_dist pi_dist (delta) | plan_projH pi_projH")
for st in steps:
    k=str(st)
    pc=s["returns_by_step"]["plan"]["collect_return"][k]["mean"]
    qc=s["returns_by_step"]["pi"]["collect_return"][k]["mean"]
    pd=s["coverage_by_step"]["plan"]["proj_distinct_bins"][k]["mean"]
    qd=s["coverage_by_step"]["pi"]["proj_distinct_bins"][k]["mean"]
    pe=s["coverage_by_step"]["plan"]["proj_entropy"][k]["mean"]
    qe=s["coverage_by_step"]["pi"]["proj_entropy"][k]["mean"]
    print("%7d | %6.1f %6.1f | %5.0f %5.0f (%+5.0f) | %.3f %.3f" % (st,pc,qc,pd,qd,pd-qd,pe,qe))
fs=str(steps[-1])
print("\nFINAL", fs)
for arm in ("plan","pi"):
    for m in ("collect_return","best_return","pi_return","mppi_return"):
        v=s["returns_by_step"][arm][m][fs]
        print("  %s %s: %.1f +/- %.1f (n=%d)" % (arm,m,v["mean"],v["std"],v["n"]))
