#!/usr/bin/env python3
"""Aggregate Proposal A1-DECISIVE (CartpoleSwingupSparse) coverage/return CSVs.
Reads ONLY from disk. Writes decisive_summary.json.
Key questions:
  warmup/discovery : first step where a seed/arm collect-return leaves the floor.
  Link1 plan->coverage : does PLAN cover MORE than PI (esp. PRE-discovery)?
  Link2 coverage->perf : does coverage predict discovery / final return?
  discovery rate   : fraction of seeds per arm that discover the sparse reward.
  matched-step     : at equal env_steps, is PLAN collect-return ahead of PI?"""
import csv, json, glob, math
from collections import defaultdict

BASE = "/root/tdmpc_glass/helios-rl/exp/tdmpc_glass"
OUT  = "/root/tdmpc_glass/exp/proposal_A1_coverage"
TASK = "CartpoleSwingupSparse"
ARMS = {"plan": f"{BASE}/{TASK}_A1sparse_plan", "pi": f"{BASE}/{TASK}_A1sparse_pi"}
COVCOLS = ["mean_perdim_entropy", "proj_distinct_bins", "proj_entropy", "frac_cells"]
FLOOR = 20.0      # return>FLOOR = clearly off the sparse floor (random ~ 0)
DISCOVER = 50.0   # collect-return>DISCOVER = the sparse reward has been found+exploited

def load_arm(d):
    rows = []
    for f in sorted(glob.glob(f"{d}/seed_*_coverage.csv")):
        with open(f) as fh:
            for r in csv.DictReader(fh):
                rr = {"seed": int(r["seed"]), "step": int(r["step"]),
                      "pi_return": float(r["pi_return"]), "mppi_return": float(r["mppi_return"]),
                      "n_states": int(r["n_states"])}
                for c in COVCOLS: rr[c] = float(r[c])
                rr["collect_return"] = rr["mppi_return"] if "plan" in d else rr["pi_return"]
                rr["best_return"] = max(rr["pi_return"], rr["mppi_return"])
                rows.append(rr)
    return rows

def mean(x): return sum(x)/len(x) if x else float("nan")
def std(x):
    if len(x) < 2: return 0.0
    m = mean(x); return math.sqrt(sum((v-m)**2 for v in x)/(len(x)-1))
def welch(a, b):
    if len(a)<2 or len(b)<2: return float("nan")
    va, vb = std(a)**2, std(b)**2
    se = math.sqrt(va/len(a)+vb/len(b))
    return (mean(a)-mean(b))/se if se>0 else float("nan")
def pearson(x, y):
    n=len(x)
    if n<3: return float("nan")
    mx,my=mean(x),mean(y); sx,sy=std(x),std(y)
    if sx==0 or sy==0: return float("nan")
    cov=sum((a-mx)*(b-my) for a,b in zip(x,y))/(n-1)
    return cov/(sx*sy)
def by_step(rows, col):
    d=defaultdict(list)
    for r in rows: d[r["step"]].append(r[col])
    return {s:(mean(v),std(v),len(v)) for s,v in sorted(d.items())}

all_rows={arm:load_arm(d) for arm,d in ARMS.items()}

# --- per-seed discovery step (first step collect_return > DISCOVER) ---
def seed_rows(rows, sd): return sorted([r for r in rows if r["seed"]==sd], key=lambda r:r["step"])
discovery={}
for arm in ARMS:
    seeds=sorted(set(r["seed"] for r in all_rows[arm]))
    discovery[arm]={}
    for sd in seeds:
        sr=seed_rows(all_rows[arm], sd)
        dstep=next((r["step"] for r in sr if r["collect_return"]>DISCOVER), None)
        finals=sr[-1] if sr else None
        discovery[arm][str(sd)]={
            "discovery_step": dstep,
            "final_step": finals["step"] if finals else None,
            "final_collect_return": finals["collect_return"] if finals else None,
            "final_best_return": finals["best_return"] if finals else None,
            "max_collect_return": max((r["collect_return"] for r in sr), default=None)}
    n=len(seeds)
    ndisc=sum(1 for sd in seeds if discovery[arm][str(sd)]["discovery_step"] is not None)
    discovery[arm]["_rate"]={"n_seeds":n,"n_discovered":ndisc,"discovery_rate":ndisc/n if n else float("nan"),
        "mean_discovery_step": mean([discovery[arm][str(sd)]["discovery_step"] for sd in seeds
                                     if discovery[arm][str(sd)]["discovery_step"] is not None]),
        "mean_final_collect_return": mean([discovery[arm][str(sd)]["final_collect_return"] for sd in seeds
                                     if discovery[arm][str(sd)]["final_collect_return"] is not None]),
        "mean_final_best_return": mean([discovery[arm][str(sd)]["final_best_return"] for sd in seeds
                                     if discovery[arm][str(sd)]["final_best_return"] is not None])}

# --- warmup step: first step where mean collect_return > FLOOR (per arm) ---
warmup={}
for arm in ARMS:
    bs=by_step(all_rows[arm],"collect_return")
    w=next((s for s,(m,sd,n) in bs.items() if m>FLOOR), None)
    warmup[arm]={"warmup_step":w}
ws=[warmup[a]["warmup_step"] for a in ARMS if warmup[a]["warmup_step"] is not None]
warmup_step = max(ws) if len(ws)==len(ARMS) else (min(ws) if ws else None)

# --- link1: planning->coverage across curve; early(pre-discovery) vs late ---
common=sorted(set(r["step"] for r in all_rows["plan"]) & set(r["step"] for r in all_rows["pi"]))
link1={"by_metric":{}, "early_vs_late":{}}
for c in ["proj_distinct_bins","proj_entropy","mean_perdim_entropy"]:
    per={}
    for s in common:
        pv=[r[c] for r in all_rows["plan"] if r["step"]==s]
        qv=[r[c] for r in all_rows["pi"] if r["step"]==s]
        per[str(s)]={"plan_mean":mean(pv),"plan_std":std(pv),"pi_mean":mean(qv),"pi_std":std(qv),
                     "delta_plan_minus_pi":mean(pv)-mean(qv),"welch_t":welch(pv,qv),"plan_higher":mean(pv)>mean(qv)}
    link1["by_metric"][c]=per
    if warmup_step is not None:
        early=set(s for s in common if s< warmup_step); late=set(s for s in common if s>=warmup_step)
        def arm_avg(arm,ss): return mean([r[c] for r in all_rows[arm] if r["step"] in ss])
        link1["early_vs_late"][c]={
          "warmup_step":warmup_step,
          "early_plan":arm_avg("plan",early),"early_pi":arm_avg("pi",early),
          "early_delta":arm_avg("plan",early)-arm_avg("pi",early),
          "early_welch_t":welch([r[c] for r in all_rows["plan"] if r["step"] in early],
                                [r[c] for r in all_rows["pi"] if r["step"] in early]),
          "late_plan":arm_avg("plan",late),"late_pi":arm_avg("pi",late),
          "late_delta":arm_avg("plan",late)-arm_avg("pi",late),
          "late_welch_t":welch([r[c] for r in all_rows["plan"] if r["step"] in late],
                               [r[c] for r in all_rows["pi"] if r["step"] in late])}

# --- matched-step collect-return: is PLAN ahead of PI at equal budget? ---
matched={}
for s in common:
    pv=[r["collect_return"] for r in all_rows["plan"] if r["step"]==s]
    qv=[r["collect_return"] for r in all_rows["pi"] if r["step"]==s]
    matched[str(s)]={"plan_collect_mean":mean(pv),"pi_collect_mean":mean(qv),
                     "delta_plan_minus_pi":mean(pv)-mean(qv),"plan_ahead":mean(pv)>mean(qv)}

# --- link2: coverage->performance ---
def corr_set(rows_pred):
    xs=[r["proj_distinct_bins"] for r in rows_pred]; ys=[r["best_return"] for r in rows_pred]
    return pearson(xs,ys), len(xs)
allrows=[r for arm in ARMS for r in all_rows[arm]]
post=[r for r in allrows if warmup_step is not None and r["step"]>=warmup_step]
r_all,n_all=corr_set(allrows); r_post,n_post=corr_set(post)
rets=[r["best_return"] for r in allrows]
link2={"pearson_all":r_all,"n_all":n_all,"pearson_postwarmup":r_post,"n_postwarmup":n_post,
       "return_min":min(rets),"return_max":max(rets),"return_mean":mean(rets),
       "note":"proj_distinct_bins vs best_return; post = steps >= overall warmup_step"}

summary={"task":TASK,"config":{"N_ENVS":64,"K_UPDATE":16,"total_steps":300000,"expl_until":2000,
         "eval_interval":10000,"coverage":"20-bin per-dim + 12^3 random-proj grid, frozen on shared random warmup",
         "floor_thresh":FLOOR,"discover_thresh":DISCOVER},
         "n_seeds":{a:len(set(r["seed"] for r in all_rows[a])) for a in ARMS},
         "seeds":{a:sorted(set(r["seed"] for r in all_rows[a])) for a in ARMS},
         "discovery":discovery,"warmup_per_arm":{a:warmup[a]["warmup_step"] for a in ARMS},
         "warmup_step_overall":warmup_step,
         "link1_planning_to_coverage":link1,
         "matched_step_collect_return":matched,
         "link2_coverage_to_performance":link2,
         "returns_by_step":{a:{c:{str(s):{"mean":m,"std":sd,"n":n} for s,(m,sd,n) in by_step(all_rows[a],c).items()}
                              for c in ["collect_return","best_return","pi_return","mppi_return"]} for a in ARMS},
         "coverage_by_step":{a:{c:{str(s):{"mean":m,"std":sd,"n":n} for s,(m,sd,n) in by_step(all_rows[a],c).items()}
                              for c in COVCOLS} for a in ARMS}}
with open(f"{OUT}/decisive_summary.json","w") as fh: json.dump(summary,fh,indent=2)
print(json.dumps({"task":TASK,"n_seeds":summary["n_seeds"],
    "discovery_rate":{a:discovery[a]["_rate"] for a in ARMS},
    "warmup_per_arm":summary["warmup_per_arm"],"warmup_overall":warmup_step,
    "link1_early_vs_late":link1["early_vs_late"],"link2":link2},indent=2))
