#!/bin/bash
# D3 pixel-JEPA arm grid on WalkerWalk. One job per GPU, 4 concurrent.
cd /root/tdmpc_glass/exp/proposal_D3_pixel_jepa
source /root/tdmpc_glass/venv/bin/activate
LOG=logs; mkdir -p $LOG
FILTER='glCheckError|__del__|Exception ignored|GLContext|free(|OpenGL/error|renderer|egl/__init|Traceback|NoneType|vast.ai|Welcome|Have fun|AGENTS'

# job spec: cond simnorm lam_or_lamse seed   (lam used for uniformity/vicreg; lam_se for se_fixed)
JOBS=(
  "none 0 1.0 1" "none 0 1.0 2"
  "uniformity 0 0.5 0" "uniformity 0 0.5 1" "uniformity 0 0.5 2"
  "vicreg 0 1.0 0" "vicreg 0 1.0 1" "vicreg 0 1.0 2"
  "se_fixed 0 1.0 0" "se_fixed 0 1.0 1" "se_fixed 0 1.0 2"
  "se_fixed 0 0.3 0" "se_fixed 0 0.3 1" "se_fixed 0 0.3 2"
  "none 1 1.0 0" "none 1 1.0 1" "none 1 1.0 2"
)

run_job () {
  local spec="$1" gpu="$2"
  read cond sn lam seed <<< "$spec"
  local extra=""
  if [ "$cond" = "se_fixed" ]; then extra="--lam_se $lam"; else extra="--lam $lam"; fi
  local tag="${cond}_sn${sn}_l${lam}_s${seed}"
  python pixel_jepa_dmc.py train --task WalkerWalk \
     --cond $cond --seed $seed --simnorm $sn --gpu $gpu $extra \
     > $LOG/$tag.log 2>&1
}

i=0
for spec in "${JOBS[@]}"; do
  gpu=$((i % 4))
  run_job "$spec" "$gpu" &
  i=$((i+1))
  if (( i % 4 == 0 )); then wait; fi
done
wait
echo "ALL_D3_DONE"
