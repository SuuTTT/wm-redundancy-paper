#!/bin/bash
cd /root/tdmpc_glass/exp/proposal_D3_pixel_jepa
source /root/tdmpc_glass/venv/bin/activate
LOG=logs
JOBS=(
  "none 0 1.0 0" "none 0 1.0 1" "none 0 1.0 2"
  "uniformity 0 0.5 0" "uniformity 0 0.5 1" "uniformity 0 0.5 2"
  "vicreg 0 1.0 0" "vicreg 0 1.0 1" "vicreg 0 1.0 2"
  "se_fixed 0 1.0 0" "se_fixed 0 1.0 1" "se_fixed 0 1.0 2"
)
run_job () {
  read cond sn lam seed <<< "$1"; local gpu="$2"; local extra
  if [ "$cond" = "se_fixed" ]; then extra="--lam_se $lam"; else extra="--lam $lam"; fi
  python pixel_jepa_dmc.py train --task CheetahRun --cond $cond --seed $seed \
     --simnorm $sn --gpu $gpu $extra > $LOG/cheetah_${cond}_l${lam}_s${seed}.log 2>&1
}
i=0
for spec in "${JOBS[@]}"; do
  run_job "$spec" "$((i % 4))" &
  i=$((i+1)); if (( i % 4 == 0 )); then wait; fi
done
wait
echo "CHEETAH_DONE"
