"""PURE self-predictive JEPA on PIXEL DMControl — anti-collapse on high-dim inputs (Proposal D3).

Mirrors the D2 state harness (pure_jepa_ext.py) but swaps low-dim state obs for 64x64x3
PIXEL observations + a DrQ/Dreamer-style CNN encoder. Motivation: on low-dim STATE, a pure
JEPA (encoder + jumpy latent predictor + EMA target) did NOT collapse and `none` (no
anti-collapse) was the strongest arm. LeCun's collapse argument is really about HIGH-DIM
(pixel) inputs, where predicting all pixels is impossible and collapse is a genuine risk.

QUESTION: on PIXELS, does a pure JEPA collapse, and does an anti-collapse term become
LOAD-BEARING (rescuing readouts) unlike on state?

Encoder+target: CNN. Predictor: latent-space (z+a -> zhat). Loss: latent self-prediction ONLY
(no reward/value/policy). Then FREEZE encoder, held-out ridge probes:
  (a) GEOMETRIC : decode true qpos (body/agent config) from pixels
  (b) VALUE     : decode discounted return-to-go (RTG)

Arms (fixed lambda, learned from D2 -- NO grad-norm matching): none / uniformity / vicreg / se.
Backbone --simnorm {0,1}: raw L2-norm latent (0) is the honest collapse control (no simplex prior).

USAGE
  MUJOCO_GL=egl python pixel_jepa_dmc.py collect --task WalkerWalk
  python pixel_jepa_dmc.py train --task WalkerWalk --cond none --seed 0 --simnorm 0 --gpu 0
"""
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path
import numpy as np

HELIOS = Path("/root/tdmpc_glass/helios-rl")
sys.path.insert(0, str(HELIOS / "src"))
sys.path.insert(0, "/root/tdmpc_glass/mujoco_playground_repo")
sys.path.insert(0, "/root/tdmpc_glass/selib")

ROOT = Path("/root/tdmpc_glass/exp/proposal_D3_pixel_jepa")
ROOT.mkdir(parents=True, exist_ok=True)

IMG = 64          # render size
LD = 64           # latent dim
V = 8             # SimNorm groups
HID = (512,)      # MLP head after CNN
BATCH = 256
STEPS = 12000
LR = 3e-4
EMA = 0.99
TAU_S = 0.5
KNN = 15
KC = 16
VICREG_W = 3.0
VICCOV_W = 1.0
VIC_GAMMA = 0.05
UNIF_W = 1.0
GAMMA = 0.97


def cache_path(task, datatag=""):
    return ROOT / f"data_{task}{datatag}.npz"


# ---------------------------------------------------------------------------
# 1. Data collection: pixel transitions via mujoco_playground dynamics + raw
#    mujoco CPU renderer (dm_control loader is version-broken with mujoco 3.8).
# ---------------------------------------------------------------------------
def collect(task, T=1600, num_envs=8, seed=0, policy="smooth", datatag=""):
    import jax, jax.numpy as jnp, mujoco
    from mujoco_playground import registry, wrapper
    base = registry.load(task, config_overrides={"impl": "jax"})
    env = wrapper.wrap_for_brax_training(base, episode_length=1000, action_repeat=1)
    act_dim = int(env.action_size)
    mjm = base.mj_model
    mjd = mujoco.MjData(mjm)
    ren = mujoco.Renderer(mjm, IMG, IMG)
    _reset = jax.jit(env.reset); _step = jax.jit(env.step)
    key = jax.random.PRNGKey(seed)
    key, rk = jax.random.split(key)
    st = _reset(jax.random.split(rk, num_envs))

    def render_batch(qpos, qvel):
        imgs = np.empty((num_envs, IMG, IMG, 3), np.uint8)
        for e in range(num_envs):
            mjd.qpos[:] = qpos[e]; mjd.qvel[:] = qvel[e]
            mujoco.mj_forward(mjm, mjd)
            ren.update_scene(mjd, camera=0)
            imgs[e] = ren.render()
        return imgs

    FR, A, R, D, G = [], [], [], [], []      # per-step frame, action, reward, done, qpos
    a_prev = jnp.zeros((num_envs, act_dim))
    t0 = time.time()
    for t in range(T):
        qpos = np.asarray(st.data.qpos); qvel = np.asarray(st.data.qvel)
        FR.append(render_batch(qpos, qvel))
        G.append(qpos.astype(np.float32))
        key, ak = jax.random.split(key)
        if policy == "smooth":
            a = jnp.clip(a_prev + 0.3 * jax.random.normal(ak, (num_envs, act_dim)), -1.0, 1.0)
            a_prev = a
        else:
            a = jax.random.uniform(ak, (num_envs, act_dim), minval=-1, maxval=1)
        A.append(np.asarray(a))
        st = _step(st, a)
        R.append(np.asarray(st.reward).astype(np.float32))
        D.append(np.asarray(st.done).astype(np.float32))
        if t % 200 == 0:
            print(f"[collect {task}] {t}/{T} {time.time()-t0:.0f}s", flush=True)
    FR = np.stack(FR); A = np.stack(A); R = np.stack(R); D = np.stack(D); G = np.stack(G)  # (T,ne,.)
    # discounted RTG backward with episode reset
    RTG = np.zeros_like(R); running = np.zeros(num_envs, np.float32)
    for t in range(T - 1, -1, -1):
        running = R[t] + GAMMA * running * (1.0 - D[t]); RTG[t] = running
    # form transitions (frame_t, a_t, frame_{t+1}); drop steps where episode ended at t
    O_img, O2_img, Af, Gf, RTGf = [], [], [], [], []
    for t in range(T - 1):
        keep = D[t] < 0.5
        O_img.append(FR[t][keep]); O2_img.append(FR[t + 1][keep])
        Af.append(A[t][keep]); Gf.append(G[t][keep]); RTGf.append(RTG[t][keep])
    O_img = np.concatenate(O_img); O2_img = np.concatenate(O2_img)
    Af = np.concatenate(Af); Gf = np.concatenate(Gf); RTGf = np.concatenate(RTGf)
    print(f"[collect {task}] N={O_img.shape[0]} img={O_img.shape[1:]} act={act_dim} "
          f"qdim={Gf.shape[1]} rtg(mean={RTGf.mean():.2f} std={RTGf.std():.2f}) "
          f"pix(std={O_img.std():.1f}) {time.time()-t0:.0f}s", flush=True)
    np.savez_compressed(cache_path(task, datatag),
                        O=O_img.astype(np.uint8), O2=O2_img.astype(np.uint8),
                        A=Af.astype(np.float32), G=Gf.astype(np.float32),
                        RTG=RTGf.astype(np.float32), act_dim=act_dim)
    print(f"[collect {task}] saved {cache_path(task, datatag)}", flush=True)


# ---------------------------------------------------------------------------
# 2. Differentiable 2D structural entropy (validated vs selib) -- from D2
# ---------------------------------------------------------------------------
def build_se_fns():
    import jax, jax.numpy as jnp

    def knn_adj(z):
        zc = z / (jnp.linalg.norm(z, axis=1, keepdims=True) + 1e-8)
        sim = zc @ zc.T; B = z.shape[0]
        sim = sim - jnp.eye(B) * 10.0
        thr = jax.lax.top_k(sim, KNN)[0][:, -1:]
        mask = jax.lax.stop_gradient((sim >= thr).astype(z.dtype))
        A = mask * jax.nn.relu(sim); A = jnp.maximum(A, A.T)
        return A

    def se2d_soft(A, S):
        deg = A.sum(1); two_m = deg.sum() + 1e-12
        Vol = S.T @ deg; intra = jnp.diag(S.T @ A @ S)
        cut = jnp.clip(Vol - intra, 0.0, None)
        logVol = jnp.log2(Vol + 1e-12)
        leaf = -jnp.sum((deg / two_m) * (jnp.log2(deg + 1e-12) - S @ logVol))
        cutt = -jnp.sum((cut / two_m) * jnp.log2((Vol + 1e-12) / two_m))
        return leaf + cutt

    return knn_adj, se2d_soft


def validate_se():
    import jax.numpy as jnp, networkx as nx
    from selib.metrics import structural_entropy_2d
    _, se2d_soft = build_se_fns()
    rng = np.random.default_rng(0); n = 60
    G = nx.gnm_random_graph(n, 240, seed=1)
    labels = rng.integers(0, 5, n)
    A = nx.to_numpy_array(G, nodelist=list(range(n)))
    S = np.eye(5)[labels]
    mine = float(se2d_soft(jnp.asarray(A), jnp.asarray(S.astype(np.float32))))
    ref = float(structural_entropy_2d(G, list(labels)))
    err = abs(mine - ref)
    print(f"[validate_se] diff-SE={mine:.6f} selib={ref:.6f} abs_err={err:.2e}", flush=True)
    return {"abs_err": err, "match": err < 1e-4}


# ---------------------------------------------------------------------------
# 3. probes + health (from D2)
# ---------------------------------------------------------------------------
def ridge_r2(Ztr, Ytr, Zte, Yte, alpha=1.0):
    n = Ztr.shape[0]
    Zc = np.concatenate([Ztr, np.ones((n, 1))], 1)
    Zce = np.concatenate([Zte, np.ones((Zte.shape[0], 1))], 1)
    A = Zc.T @ Zc; reg = alpha * np.eye(A.shape[0]); reg[-1, -1] = 0.0
    W = np.linalg.solve(A + reg, Zc.T @ Ytr)
    pred = Zce @ W
    ss_res = ((Yte - pred) ** 2).sum(0)
    ss_tot = ((Yte - Yte.mean(0)) ** 2).sum(0) + 1e-12
    r2 = 1.0 - ss_res / ss_tot
    return float(np.mean(r2)), [float(x) for x in r2]


def latent_health(Z, simnorm):
    Z = np.asarray(Z, np.float64); n, D = Z.shape
    Zc = Z - Z.mean(0, keepdims=True)
    cov = (Zc.T @ Zc) / max(n - 1, 1)
    ev = np.clip(np.linalg.eigvalsh(cov), 0, None); s = ev.sum()
    eff_rank = float((s * s) / (np.square(ev).sum() + 1e-12)) if s > 0 else 0.0
    out = {"z_eff_rank": eff_rank, "z_std_mean": float(Z.std(0).mean())}
    if simnorm:
        grp = Z.reshape(n, V, D // V); codes = grp.argmax(-1); ent = []
        for g in range(V):
            cnt = np.bincount(codes[:, g], minlength=D // V).astype(np.float64)
            p = cnt / cnt.sum(); p = p[p > 0]; ent.append(float(-(p * np.log(p)).sum()))
        out["code_entropy_frac"] = float(np.mean(ent) / np.log(D // V))
    return out


# ---------------------------------------------------------------------------
# 4. Train one CNN encoder under one condition, then probe
# ---------------------------------------------------------------------------
def train(task, cond, seed, simnorm, lam_se=1.0, lam_reg=1.0, datatag="", outdir=None):
    import jax, jax.numpy as jnp, flax.linen as nn, optax
    from helios.algorithms.tdmpc2 import simnorm as simnorm_fn, NormMLP
    fname_cond = cond if cond != "se_fixed" else f"sefix{lam_se}"

    d = np.load(cache_path(task, datatag))
    O, O2, A_, G, RTG = d["O"], d["O2"], d["A"], d["G"], d["RTG"]   # O uint8 (N,64,64,3)
    act_dim = int(d["act_dim"]); N = O.shape[0]
    rng = np.random.default_rng(seed)
    perm = rng.permutation(N); ntr = int(0.85 * N)
    tr, te = perm[:ntr], perm[ntr:]

    def headfn(x):
        h = NormMLP(HID, LD)(x)
        return simnorm_fn(h, V) if simnorm else (h / (jnp.linalg.norm(h, axis=-1, keepdims=True) + 1e-6))

    class CNN(nn.Module):
        @nn.compact
        def __call__(self, img):                       # img float (B,64,64,3) in [-0.5,0.5]
            x = img
            for _ in range(4):
                x = nn.Conv(32, (3, 3), strides=(2, 2), padding="VALID")(x)
                x = nn.relu(x)
            x = x.reshape(x.shape[0], -1)               # (B, 3*3*32=288)
            return headfn(x)

    class Pred(nn.Module):
        @nn.compact
        def __call__(self, z, a):
            return headfn(jnp.concatenate([z, a], -1))

    enc, pred = CNN(), Pred()
    key = jax.random.PRNGKey(seed); key, k1, k2, k3 = jax.random.split(key, 4)
    p_enc = enc.init(k1, jnp.zeros((1, IMG, IMG, 3)))
    p_pred = pred.init(k2, jnp.zeros((1, LD)), jnp.zeros((1, act_dim)))
    C0 = jax.random.normal(k3, (KC, LD)) * 0.1
    params = {"enc": p_enc, "pred": p_pred, "C": C0}
    target = {"enc": jax.tree.map(lambda x: x, p_enc)}
    tx = optax.chain(optax.clip_by_global_norm(20.0), optax.adam(LR))
    opt = tx.init(params)
    knn_adj, se2d_soft = build_se_fns()

    def prep(u8):   # uint8 (B,64,64,3) -> float [-0.5,0.5]
        return u8.astype(jnp.float32) / 255.0 - 0.5

    def vicreg(z):
        B, D = z.shape
        std = jnp.sqrt(z.var(0) + 1e-4)
        v = jnp.mean(jax.nn.relu(VIC_GAMMA - std))
        zc = z - z.mean(0, keepdims=True); cov = (zc.T @ zc) / (B - 1)
        off = cov - jnp.diag(jnp.diag(cov)); c = jnp.sum(off ** 2) / D
        return VICREG_W * v + VICCOV_W * c

    def uniformity(z):
        zc = z / (jnp.linalg.norm(z, axis=1, keepdims=True) + 1e-8)
        sq = jnp.clip(2.0 - 2.0 * (zc @ zc.T), 0.0, None); B = z.shape[0]
        off = sq + jnp.eye(B) * 1e9
        return UNIF_W * jnp.log(jnp.mean(jnp.exp(-2.0 * off)) + 1e-12)

    def se_raw(params, z):
        A = knn_adj(z); S = jax.nn.softmax((z @ params["C"].T) / TAU_S, axis=1)
        return se2d_soft(A, S)

    def struct_loss(params, z_t, z_tk, zhat):
        if cond == "none":
            return 0.0 * jnp.sum(z_t[:1])
        if cond == "vicreg":
            return lam_reg * (vicreg(z_t) + vicreg(z_tk) + vicreg(zhat))
        if cond == "uniformity":
            return lam_reg * (uniformity(z_t) + uniformity(z_tk))
        if cond in ("se", "se_fixed"):
            return lam_se * se_raw(params, z_t)
        raise ValueError(cond)

    def loss_fn(params, target, o, a, o2):
        z_t = enc.apply(params["enc"], o)
        zhat = pred.apply(params["pred"], z_t, a)
        z_tgt = jax.lax.stop_gradient(enc.apply(target["enc"], o2))
        l_pred = jnp.mean(jnp.sum((zhat - z_tgt) ** 2, -1))
        z_tk = enc.apply(params["enc"], o2)
        l_struct = struct_loss(params, z_t, z_tk, zhat)
        return l_pred + l_struct, (l_pred, l_struct)

    @jax.jit
    def step(params, target, opt, o, a, o2):
        (loss, aux), g = jax.value_and_grad(loss_fn, has_aux=True)(params, target, o, a, o2)
        upd, opt = tx.update(g, opt, params)
        params = optax.apply_updates(params, upd)
        target = {"enc": jax.tree.map(lambda t, o_: EMA * t + (1 - EMA) * o_,
                                      target["enc"], params["enc"])}
        return params, target, opt, loss, aux

    t0 = time.time(); log = []
    Otr, Atr, O2tr = O[tr], A_[tr], O2[tr]
    ntr_n = Otr.shape[0]
    for it in range(STEPS):
        idx = rng.integers(0, ntr_n, BATCH)
        o = prep(jnp.asarray(Otr[idx])); a = jnp.asarray(Atr[idx]); o2 = prep(jnp.asarray(O2tr[idx]))
        params, target, opt, loss, aux = step(params, target, opt, o, a, o2)
        if it % 2000 == 0 or it == STEPS - 1:
            lp, ls = float(aux[0]), float(aux[1])
            log.append({"it": it, "loss": float(loss), "l_pred": lp, "l_struct": ls})
            print(f"[{task}/{cond}/sn{simnorm} s{seed}] it={it} loss={float(loss):.4f} "
                  f"l_pred={lp:.4f} l_struct={ls:.4f} {time.time()-t0:.0f}s", flush=True)

    # ---- freeze + probe ----
    enc_j = jax.jit(lambda p, o: enc.apply(p["enc"], o))
    def encode_all(imgu8):
        out = []
        for i in range(0, imgu8.shape[0], 2048):
            out.append(np.asarray(enc_j(params, prep(jnp.asarray(imgu8[i:i + 2048])))))
        return np.concatenate(out)
    Ztr, Zte = encode_all(O[tr]), encode_all(O[te])
    geom_r2, geom_per = ridge_r2(Ztr, G[tr], Zte, G[te])
    val_r2, _ = ridge_r2(Ztr, RTG[tr].reshape(-1, 1), Zte, RTG[te].reshape(-1, 1))
    health = latent_health(Zte[:4000], simnorm)

    res = {"task": task, "cond": fname_cond, "simnorm": int(simnorm), "seed": seed, "steps": STEPS,
           "lam_reg": lam_reg, "lam_se": lam_se, "datatag": datatag, "modality": "pixel",
           "latent_dim": LD, "img": IMG, "n_train": int(len(tr)), "n_test": int(len(te)),
           "wall_s": round(time.time() - t0, 1),
           "geom_r2": geom_r2, "geom_r2_per_dim": geom_per, "value_r2": val_r2,
           "eff_rank": health["z_eff_rank"], "z_std_mean": health["z_std_mean"],
           "code_entropy_frac": health.get("code_entropy_frac"), "train_log": log}
    outd = Path(outdir) if outdir else ROOT
    outd.mkdir(parents=True, exist_ok=True)
    fn = outd / f"run_{task}{datatag}_{fname_cond}_sn{simnorm}_seed{seed}.json"
    fn.write_text(json.dumps(res, indent=2))
    print(f"[{task}/{cond}/sn{simnorm} s{seed}] DONE geom_r2={geom_r2:.4f} value_r2={val_r2:.4f} "
          f"eff_rank={health['z_eff_rank']:.2f} -> {fn}", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["collect", "validate_se", "train"])
    ap.add_argument("--task", default="WalkerWalk")
    ap.add_argument("--cond", default="none")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--simnorm", type=int, default=0)
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--lam_se", type=float, default=1.0)
    ap.add_argument("--lam", type=float, default=1.0)
    ap.add_argument("--policy", default="smooth")
    ap.add_argument("--datatag", default="")
    ap.add_argument("--outdir", default="")
    args = ap.parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    os.environ["XLA_PYTHON_CLIENT_MEM_FRACTION"] = "0.20"
    if args.mode == "collect":
        os.environ.setdefault("MUJOCO_GL", "egl")
        collect(args.task, policy=args.policy, datatag=args.datatag)
    elif args.mode == "validate_se":
        print(validate_se())
    elif args.mode == "train":
        v = validate_se()
        if not v["match"]:
            print("[WARN] SE faithfulness check failed", flush=True)
        train(args.task, args.cond, args.seed, bool(args.simnorm), lam_se=args.lam_se,
              lam_reg=args.lam, datatag=args.datatag, outdir=(args.outdir or None))
