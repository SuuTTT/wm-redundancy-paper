#!/bin/bash
cd /root/tdmpc_glass/exp/proposal_D3_pixel_jepa
source /root/tdmpc_glass/venv/bin/activate
LOG=logs
JOBS=(
  "se_fixed 0 1.0 0" "se_fixed 0 1.0 1" "se_fixed 0 1.0 2"
  "se_fixed 0 0.3 0" "se_fixed 0 0.3 1" "se_fixed 0 0.3 2"
)
run_job () {
  read cond sn lam seed <<< "$1"; local gpu="$2"
  python pixel_jepa_dmc.py train --task WalkerWalk --cond $cond --seed $seed \
     --simnorm $sn --gpu $gpu --lam_se $lam > $LOG/${cond}_sn${sn}_l${lam}_s${seed}.log 2>&1
}
i=0
for spec in "${JOBS[@]}"; do
  run_job "$spec" "$((i % 4))" &
  i=$((i+1)); if (( i % 4 == 0 )); then wait; fi
done
wait
echo "SE_DONE"
