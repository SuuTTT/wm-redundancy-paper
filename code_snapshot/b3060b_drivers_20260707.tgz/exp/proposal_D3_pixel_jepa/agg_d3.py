import json, glob, os, sys
from collections import defaultdict
import numpy as np

ROOT = "/root/tdmpc_glass/exp/proposal_D3_pixel_jepa"
rows = defaultdict(list)
for f in sorted(glob.glob(os.path.join(ROOT, "run_*.json"))):
    r = json.load(open(f))
    key = (r["task"], r["cond"], r["simnorm"])
    rows[key].append(r)

def ms(xs):
    a = np.array(xs, float)
    return a.mean(), (a.std() if len(a) > 1 else 0.0)

print(f"{'task':12} {'cond':12} {'sn':3} {'n':2} {'eff_rank':>14} {'geom_r2':>16} {'value_r2':>16}")
agg = {}
for key in sorted(rows):
    rs = rows[key]
    er = ms([x["eff_rank"] for x in rs])
    gm = ms([x["geom_r2"] for x in rs])
    vl = ms([x["value_r2"] for x in rs])
    task, cond, sn = key
    print(f"{task:12} {cond:12} {sn:<3} {len(rs):<2} "
          f"{er[0]:6.2f}±{er[1]:5.2f}  {gm[0]:6.3f}±{gm[1]:5.3f}   {vl[0]:6.3f}±{vl[1]:5.3f}")
    agg["|".join(map(str, key))] = {
        "n": len(rs), "eff_rank": er, "geom_r2": gm, "value_r2": vl,
        "seeds": [x["seed"] for x in rs]}
json.dump(agg, open(os.path.join(ROOT, "D3_summary.json"), "w"), indent=2, default=float)
print("\nsaved D3_summary.json")
