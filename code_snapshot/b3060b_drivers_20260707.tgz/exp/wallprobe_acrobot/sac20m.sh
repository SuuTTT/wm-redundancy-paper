#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_acrobot
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p $EXP/runs_sac20m
for s in 41 42; do
  CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py --env AcrobotSwingup --seed $s --num_timesteps 20000000 --num_evals 26 --outdir $EXP/runs_sac20m > $EXP/logs/sac20m_seed${s}.log 2>&1
  echo "[acro20] sac20m s$s rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log
done
echo "SAC20M_ACRO_DONE" > $EXP/SAC20M_ACRO_DONE
