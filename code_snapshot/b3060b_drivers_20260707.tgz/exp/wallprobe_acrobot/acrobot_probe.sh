#!/usr/bin/env bash
# Discriminating wall probe: AcrobotSwingup = UNSTABLE but CONTACT-FREE dynamics.
# Tests whether the on-policy wall characterization requires contact-criticality or
# instability alone. GPU0/1: PPO 285M seeds 41-44 (2 chains); GPU2: SAC 5M seeds 41-43;
# GPU3: TD-MPC2 1M seeds 41-42.
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_acrobot
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
export PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo
mkdir -p "$EXP/logs" "$EXP/runs_ppo" "$EXP/runs_sac"
ppo_chain() {
  local gpu=$1; shift
  for s in "$@"; do
    CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py \
        --env AcrobotSwingup --seed "$s" --num_timesteps 285000000 --num_evals 30 \
        --outdir "$EXP/runs_ppo" > "$EXP/logs/ppo_seed${s}.log" 2>&1
    echo "[acro] ppo s$s rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
  done
}
sac_chain() {
  for s in 41 42 43; do
    CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py \
        --env AcrobotSwingup --seed "$s" --num_timesteps 5000000 --num_evals 26 \
        --outdir "$EXP/runs_sac" > "$EXP/logs/sac_seed${s}.log" 2>&1
    echo "[acro] sac s$s rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
  done
}
tdmpc2_chain() {
  for s in 41 42; do
    CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax \
      TDMPC_GLASS_OUTPUT_TAG=wallprobe_acro_s$s \
      python -u /root/tdmpc_glass/helios-rl/scripts/run_benchmark.py --algos tdmpc2 \
        --tasks AcrobotSwingup --total_steps 1000000 --seed "$s" \
        --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 \
        --no_plot > "$EXP/logs/tdmpc2_seed${s}.log" 2>&1
    echo "[acro] tdmpc2 s$s rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
  done
}
ppo_chain 0 41 42 &
ppo_chain 1 43 44 &
sac_chain &
tdmpc2_chain &
wait
echo "ACROBOT_PROBE_DONE $(date -u +%FT%TZ)" > "$EXP/ACROBOT_PROBE_DONE"
