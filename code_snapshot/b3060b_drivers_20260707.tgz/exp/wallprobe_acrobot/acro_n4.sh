#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_acrobot
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
export PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo
t2() { CUDA_VISIBLE_DEVICES=$1 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax TDMPC_GLASS_OUTPUT_TAG=wallprobe_acro_s$2 python -u /root/tdmpc_glass/helios-rl/scripts/run_benchmark.py --algos tdmpc2 --tasks AcrobotSwingup --total_steps 1000000 --seed $2 --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 --no_plot > $EXP/logs/tdmpc2_seed$2.log 2>&1; echo "[n4] t$2 rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log; }
s20() { for s in 43 44; do CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py --env AcrobotSwingup --seed $s --num_timesteps 20000000 --num_evals 26 --outdir $EXP/runs_sac20m > $EXP/logs/sac20m_seed$s.log 2>&1; echo "[n4] sac20 s$s rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log; done; }
hs() { for s in 41 42; do CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py --env HumanoidStand --seed $s --num_timesteps 5000000 --num_evals 26 --outdir /root/tdmpc_glass/exp/wallgen_humanoid/runs_sac_stand > /root/tdmpc_glass/exp/wallgen_humanoid/logs/sacstand_seed$s.log 2>&1; echo "[n4] sacstand s$s rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log; done; }
mkdir -p /root/tdmpc_glass/exp/wallgen_humanoid/runs_sac_stand
t2 0 43 &
t2 1 44 &
s20 &
hs &
wait
echo DONE > $EXP/ACRO_N4_DONE
