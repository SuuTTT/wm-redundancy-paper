#!/usr/bin/env python3
"""C1-OOD GATE for the entity-graph class (Paper A: "When is abstraction redundant?").

THE DISCRIMINATING TEST
=======================
Train a MONOLITHIC (flat) world model on the synthetic multi-entity world at
N_train, then fit a HELD-OUT ridge value-decoder on its latent and measure
held-out R^2 of the (Monte-Carlo) return at N_train vs at held-out object counts
N_ood. The paper's criterion predicts explicit entity abstraction helps IFF C1
collapses OOD -- i.e. value stops being linearly decodable from the monolithic
latent at unseen object counts.

  - R^2 does NOT drop OOD  -> NULL  (abstraction still redundant; closes the class)
  - R^2 DROPS markedly OOD -> GO    (run the entity-vs-monolith payoff comparison)

DISCIPLINE (this project over-claimed ~7x):
  * HELD-OUT ridge R^2 (80/20 split, standardized, lam=10) -- NOT train R^2.
    Protocol copied from scripts/vz_probe.heldout_ridge_r2.
  * Every number written to disk; n (samples, seeds) reported.
  * Pooling-artifact confound: monolith mode="pool" (mean+max) can collapse OOD
    purely from pooling, not from value-decodability. We therefore run BOTH
    mode="pool" AND mode="pad" (fixed per-entity slots up to max_entities, no
    pooling collapse, N-invariant latent width => no untrained-param confound).
    A drop that appears in BOTH modes is a genuine value-decodability collapse;
    a drop only in "pool" is a pooling artifact.
  * Two probe variants reported:
      - r2_perN  : decoder fit on THIS N's latents (standard "is value decodable
                   here").
      - r2_transfer : decoder fit on N_train latents, applied to OOD latents
                   (sharpest gate; valid because latent width is N-invariant).
  * Entity-factored WM probed too, as the reference the monolith is compared to.

One run = one (seed). Trains monolith(pool), monolith(pad), entity WM; probes all
at N_train + each N_ood. Writes <out>/seed<seed>.json.
"""
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax, jax.numpy as jnp
import numpy as np
import optax

HELIOS = "/root/helios-rl"
sys.path.insert(0, HELIOS + "/src")
from helios.envs import synthetic_entities as se
from helios.dynamics.monolithic_wm import MonolithicWM, monolithic_wm_loss
from helios.dynamics.entity_wm import EntityWM, entity_wm_loss


# --------------------------------------------------------------------------
# Data collection (return-to-go = value target), reused from run_synthetic_gate
# --------------------------------------------------------------------------
def collect_dataset(env, key, n_episodes, ep_len, gamma=0.99):
    roll = jax.jit(lambda k: se.rollout(env, k, ep_len))

    def returns_to_go(rewards):
        def body(carry, r):
            g = r + gamma * carry
            return g, g
        _, g_rev = jax.lax.scan(body, 0.0, rewards[::-1])
        return g_rev[::-1]
    rtg = jax.jit(returns_to_go)

    ents, acts, nents, rews, rets = [], [], [], [], []
    for k in jax.random.split(key, n_episodes):
        traj = roll(k)
        next_ent = jax.vmap(
            lambda o: o.reshape(env.n_entities, se.ENTITY_DIM))(traj["next_obs"])
        ents.append(traj["ent"]); acts.append(traj["action"])
        nents.append(next_ent); rews.append(traj["reward"])
        rets.append(rtg(traj["reward"]))
    cat = lambda xs: jnp.concatenate(xs, axis=0)
    return {"ent": cat(ents), "action": cat(acts), "next_ent": cat(nents),
            "reward": cat(rews), "ret": cat(rets)}


# --------------------------------------------------------------------------
# Held-out ridge R^2 (protocol identical to scripts/vz_probe.heldout_ridge_r2)
# --------------------------------------------------------------------------
def ridge_fit(Xtr, ytr, lam=10.0):
    Xtr = np.asarray(Xtr, np.float64); ytr = np.asarray(ytr, np.float64)
    mu = Xtr.mean(0); sd = Xtr.std(0) + 1e-6
    Xn = (Xtr - mu) / sd
    ym = ytr.mean(); d = Xn.shape[1]
    w = np.linalg.solve(Xn.T @ Xn + lam * np.eye(d), Xn.T @ (ytr - ym))
    return (mu, sd, ym, w)


def ridge_apply(model, X):
    mu, sd, ym, w = model
    Xn = (np.asarray(X, np.float64) - mu) / sd
    return Xn @ w + ym


def r2_score(y, pred):
    y = np.asarray(y, np.float64); pred = np.asarray(pred, np.float64)
    sr = float(((y - pred) ** 2).sum())
    stt = float(((y - y.mean()) ** 2).sum())
    return float(1.0 - sr / stt) if stt > 1e-8 else float("nan")


def heldout_split(n, seed=0, frac=0.8):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(n); cut = int(n * frac)
    return idx[:cut], idx[cut:]


# --------------------------------------------------------------------------
# Latent extraction
# --------------------------------------------------------------------------
def mono_latent(model, params, ent, action, bs=4096):
    outs = []
    for i in range(0, ent.shape[0], bs):
        out = model.apply({"params": params}, ent[i:i+bs], action[i:i+bs],
                          return_attn=True)
        lat = out["tokens"][0, :, 0, :]       # monolith tokens = (1,B,1,hidden)
        outs.append(np.asarray(lat))
    return np.concatenate(outs, 0)            # (M, hidden)


def entity_latent(model, params, ent, action, bs=4096):
    outs = []
    for i in range(0, ent.shape[0], bs):
        out = model.apply({"params": params}, ent[i:i+bs], action[i:i+bs],
                          return_attn=True)
        tok = out["tokens"][-1]               # (B, N, D) final layer
        outs.append(np.asarray(tok.mean(axis=1)))   # mean-pool over entities -> (B,D)
    return np.concatenate(outs, 0)            # (M, D), N-invariant width


# --------------------------------------------------------------------------
# Training
# --------------------------------------------------------------------------
def train_model(model, loss_fn, data, key, steps, batch, lr):
    k_init, key = jax.random.split(key)
    params = model.init(k_init, data["ent"][:2], data["action"][:2])["params"]
    opt = optax.adam(lr); opt_state = opt.init(params)
    M = data["ent"].shape[0]

    @jax.jit
    def step_fn(params, opt_state, batch):
        (loss, metrics), grads = jax.value_and_grad(loss_fn, has_aux=True)(
            params, model.apply, batch)
        updates, opt_state = opt.update(grads, opt_state)
        return optax.apply_updates(params, updates), opt_state, metrics

    last = {}
    for s in range(steps):
        key, bk = jax.random.split(key)
        idx = jax.random.randint(bk, (batch,), 0, M)
        b = {"ent": data["ent"][idx], "action": data["action"][idx],
             "next_ent": data["next_ent"][idx], "reward": data["reward"][idx],
             "q_target": data["ret"][idx]}
        params, opt_state, metrics = step_fn(params, opt_state, b)
        last = {k: float(v) for k, v in metrics.items()}
    nparams = int(sum(x.size for x in jax.tree_util.tree_leaves(params)))
    return params, last, nparams


# --------------------------------------------------------------------------
# Probe one trained model across N (per-N + transfer-from-N_train), held-out R^2
# --------------------------------------------------------------------------
def probe_model(model, params, latent_fn, n_train, n_list, seed, episodes, ep_len,
                base_key):
    """Returns dict {str(N): {r2_perN, r2_transfer, n_samples}} + r2_train_indist."""
    # collect & cache latents per N
    feats, rets = {}, {}
    for n in n_list:
        env_n = se.make_env(n_entities=n, seed=seed)
        k = jax.random.fold_in(base_key, n)
        d = collect_dataset(env_n, k, episodes, ep_len)
        feats[n] = latent_fn(model, params, d["ent"], d["action"])
        rets[n] = np.asarray(d["ret"])

    # fit decoder on N_train (held-out split)
    Xtr_all, ytr_all = feats[n_train], rets[n_train]
    tr_idx, te_idx = heldout_split(len(Xtr_all), seed=seed)
    decoder = ridge_fit(Xtr_all[tr_idx], ytr_all[tr_idx])
    # in-dist held-out R^2 at N_train
    r2_indist = r2_score(ytr_all[te_idx], ridge_apply(decoder, Xtr_all[te_idx]))

    out = {}
    for n in n_list:
        Xn, yn = feats[n], rets[n]
        if n == n_train:
            r2_perN = r2_indist                      # already held-out
            r2_transfer = r2_indist
        else:
            # per-N decoder: fit on this N's train split, eval its test split
            tr, te = heldout_split(len(Xn), seed=seed)
            dec_n = ridge_fit(Xn[tr], yn[tr])
            r2_perN = r2_score(yn[te], ridge_apply(dec_n, Xn[te]))
            # transfer: N_train decoder applied to ALL of this N's data
            r2_transfer = r2_score(yn, ridge_apply(decoder, Xn))
        out[str(n)] = {"r2_perN": round(r2_perN, 4),
                       "r2_transfer": round(r2_transfer, 4),
                       "n_samples": int(len(Xn)),
                       "latent_dim": int(Xn.shape[1])}
    return out, round(r2_indist, 4)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n_train", type=int, default=4)
    ap.add_argument("--n_ood", type=str, default="6,8")
    ap.add_argument("--steps", type=int, default=4000)
    ap.add_argument("--episodes", type=int, default=256)
    ap.add_argument("--ep_len", type=int, default=100)
    ap.add_argument("--batch", type=int, default=256)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--hidden", type=int, default=128)
    ap.add_argument("--n_layers", type=int, default=2)
    ap.add_argument("--d_model", type=int, default=64)
    ap.add_argument("--ent_layers", type=int, default=2)
    ap.add_argument("--n_heads", type=int, default=4)
    ap.add_argument("--max_entities", type=int, default=16)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    n_ood = [int(x) for x in args.n_ood.split(",") if x.strip()]
    n_list = [args.n_train] + n_ood
    Path(args.out).mkdir(parents=True, exist_ok=True)

    t0 = time.time()
    key = jax.random.PRNGKey(args.seed)
    k_data, k_tr1, k_tr2, k_tr3, k_pr, key = jax.random.split(key, 6)

    # --- training data at N_train ---
    env_train = se.make_env(n_entities=args.n_train, seed=args.seed)
    data = collect_dataset(env_train, k_data, args.episodes, args.ep_len)

    results = {}

    # --- MONOLITH (pool) ---
    m_pool = MonolithicWM(entity_dim=se.ENTITY_DIM, action_dim=2,
                          n_entities=args.n_train, hidden=args.hidden,
                          n_layers=args.n_layers, mode="pool",
                          max_entities=args.max_entities)
    p_pool, tm_pool, np_pool = train_model(m_pool, monolithic_wm_loss, data, k_tr1,
                                           args.steps, args.batch, args.lr)
    probe_pool, indist_pool = probe_model(
        m_pool, p_pool, mono_latent, args.n_train, n_list, args.seed,
        args.episodes, args.ep_len, k_pr)
    results["monolith_pool"] = {"train_metrics": tm_pool, "nparams": np_pool,
                                "r2_indist": indist_pool, "per_N": probe_pool}

    # --- MONOLITH (pad) ---
    m_pad = MonolithicWM(entity_dim=se.ENTITY_DIM, action_dim=2,
                         n_entities=args.n_train, hidden=args.hidden,
                         n_layers=args.n_layers, mode="pad",
                         max_entities=args.max_entities)
    p_pad, tm_pad, np_pad = train_model(m_pad, monolithic_wm_loss, data, k_tr2,
                                        args.steps, args.batch, args.lr)
    probe_pad, indist_pad = probe_model(
        m_pad, p_pad, mono_latent, args.n_train, n_list, args.seed,
        args.episodes, args.ep_len, k_pr)
    results["monolith_pad"] = {"train_metrics": tm_pad, "nparams": np_pad,
                               "r2_indist": indist_pad, "per_N": probe_pad}

    # --- ENTITY-factored WM (reference) ---
    m_ent = EntityWM(entity_dim=se.ENTITY_DIM, action_dim=2,
                     n_entities=args.n_train, d_model=args.d_model,
                     n_layers=args.ent_layers, n_heads=args.n_heads,
                     max_entities=args.max_entities)
    p_ent, tm_ent, np_ent = train_model(m_ent, entity_wm_loss, data, k_tr3,
                                        args.steps, args.batch, args.lr)
    probe_ent, indist_ent = probe_model(
        m_ent, p_ent, entity_latent, args.n_train, n_list, args.seed,
        args.episodes, args.ep_len, k_pr)
    results["entity_wm"] = {"train_metrics": tm_ent, "nparams": np_ent,
                            "r2_indist": indist_ent, "per_N": probe_ent}

    out = {
        "seed": args.seed,
        "config": {"n_train": args.n_train, "n_ood": n_ood, "steps": args.steps,
                   "episodes": args.episodes, "ep_len": args.ep_len,
                   "batch": args.batch, "lr": args.lr, "hidden": args.hidden,
                   "n_layers": args.n_layers, "d_model": args.d_model,
                   "ent_layers": args.ent_layers, "n_heads": args.n_heads,
                   "max_entities": args.max_entities},
        "probe_protocol": "heldout_ridge_r2 (80/20 split, standardized, lam=10); "
                          "target=MC return-to-go; latent=monolith encode() / "
                          "entity mean-pooled final tokens",
        "value_relevant_entities": list(env_train.value_relevant_entities),
        "results": results,
        "wall_time_sec": round(time.time() - t0, 1),
    }
    out_path = Path(args.out) / f"seed{args.seed}.json"
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"[c1_ood_gate] wrote {out_path}")
    # concise console summary
    for name, r in results.items():
        line = " ".join(f"N{n}:perN={r['per_N'][str(n)]['r2_perN']},"
                        f"tr={r['per_N'][str(n)]['r2_transfer']}" for n in n_list)
        print(f"  {name:14s} indist={r['r2_indist']}  {line}")


if __name__ == "__main__":
    main()
