#!/usr/bin/env python3
"""Aggregate C1-OOD gate seeds -> GO_VERDICT.json. Reads only from disk JSONs."""
import json, glob, sys
from pathlib import Path
import numpy as np

OUT = Path("/root/tdmpc_glass/exp/entity_graph_go")
files = sorted(glob.glob(str(OUT / "seed*.json")))
runs = [json.load(open(f)) for f in files]
assert runs, "no seed JSONs"
cfg = runs[0]["config"]
n_train = cfg["n_train"]; n_ood = cfg["n_ood"]; n_list = [n_train] + n_ood
seeds = [r["seed"] for r in runs]

def collect(model_key, metric):
    """Return {N: [values across seeds]} for results[model_key].per_N[N][metric]."""
    d = {n: [] for n in n_list}
    for r in runs:
        per = r["results"][model_key]["per_N"]
        for n in n_list:
            d[n].append(per[str(n)][metric])
    return d

def ms(vals):
    a = np.asarray(vals, float)
    return {"mean": round(float(a.mean()), 4),
            "std": round(float(a.std(ddof=1)) if len(a) > 1 else 0.0, 4),
            "n_seeds": int(len(a)), "values": [round(float(x), 4) for x in a]}

summary = {}
for mk in ["monolith_pool", "monolith_pad", "entity_wm"]:
    perN = collect(mk, "r2_perN")
    trN = collect(mk, "r2_transfer")
    indist = [r["results"][mk]["r2_indist"] for r in runs]
    nsamp = [r["results"][mk]["per_N"][str(n_train)]["n_samples"] for r in runs]
    summary[mk] = {
        "r2_perN_by_N": {str(n): ms(perN[n]) for n in n_list},
        "r2_transfer_by_N": {str(n): ms(trN[n]) for n in n_list},
        "r2_indist_heldout": ms(indist),
        "n_samples_per_N": int(np.mean(nsamp)),
    }

# ---- VERDICT logic (uses r2_perN: the clean "is value linearly decodable at
# this N" metric; r2_transfer conflates decodability with latent-distribution
# shift and is reported for transparency only, NOT used for the verdict) ----
def perN_mean(mk, n):
    return summary[mk]["r2_perN_by_N"][str(n)]["mean"]

mono = "monolith_pad"   # the FAIR monolith (no pooling-collapse artifact)
indist_pad = perN_mean(mono, n_train)
ood_pad = {str(n): perN_mean(mono, n) for n in n_ood}
worst_ood_pad = min(ood_pad.values())
drop_pad = round(indist_pad - worst_ood_pad, 4)
rel_drop_pad = round(drop_pad / indist_pad, 4)

indist_pool = perN_mean("monolith_pool", n_train)
ood_pool = {str(n): perN_mean("monolith_pool", n) for n in n_ood}
worst_ood_pool = min(ood_pool.values())
drop_pool = round(indist_pool - worst_ood_pool, 4)

# GO requires a MARKED collapse OOD in the FAIR (pad) monolith. A collapse in
# pool-only is a pooling artifact, not a value-decodability collapse.
# Threshold: GO if fair monolith R^2 drops below 0.5 absolute OR loses >50% rel.
GO = bool(worst_ood_pad < 0.5 or rel_drop_pad > 0.5)

verdict = {
    "experiment": "C1-OOD gate: entity-graph class, monolithic WM, held-out object counts",
    "criterion": "abstraction helps IFF value stops being linearly decodable from the "
                 "monolithic latent at unseen object counts (C1 collapses OOD)",
    "n_seeds": len(runs), "seeds": seeds,
    "n_train": n_train, "n_ood": n_ood,
    "train_steps": cfg["steps"], "episodes_per_N": cfg["episodes"], "ep_len": cfg["ep_len"],
    "probe_protocol": "held-out ridge R^2 (80/20, standardized, lam=10); target=MC "
                      "return-to-go; metric for verdict = r2_perN (decoder refit at each N)",
    "value_relevant_entities": runs[0]["value_relevant_entities"],
    "headline_fair_monolith(pad)": {
        "r2_perN_indist_N%d" % n_train: round(indist_pad, 4),
        "r2_perN_ood": {k: round(v, 4) for k, v in ood_pad.items()},
        "abs_drop_worst_ood": drop_pad,
        "rel_drop_worst_ood": rel_drop_pad,
    },
    "monolith_pool(pooling-confounded)": {
        "r2_perN_indist_N%d" % n_train: round(indist_pool, 4),
        "r2_perN_ood": {k: round(v, 4) for k, v in ood_pool.items()},
        "abs_drop_worst_ood": drop_pool,
        "note": "pool mode mean+max pooling can collapse OOD as a pooling artifact; "
                "compare to pad to disentangle",
    },
    "entity_wm_reference": {
        "r2_perN_indist_N%d" % n_train: round(perN_mean("entity_wm", n_train), 4),
        "r2_perN_ood": {str(n): round(perN_mean("entity_wm", n), 4) for n in n_ood},
    },
    "VERDICT": "GO" if GO else "NO-GO (NULL)",
    "verdict_basis": (
        "Fair (pad) monolith retains high linear value-decodability OOD "
        f"(worst OOD R^2={worst_ood_pad:.3f}, rel drop={rel_drop_pad:.2%} from in-dist "
        f"{indist_pad:.3f}); C1 does NOT collapse OOD -> NULL: explicit entity "
        "abstraction is predicted redundant, consistent with the rest of the paper."
        if not GO else
        f"Fair (pad) monolith value-decodability collapses OOD (worst OOD R^2="
        f"{worst_ood_pad:.3f}, rel drop {rel_drop_pad:.2%}) -> GO: run entity-vs-"
        "monolith compositional-OOD payoff comparison."),
    "full_summary": summary,
    "source_files": [Path(f).name for f in files],
}

(OUT / "GO_VERDICT.json").write_text(json.dumps(verdict, indent=2))
print(json.dumps({k: verdict[k] for k in
    ["VERDICT", "verdict_basis", "headline_fair_monolith(pad)",
     "monolith_pool(pooling-confounded)", "entity_wm_reference", "n_seeds"]}, indent=2))
print("\nwrote", OUT / "GO_VERDICT.json")
