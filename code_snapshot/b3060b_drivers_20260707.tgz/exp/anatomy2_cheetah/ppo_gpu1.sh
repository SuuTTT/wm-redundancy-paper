#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/anatomy2_cheetah
DRV=/root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
CUDA_VISIBLE_DEVICES=1 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.5 MUJOCO_GL=egl \
  python -u "$DRV" --env CheetahRun --seed 32 \
    --num_timesteps 150000000 --num_evals 30 --outdir "$EXP/runs_ppo" \
    > "$EXP/logs/ppo_seed32.log" 2>&1
echo "PPO_S32 rc=$? $(date -u +%FT%TZ)" >> "$EXP/logs/ppo_progress.log"
touch "$EXP/.ppo_gpu1_done"
