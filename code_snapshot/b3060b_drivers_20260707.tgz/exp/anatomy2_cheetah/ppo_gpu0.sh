#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/anatomy2_cheetah
DRV=/root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
python -c "from mujoco_playground.config import dm_control_suite_params as p; c=p.brax_ppo_config('CheetahRun'); print('[audit] brax_ppo_config(CheetahRun) resolved (pre-override):'); print(c)" > "$EXP/logs/ppo_config_audit.log" 2>&1
for s in 31 33; do
  CUDA_VISIBLE_DEVICES=0 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.5 MUJOCO_GL=egl \
    python -u "$DRV" --env CheetahRun --seed $s \
      --num_timesteps 150000000 --num_evals 30 --outdir "$EXP/runs_ppo" \
      > "$EXP/logs/ppo_seed${s}.log" 2>&1
  echo "PPO_S${s} rc=$? $(date -u +%FT%TZ)" >> "$EXP/logs/ppo_progress.log"
done
touch "$EXP/.ppo_gpu0_done"
