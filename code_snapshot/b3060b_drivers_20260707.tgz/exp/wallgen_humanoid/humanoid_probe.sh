#!/usr/bin/env bash
# Wall-generalization probe: does the TD-MPC2 >> SAC >> PPO reliability x efficiency ordering
# hold on a second unstable morphology (HumanoidWalk)?
# GPU0: PPO seed 41 (200M); GPU1: PPO seed 42 (200M); GPU2: SAC seeds 41,42 (5M, sequential);
# GPU3: TD-MPC2 seed 41 (1M).
set -u
EXP=/root/tdmpc_glass/exp/wallgen_humanoid
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$EXP/logs" "$EXP/runs_ppo" "$EXP/runs_sac"

ppo_seed() {
  local gpu=$1 seed=$2
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
    python -u /root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py \
      --env HumanoidWalk --seed "$seed" --num_timesteps 200000000 --num_evals 30 \
      --outdir "$EXP/runs_ppo" > "$EXP/logs/ppo_seed${seed}.log" 2>&1
  echo "[hum] ppo seed $seed rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
}
sac_chain() {
  for s in 41 42; do
    CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py \
        --env HumanoidWalk --seed "$s" --num_timesteps 5000000 --num_evals 26 \
        --outdir "$EXP/runs_sac" > "$EXP/logs/sac_seed${s}.log" 2>&1
    echo "[hum] sac seed $s rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
  done
}
tdmpc2_seed() {
  export PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo
  CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax \
    TDMPC_GLASS_OUTPUT_TAG=wallgen_hum_s41 \
    python -u /root/tdmpc_glass/helios-rl/scripts/run_benchmark.py --algos tdmpc2 \
      --tasks HumanoidWalk --total_steps 1000000 --seed 41 \
      --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 \
      --no_plot > "$EXP/logs/tdmpc2_seed41.log" 2>&1
  echo "[hum] tdmpc2 seed 41 rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
}
ppo_seed 0 41 &
ppo_seed 1 42 &
sac_chain &
tdmpc2_seed &
wait
echo "WALLGEN_HUMANOID_DONE $(date -u +%FT%TZ)" > "$EXP/WALLGEN_HUMANOID_DONE"
