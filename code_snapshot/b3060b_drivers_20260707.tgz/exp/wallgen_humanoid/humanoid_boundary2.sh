#!/usr/bin/env bash
# Firms the two thin cells in Part 9 §4b:
# GPU0/1: TD-MPC2 HumanoidWalk 4M seeds 43/44 -> divergence-rate n=2 -> n=4.
# GPU2: TD-MPC2 HumanoidStand 1M seed 41 -> is the failure task-difficulty or morphology-wide?
set -u
EXP=/root/tdmpc_glass/exp/wallgen_humanoid
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
export PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo
mkdir -p "$EXP/logs"
run() {
  local gpu=$1 task=$2 steps=$3 seed=$4 tag=$5
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax \
    TDMPC_GLASS_OUTPUT_TAG=$tag \
    python -u /root/tdmpc_glass/helios-rl/scripts/run_benchmark.py --algos tdmpc2 \
      --tasks "$task" --total_steps "$steps" --seed "$seed" \
      --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 \
      --no_plot > "$EXP/logs/${tag}.log" 2>&1
  echo "[hb2] $tag rc=$? $(date -u +%FT%TZ)" >> "$EXP/hb2_driver.log"
}
run 0 HumanoidWalk 4000000 43 wallgen_hum4m_s43 &
run 1 HumanoidWalk 4000000 44 wallgen_hum4m_s44 &
run 2 HumanoidStand 1000000 41 wallgen_humstand_s41 &
wait
echo "HUMANOID_BOUNDARY2_DONE $(date -u +%FT%TZ)" > "$EXP/HUMANOID_BOUNDARY2_DONE"
