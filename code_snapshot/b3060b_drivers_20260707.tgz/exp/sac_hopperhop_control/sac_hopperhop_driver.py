"""Lean brax-SAC driver: off-policy model-free control for the HopperHop
exploration-wall flagship. Mirrors ppo_hopperhop_driver.py env loading EXACTLY
(mujoco_playground registry.load(..., config_overrides={"impl":"jax"}) +
wrapper.wrap_for_brax_training) so env parity with the PPO and TD-MPC2 arms is
byte-identical. Logs eval episode_reward vs env-steps to per-seed JSON.
NO checkpoints, NO videos.
"""
import argparse, functools, json, os, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="HopperHop")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--num_timesteps", type=int, default=5_000_000)
    ap.add_argument("--num_evals", type=int, default=26)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
    os.environ.setdefault("MUJOCO_GL", "egl")

    import jax
    import jax.numpy as jnp
    # Shim: brax 0.14.2 pmap path calls jax.device_put_replicated, removed in this jax.
    if not hasattr(jax, "device_put_replicated"):
        def _dpr(x, devices):
            n = len(devices)
            return jax.tree_util.tree_map(lambda a: jnp.stack([jnp.asarray(a)] * n), x)
        jax.device_put_replicated = _dpr
    from brax.training.agents.sac import networks as sac_networks
    from brax.training.agents.sac import train as sac
    from mujoco_playground import registry, wrapper
    from mujoco_playground.config import dm_control_suite_params

    os.makedirs(args.outdir, exist_ok=True)
    out_json = os.path.join(args.outdir, f"seed{args.seed}.json")

    env_cfg = registry.get_default_config(args.env)
    sac_params = dm_control_suite_params.brax_sac_config(args.env)
    # Audit (name-match check, cf. the PendulumSwingUp case-mismatch bug): the tuned
    # config bumps Hopper*-prefixed envs to num_timesteps=10_000_000. If the print
    # below shows 10000000 pre-override, the "HopperHop" branch fired correctly.
    print(f"[audit] brax_sac_config({args.env!r}) resolved (pre-override):", flush=True)
    print(sac_params, flush=True)
    sac_params.num_timesteps = args.num_timesteps
    sac_params.num_evals = args.num_evals
    print(f"[audit] post-override num_timesteps={sac_params.num_timesteps} "
          f"num_evals={sac_params.num_evals}", flush=True)

    env = registry.load(args.env, config=env_cfg, config_overrides={"impl": "jax"})
    eval_env = registry.load(args.env, config=registry.get_default_config(args.env), config_overrides={"impl": "jax"})

    training_params = dict(sac_params)
    network_factory = sac_networks.make_sac_networks
    if "network_factory" in training_params:
        network_factory = functools.partial(
            sac_networks.make_sac_networks, **training_params.pop("network_factory"))
    # brax 0.14.2 sac.train does not accept these mujoco_playground config keys
    # (verified against inspect.signature(sac.train)):
    for k in ("num_resets_per_eval", "num_eval_envs"):
        if k in training_params:
            print(f"[audit] dropping unsupported sac.train kwarg {k}={training_params.pop(k)}", flush=True)

    curve = []
    t0 = time.monotonic()
    record = {
        "algo": "brax_sac", "env": args.env, "seed": args.seed,
        "num_timesteps": args.num_timesteps, "num_evals": args.num_evals,
        "num_envs": int(sac_params.num_envs),
        "config": {k: (v if isinstance(v, (int, float, str, bool)) else str(v))
                   for k, v in dict(sac_params).items()},
        "curve": curve, "done": False,
    }
    def flush():
        with open(out_json, "w") as f:
            json.dump(record, f, indent=2)
    flush()

    def progress(num_steps, metrics):
        r = float(metrics.get("eval/episode_reward", float("nan")))
        rs = float(metrics.get("eval/episode_reward_std", float("nan")))
        wall = time.monotonic() - t0
        curve.append({"step": int(num_steps), "reward": r, "reward_std": rs,
                      "wall_s": round(wall, 1)})
        print(f"[SAC {args.env} s{args.seed}] {num_steps}: reward={r:.3f} "
              f"(+-{rs:.2f}) wall={wall:.0f}s", flush=True)
        flush()

    train_fn = functools.partial(
        sac.train, **training_params,
        network_factory=network_factory,
        seed=args.seed,
        wrap_env_fn=wrapper.wrap_for_brax_training,
    )
    make_inference_fn, params, metrics = train_fn(
        environment=env, eval_env=eval_env, progress_fn=progress)

    rewards = [c["reward"] for c in curve if c["reward"] == c["reward"]]
    record["peak_reward"] = max(rewards) if rewards else None
    record["final_reward"] = rewards[-1] if rewards else None
    record["total_wall_s"] = round(time.monotonic() - t0, 1)
    record["done"] = True
    flush()
    print(f"DONE seed{args.seed} peak={record['peak_reward']} final={record['final_reward']}", flush=True)

if __name__ == "__main__":
    main()
