#!/usr/bin/env bash
set -u
HOP=/root/tdmpc_glass/exp/sac_hopperhop_control
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$HOP/runs" "$HOP/logs"
run_chain() {
  local gpu=$1; shift
  for s in "$@"; do
    CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u "$HOP/sac_hopperhop_driver.py" --env HopperHop --seed "$s" \
        --num_timesteps 5000000 --num_evals 26 --outdir "$HOP/runs" \
        > "$HOP/logs/seed${s}.log" 2>&1
    echo "[s678] seed $s rc=$? $(date -u +%FT%TZ)" >> "$HOP/s678_driver.log"
  done
}
run_chain 2 6 8 &
run_chain 3 7 &
wait
echo "SAC5M_S678_DONE $(date -u +%FT%TZ)" > "$HOP/SAC5M_S678_DONE"
