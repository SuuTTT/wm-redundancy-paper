#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/sac_hopperhop_control
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
for s in 11 12; do
  CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.5 MUJOCO_GL=egl \
    python -u "$EXP/sac_hopperhop_driver.py" --env HopperHop --seed "$s" \
      --num_timesteps 20000000 --num_evals 40 --outdir "$EXP/runs_20M" \
      > "$EXP/logs/seed${s}_20M.log" 2>&1
  echo "[sac20] seed $s rc=$? $(date -u +%FT%TZ)"
done
echo "SAC20M_DONE $(date -u +%FT%TZ)" > "$EXP/SAC_20M_DONE"
