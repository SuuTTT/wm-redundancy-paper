#!/usr/bin/env bash
# SAC-on-HopperHop off-policy model-free control: 3 seeds SEQUENTIAL on GPU3.
# Gates on the ppo_wall_generalization BallInCup job currently occupying GPU3
# (it is the sweep's last task) so we never contend with / disturb it.
set -u
EXP=/root/tdmpc_glass/exp/sac_hopperhop_control
cd /root/tdmpc_glass || exit 1
source venv/bin/activate

gpu3_busy() {
  local p
  for p in $(pgrep -f "ppo_driver.py"); do
    if tr "\0" "\n" < /proc/$p/environ 2>/dev/null | grep -qx "CUDA_VISIBLE_DEVICES=3"; then
      return 0
    fi
  done
  return 1
}

echo "[sac driver] start $(date -u +%FT%TZ); waiting for GPU3 ppo_wall_generalization job to exit"
while gpu3_busy; do sleep 120; done
echo "[sac driver] GPU3 free at $(date -u +%FT%TZ); launching seeds 1 2 3 sequentially"

for s in 1 2 3; do
  CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.5 MUJOCO_GL=egl \
    python -u "$EXP/sac_hopperhop_driver.py" --env HopperHop --seed "$s" \
      --num_timesteps 5000000 --num_evals 26 --outdir "$EXP/runs" \
      > "$EXP/logs/seed${s}.log" 2>&1
  echo "[sac driver] seed $s exited rc=$? $(date -u +%FT%TZ)"
done

python - <<'PY' > "$EXP/SAC_CONTROL_DONE"
import json, glob
parts = []
for f in sorted(glob.glob("/root/tdmpc_glass/exp/sac_hopperhop_control/runs/seed*.json")):
    d = json.load(open(f))
    parts.append(f"seed{d['seed']}: peak={d.get('peak_reward')} final={d.get('final_reward')} done={d.get('done')}")
print("SAC_CONTROL_DONE HopperHop brax-SAC tuned-config 3x5M | " + " | ".join(parts))
PY
echo "[sac driver] DONE $(date -u +%FT%TZ)"
