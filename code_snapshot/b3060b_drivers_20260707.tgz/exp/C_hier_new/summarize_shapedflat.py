import json, glob
parts = []
for f in sorted(glob.glob("/root/tdmpc_glass/exp/C_hier_new/runs_shapedflat/*.json")):
    d = json.load(open(f))
    fin = d["curve"][-1]["success"] if d.get("curve") else None
    parts.append("s%s: final=%s best=%s" % (d.get("meta", {}).get("seed", d.get("seed")), fin, d.get("best")))
print("SHAPEDFLAT_DONE fourroom n=6 potential-shaping-to-true-goal | " + " | ".join(parts))
