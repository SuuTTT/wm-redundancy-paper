#!/usr/bin/env bash
# Shaped-flat control driver: fourroom, seeds 0-5 sequential, GPU3 (small footprint).
set -u
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
OUT=/root/tdmpc_glass/exp/C_hier_new/runs_shapedflat
LOGS=/root/tdmpc_glass/exp/C_hier_new/logs_shapedflat
mkdir -p "$OUT" "$LOGS"
for s in 0 1 2 3 4 5; do
  CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.15 \
    python -u exp/C_hier_new/shapedflat_maze.py --maze fourroom --seed "$s" \
      --steps 400000 --out_dir "$OUT" --tag shapedflat_control \
      > "$LOGS/seed${s}.log" 2>&1
  echo "[shapedflat driver] seed $s rc=$? $(date -u +%FT%TZ)"
done
python /root/tdmpc_glass/exp/C_hier_new/summarize_shapedflat.py > /root/tdmpc_glass/exp/C_hier_new/SHAPEDFLAT_DONE
echo "[shapedflat driver] DONE $(date -u +%FT%TZ)"
