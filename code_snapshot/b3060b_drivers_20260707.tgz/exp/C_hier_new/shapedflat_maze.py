#!/usr/bin/env python
"""
Shaped-flat CONTROL for the C_hier_new feudal-vs-flat fourroom positive.

Confound being tested: feudal's low level trains on dense self-generated
progress-to-subgoal shaping while flat trains sparse-only. This control runs
the flat TD3 arm UNCHANGED except the TRAINING reward is

    r_train = r_env + (prev_dist_to_TRUE_goal - cur_dist_to_TRUE_goal)

i.e. dense potential-based shaping toward the TRUE goal -- deliberately MORE
informed than feudal's self-generated subgoal signal (an UPPER BOUND on what
dense shaping alone can buy). Evaluation is IDENTICAL to the other arms:
deterministic, unshaped, success = dist <= goal_radius to the true goal.

If shaped-flat still fails fourroom -> the hierarchy claim firms.
If shaped-flat solves it            -> the positive re-attributes to dense shaping.

feudal_maze.py is imported, NOT modified. Everything else (nets 2x256, lr 3e-4,
gamma 0.99, expl_noise 0.2, start_random 5000, bs 256, eval 50 eps every 20k,
done-for-bootstrap only on true success) is byte-identical to train_flat.
"""
import os, sys, time, argparse
import numpy as np

sys.path.insert(0, "/root/tdmpc_glass/exp")
from feudal_maze import PointMaze, TD3, Replay, eval_flat, _dump


def train_shapedflat(env, seed, total_steps, out_path, meta, start_random=5000,
                     eval_every=20000, eval_eps=50, expl_noise=0.2, bs=256):
    # identical to feudal_maze.train_flat except r_train adds potential shaping
    obs_dim = 4; act_dim = 2
    agent = TD3(obs_dim, act_dim, seed)
    rb = Replay(obs_dim, act_dim)
    curve = []
    o = env.reset(); best = 0.0
    prev_dist = env.dist_to(env.goal)
    t0 = time.time()
    for step in range(1, total_steps + 1):
        if step < start_random:
            a = np.random.uniform(-1, 1, act_dim)
        else:
            a = agent.act(o, noise=expl_noise)
        o2, r, done, info = env.step(a)
        cur_dist = env.dist_to(env.goal)
        r_train = r + (prev_dist - cur_dist)  # dense potential-based shaping to TRUE goal (TRAIN ONLY)
        prev_dist = cur_dist
        rb.add(o, a, r_train, o2, float(info["success"]))  # done-for-bootstrap only on true success
        o = o2
        if done:
            o = env.reset()
            prev_dist = env.dist_to(env.goal)
        if step >= start_random and len(rb) >= bs:
            agent.update(rb.sample(bs))
        if step % eval_every == 0 or step == total_steps:
            sr, md = eval_flat(env, agent, eval_eps)  # UNSHAPED deterministic eval
            best = max(best, sr)
            curve.append({"step": step, "success": sr, "mean_dist": md,
                          "elapsed": round(time.time() - t0, 1)})
            _dump(out_path, meta, curve, best, final=(step == total_steps))
            print(f"[shapedflat s{seed} {meta['maze']}] step {step} succ {sr:.3f} "
                  f"best {best:.3f} ({time.time()-t0:.0f}s)", flush=True)
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--maze", choices=["room", "midroom", "bigroom", "corridor", "umaze", "fourroom"], default="fourroom")
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--steps", type=int, default=400000)
    ap.add_argument("--eval_every", type=int, default=20000)
    ap.add_argument("--out_dir", required=True)
    ap.add_argument("--tag", default="")
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    np.random.seed(args.seed)
    env = PointMaze(args.maze, seed=args.seed)
    meta = {
        "arm": "shapedflat", "maze": args.maze, "seed": args.seed,
        "total_steps": args.steps, "K": None,
        "shaping": "potential_based_to_true_goal(train_only;eval_unshaped)",
        "max_ep_steps": env.max_steps,
        "start": env.start.tolist(), "goal": env.goal.tolist(),
        "tag": args.tag,
    }
    name = f"shapedflat_{args.maze}_s{args.seed}"
    out_path = os.path.join(args.out_dir, name + ".json")
    print(f"START {name}: max_ep_steps={env.max_steps} start={env.start} goal={env.goal}", flush=True)
    train_shapedflat(env, args.seed, args.steps, out_path, meta,
                     eval_every=args.eval_every)
    print(f"DONE {name}", flush=True)


if __name__ == "__main__":
    main()
