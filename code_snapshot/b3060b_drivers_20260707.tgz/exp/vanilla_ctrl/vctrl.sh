#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/vanilla_ctrl
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
export PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo
run() { CUDA_VISIBLE_DEVICES=$1 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax TDMPC_GLASS_OUTPUT_TAG=vctrl_s$2 python -u /root/tdmpc_glass/helios-rl/scripts/run_benchmark.py --algos tdmpc2 --tasks HopperHop --total_steps 1000000 --seed $2 --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 --no_plot > $EXP/logs/seed$2.log 2>&1; echo "[vc] s$2 rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log; }
run 0 61 &
run 1 62 &
run 2 63 &
run 3 64 &
wait
echo DONE > $EXP/VCTRL_DONE
