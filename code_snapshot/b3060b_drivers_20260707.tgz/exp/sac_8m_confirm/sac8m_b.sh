#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/sac_8m_confirm
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
run() {
  CUDA_VISIBLE_DEVICES=$1 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py --env $2 --seed $3 --num_timesteps 8000000 --num_evals 26 --outdir $EXP/runs_$4 > $EXP/logs/$2_s$3.log 2>&1
  echo "[8mb] $2 s$3 rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log
}
run 0 HopperHop 53 hop &
run 1 HopperHop 54 hop &
run 2 HopperStand 53 stand &
run 3 HopperStand 54 stand &
wait
echo DONE > $EXP/SAC8M_B_DONE
