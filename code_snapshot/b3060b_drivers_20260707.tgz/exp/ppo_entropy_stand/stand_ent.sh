#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/ppo_entropy_stand
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
run() {
  CUDA_VISIBLE_DEVICES=$1 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl python -u /root/tdmpc_glass/exp/ppo_entropy_wall/ppo_entropy_driver.py --env HopperStand --seed $3 --entropy_mult $2 --num_timesteps 150000000 --num_evals 30 --outdir $EXP/runs > $EXP/logs/em$2_s$3.log 2>&1
  echo "[sent] em$2 s$3 rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log
}
run 0 3 41 &
run 1 3 42 &
run 2 10 41 &
run 3 10 42 &
wait
echo DONE > $EXP/STAND_ENT_DONE
