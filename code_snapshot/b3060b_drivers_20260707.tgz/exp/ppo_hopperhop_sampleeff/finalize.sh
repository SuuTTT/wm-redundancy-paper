#!/bin/bash
B=/root/tdmpc_glass/exp/ppo_hopperhop_sampleeff
while [ ! -f "$B/SWEEP_DONE" ]; do sleep 60; done
cd /root/tdmpc_glass && source venv/bin/activate
python "$B/analyze.py" > "$B/finalize.log" 2>&1
echo "finalized $(date -u +%FT%TZ)" >> "$B/finalize.log"
touch "$B/FINALIZE_DONE"
