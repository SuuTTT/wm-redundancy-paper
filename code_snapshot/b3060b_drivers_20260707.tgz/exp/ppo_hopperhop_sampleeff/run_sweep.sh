#!/bin/bash
# PPO-on-HopperHop: sample-efficiency-vs-exploration decider.
# Large-budget brax PPO (mujoco_playground DMControl tuned config), N seeds split
# across GPU2 and GPU3, logging real return-vs-env-steps JSON per seed.
# Writes DONE marker at end. NO checkpoints, NO videos, NO save_full_state.
set -u
BASE=/root/tdmpc_glass/exp/ppo_hopperhop_sampleeff
DRIVER=$BASE/ppo_hopperhop_driver.py
OUT=$BASE/runs
BUDGET=${BUDGET:-120000000}
NEVALS=${NEVALS:-49}
SEEDS=${SEEDS:-"1 2 3 4 5"}
DONE_MARKER=$BASE/SWEEP_DONE
mkdir -p "$OUT"
cd /root/tdmpc_glass || exit 1
source venv/bin/activate

launch () { # seed gpu
  local seed=$1 gpu=$2
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_MEM_FRACTION=.3 XLA_PYTHON_CLIENT_PREALLOCATE=false \
    python "$DRIVER" --env HopperHop --seed "$seed" \
      --num_timesteps "$BUDGET" --num_evals "$NEVALS" --outdir "$OUT" \
      > "$OUT/seed${seed}.log" 2>&1
}

# Round-robin seeds onto GPU 2 and 3; all concurrent (model is ~1.75GB each).
pids=()
i=0
for s in $SEEDS; do
  if [ $((i % 2)) -eq 0 ]; then g=2; else g=3; fi
  launch "$s" "$g" &
  pids+=($!)
  i=$((i+1))
  sleep 30   # stagger XLA compile to avoid simultaneous VRAM spikes
done

fail=0
for p in "${pids[@]}"; do
  wait "$p" || fail=1
done

echo "sweep_finished fail=$fail seeds=[$SEEDS] budget=$BUDGET $(date -u +%FT%TZ)" > "$DONE_MARKER"
