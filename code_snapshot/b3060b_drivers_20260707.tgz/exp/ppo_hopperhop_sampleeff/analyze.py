"""Aggregate PPO-HopperHop seeds -> summary.json + VERDICT.md.
Reads real return-vs-step curves from disk. TD-MPC2 published HopperHop ~367;
PPO published baseline ~33 (TD-MPC2 paper, dm_control). Decides: sample-efficiency
(PPO climbs toward ~367 given huge budget) vs exploration-wall (PPO plateaus).
"""
import glob, json, os

BASE = "/root/tdmpc_glass/exp/ppo_hopperhop_sampleeff"
OUT = os.path.join(BASE, "runs")
TDMPC2_HOPPERHOP = 367.0   # published TD-MPC2 ceiling (external anchor)
PPO_PAPER_BASELINE = 33.0  # published PPO baseline (external anchor)
THRESHOLDS = [33, 100, 200, 300, 367]

def crossing(curve, thr):
    for c in curve:
        if c["reward"] >= thr:
            return c["step"]
    return None

seeds = []
for f in sorted(glob.glob(os.path.join(OUT, "seed*.json"))):
    d = json.load(open(f))
    curve = [c for c in d.get("curve", []) if c["reward"] == c["reward"]]
    if not curve:
        continue
    rewards = [c["reward"] for c in curve]
    seeds.append({
        "seed": d["seed"],
        "done": d.get("done", False),
        "requested_budget": d["num_timesteps"],
        "actual_steps_reached": curve[-1]["step"],
        "num_envs": d.get("num_envs"),
        "peak_reward": max(rewards),
        "peak_step": curve[rewards.index(max(rewards))]["step"],
        "final_reward": rewards[-1],
        "crossings": {str(t): crossing(curve, t) for t in THRESHOLDS},
        "curve": curve,
    })

n = len(seeds)
peaks = [s["peak_reward"] for s in seeds]
finals = [s["final_reward"] for s in seeds]
max_steps = max((s["actual_steps_reached"] for s in seeds), default=0)
mean = lambda x: sum(x)/len(x) if x else None

# verdict logic
best_peak = max(peaks) if peaks else 0.0
reached_367 = any(s["crossings"]["367"] is not None for s in seeds)
reached_200 = any(s["crossings"]["200"] is not None for s in seeds)
reached_33  = any(s["crossings"]["33"] is not None for s in seeds)

if reached_367:
    verdict = "SAMPLE-EFFICIENCY"
    reason = ("PPO reaches TD-MPC2's ~367 ceiling given a large budget; "
              "TD-MPC2's advantage is sample-efficiency, not exploration.")
elif reached_200:
    verdict = "MOSTLY SAMPLE-EFFICIENCY (partial)"
    reason = ("PPO climbs well past the PPO=33 baseline toward the TD-MPC2 "
              "ceiling given a large budget, suggesting the gait is findable "
              "but very sample-inefficient for PPO.")
else:
    verdict = "EXPLORATION WALL"
    reason = (f"PPO plateaus far below TD-MPC2's ~367 (best peak {best_peak:.1f}) "
              f"even at {max_steps/1e6:.0f}M env-steps; PPO cannot find the hopping "
              "gait -- this is a genuine exploration failure, not mere inefficiency.")

summary = {
    "env": "HopperHop",
    "stack": "mujoco_playground DMControl + brax PPO 0.14.2 (JAX/MJX, 2048 envs, tuned dm_control_suite_params.brax_ppo_config)",
    "n_seeds": n,
    "requested_budget_per_seed": seeds[0]["requested_budget"] if seeds else None,
    "max_actual_steps_reached": max_steps,
    "external_anchor": {"tdmpc2_hopperhop": TDMPC2_HOPPERHOP,
                        "ppo_paper_baseline": PPO_PAPER_BASELINE},
    "peak_reward_mean": mean(peaks), "peak_reward_best": best_peak,
    "final_reward_mean": mean(finals),
    "any_seed_crossed": {"33": reached_33, "200": reached_200, "367": reached_367},
    "verdict": verdict, "reason": reason,
    "seeds": seeds,
}
with open(os.path.join(BASE, "summary.json"), "w") as f:
    json.dump(summary, f, indent=2)

lines = []
L = lines.append
L("# PPO-on-HopperHop: Sample-Efficiency vs Exploration-Wall\n")
L(f"**VERDICT: {verdict}**\n")
L(reason + "\n")
L("## Setup\n")
L(f"- Stack: {summary['stack']}")
L(f"- Env: HopperHop (dense shaped locomotion; raw episode return, max ~1000)")
L(f"- Seeds: n={n}; requested budget/seed={summary['requested_budget_per_seed']:,} "
  f"env-steps; max actual reached={max_steps:,}")
L(f"- External anchors (published TD-MPC2 paper, dm_control): "
  f"TD-MPC2 HopperHop ~{TDMPC2_HOPPERHOP:.0f} (in a few M steps), PPO ~{PPO_PAPER_BASELINE:.0f}\n")
L("## Per-seed results\n")
L("| seed | actual steps | peak | peak@step | final | crossed 33 | crossed 200 | crossed 367 |")
L("|------|-------------|------|-----------|-------|-----------|------------|------------|")
def fmt(x): return f"{x/1e6:.1f}M" if x is not None else "never"
for s in seeds:
    L(f"| {s['seed']} | {s['actual_steps_reached']/1e6:.0f}M | {s['peak_reward']:.1f} | "
      f"{s['peak_step']/1e6:.0f}M | {s['final_reward']:.1f} | "
      f"{fmt(s['crossings']['33'])} | {fmt(s['crossings']['200'])} | {fmt(s['crossings']['367'])} |")
L("")
L(f"- peak reward: mean={mean(peaks):.1f}, best={best_peak:.1f}")
L(f"- final reward: mean={mean(finals):.1f}\n")
L("## Interpretation\n")
L(f"TD-MPC2 reaches ~{TDMPC2_HOPPERHOP:.0f} on HopperHop within a few M env-steps. "
  f"Here PPO, given up to {max_steps/1e6:.0f}M env-steps (~{max_steps/5e6:.0f}x more), "
  f"peaks at only {best_peak:.1f}.")
L("")
L(reason)
open(os.path.join(BASE, "VERDICT.md"), "w").write("\n".join(lines))
print("Wrote summary.json and VERDICT.md")
print(f"n={n} verdict={verdict} best_peak={best_peak:.2f} max_steps={max_steps}")
for s in seeds:
    print(f"  seed{s['seed']}: peak={s['peak_reward']:.2f} final={s['final_reward']:.2f} "
          f"steps={s['actual_steps_reached']} done={s['done']}")
