"""Lean brax-PPO driver for HopperHop sample-efficiency-vs-exploration decider.
Logs eval episode_reward vs env-steps to per-seed JSON. NO checkpoints, NO videos.
"""
import argparse, functools, json, os, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="HopperHop")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--num_timesteps", type=int, default=60_000_000)
    ap.add_argument("--num_evals", type=int, default=31)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
    os.environ.setdefault("MUJOCO_GL", "egl")

    import jax
    import jax.numpy as jnp
    # Shim: brax 0.14.2 pmap path calls jax.device_put_replicated, removed in this jax.
    if not hasattr(jax, "device_put_replicated"):
        def _dpr(x, devices):
            n = len(devices)
            return jax.tree_util.tree_map(lambda a: jnp.stack([jnp.asarray(a)] * n), x)
        jax.device_put_replicated = _dpr
    from brax.training.agents.ppo import networks as ppo_networks
    from brax.training.agents.ppo import train as ppo
    from mujoco_playground import registry, wrapper
    from mujoco_playground.config import dm_control_suite_params

    os.makedirs(args.outdir, exist_ok=True)
    out_json = os.path.join(args.outdir, f"seed{args.seed}.json")

    env_cfg = registry.get_default_config(args.env)
    ppo_params = dm_control_suite_params.brax_ppo_config(args.env)
    if args.env == "PendulumSwingup":
        ppo_params.action_repeat = 4
        ppo_params.num_updates_per_batch = 4
        print("[fix] applied Pendulum tuned override (upstream case-bug workaround)", flush=True)
    ppo_params.num_timesteps = args.num_timesteps
    ppo_params.num_evals = args.num_evals

    env = registry.load(args.env, config=env_cfg, config_overrides={"impl": "jax"})
    eval_env = registry.load(args.env, config=registry.get_default_config(args.env), config_overrides={"impl": "jax"})

    training_params = dict(ppo_params)
    network_factory = ppo_networks.make_ppo_networks
    if "network_factory" in training_params:
        network_factory = functools.partial(
            ppo_networks.make_ppo_networks, **training_params.pop("network_factory"))
    num_eval_envs = training_params.pop("num_eval_envs", 128)

    curve = []
    t0 = time.monotonic()
    record = {
        "env": args.env, "seed": args.seed,
        "num_timesteps": args.num_timesteps, "num_evals": args.num_evals,
        "num_envs": int(ppo_params.num_envs),
        "config": {k: (float(v) if isinstance(v, float) else v)
                   for k, v in dict(ppo_params).items()
                   if isinstance(v, (int, float, str, bool))},
        "curve": curve, "done": False,
    }
    def flush():
        with open(out_json, "w") as f:
            json.dump(record, f, indent=2)
    flush()

    def progress(num_steps, metrics):
        r = float(metrics.get("eval/episode_reward", float("nan")))
        rs = float(metrics.get("eval/episode_reward_std", float("nan")))
        wall = time.monotonic() - t0
        curve.append({"step": int(num_steps), "reward": r, "reward_std": rs,
                      "wall_s": round(wall, 1)})
        print(f"[{args.env} s{args.seed}] {num_steps}: reward={r:.3f} "
              f"(+-{rs:.2f}) wall={wall:.0f}s", flush=True)
        flush()

    train_fn = functools.partial(
        ppo.train, **training_params,
        network_factory=network_factory,
        seed=args.seed,
        save_checkpoint_path=None,
        wrap_env_fn=wrapper.wrap_for_brax_training,
        num_eval_envs=num_eval_envs,
    )
    make_inference_fn, params, metrics = train_fn(
        environment=env, eval_env=eval_env, progress_fn=progress)

    rewards = [c["reward"] for c in curve if c["reward"] == c["reward"]]
    record["peak_reward"] = max(rewards) if rewards else None
    record["final_reward"] = rewards[-1] if rewards else None
    record["total_wall_s"] = round(time.monotonic() - t0, 1)
    record["done"] = True
    flush()
    print(f"DONE seed{args.seed} peak={record['peak_reward']} final={record['final_reward']}", flush=True)

if __name__ == "__main__":
    main()
