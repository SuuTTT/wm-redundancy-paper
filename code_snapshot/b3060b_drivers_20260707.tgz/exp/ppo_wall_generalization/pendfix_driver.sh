#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/ppo_wall_generalization
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$EXP/runs_pendfix" "$EXP/logs"
for s in 21 22; do
  CUDA_VISIBLE_DEVICES=1 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.5 MUJOCO_GL=egl \
    python -u "$EXP/pendulum_fixed_driver.py" --env PendulumSwingup --seed "$s" \
      --num_timesteps 60000000 --num_evals 30 --outdir "$EXP/runs_pendfix" \
      > "$EXP/logs/pendfix_seed${s}.log" 2>&1
  echo "[pendfix] seed $s rc=$? $(date -u +%FT%TZ)"
done
echo "PENDFIX_DONE $(date -u +%FT%TZ)" > "$EXP/PENDFIX_DONE"
