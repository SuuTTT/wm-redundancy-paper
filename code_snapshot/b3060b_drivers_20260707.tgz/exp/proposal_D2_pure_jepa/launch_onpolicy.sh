#!/bin/bash
# On-policy/narrow collapse test: train the SAME pure-JEPA `none` arm on each data buffer.
# Buffers (WalkerWalk): "" (broad-random) _online (broad-smooth) _onpolE _onpolF _narrowR
# Buffers (ReacherEasy): "" (broad-random) _onpolE _onpolF _narrowR
# arm = none only (the honest collapse control); simnorm in {0,1}; seeds {0,1}.
cd /root/tdmpc_glass/exp/proposal_D2_pure_jepa
PY=/root/tdmpc_glass/venv/bin/python
mkdir -p onpol_runs logs
JOBS=()
for dtag in "" _online _onpolE _onpolF _narrowR25 _narrowR10 _narrowR05 _narrowR02; do
  for sn in 0 1; do
    for s in 0 1; do
      JOBS+=("WalkerWalk $dtag $sn $s")
    done
  done
done
for dtag in "" _onpolE _onpolF _narrowR25 _narrowR10 _narrowR05 _narrowR02; do
  for sn in 0 1; do
    for s in 0 1; do
      JOBS+=("ReacherEasy $dtag $sn $s")
    done
  done
done
i=0
for job in "${JOBS[@]}"; do
  set -- $job; task=$1; dtag=$2; sn=$3; seed=$4
  [ "$dtag" = "-" ] && dtag=""
  gpu=$((i % 4))
  tag="${task}${dtag}_none_sn${sn}_s${seed}"
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_MEM_FRACTION=0.22 \
    $PY pure_jepa_ext.py train --task $task --cond none --seed $seed --simnorm $sn \
       --gpu $gpu --datatag "$dtag" --outdir onpol_runs \
    > logs/onpol_$tag.log 2>&1 &
  i=$((i+1))
  if (( i % 4 == 0 )); then wait; fi
done
wait
echo "ALL_DONE_ONPOL"
