"""On-policy / narrow-distribution data generator for the pure-JEPA collapse test (Proposal D2, Thread-D open cell).

THE OPEN QUESTION: broad OFFLINE data (random + smooth) does NOT collapse a pure JEPA
(D2 / D2-ext, verified). But the earlier nav H-JEPA DID collapse. Leading hypothesis:
NARROW, reward-optimizing, ON-POLICY data is the true collapse driver.

This script produces the DATA feeds only; the pure-JEPA encoder is trained UNCHANGED by
`pure_jepa_ext.py train` (encoder + jumpy predictor + EMA target; latent self-prediction
ONLY; NO reward/value/policy loss in the encoder -> encoder stays PURE). The reward-seeking
policy is a SEPARATE linear ARS policy on RAW obs; it never touches the encoder.

Buffers written (same npz schema as D2: O,A,O2,G,R,RTG,obs_dim,act_dim), plus a *_stats.json
recording narrowness (raw-obs eff_rank, per-dim std, RTG mean/std, raw-obs linear R^2 upper
bounds) so every narrowness number is read from disk.

Arms of narrowness (WIDTH sweep, from wide to narrow):
  broad-random   : existing data_<task>.npz               (iid random policy, widest)
  broad-smooth   : existing data_<task>_online.npz         (temporally-correlated random walk)
  onpolE (_onpolE): rollouts of an EARLY ARS snapshot        (partially reward-seeking, medium)
  onpolF (_onpolF): rollouts of the CONVERGED ARS policy     (reward-seeking, narrow gait manifold)
  narrowR (_narrowR): broad-random subsampled to a ball around a random anchor
                      -> REWARD-AGNOSTIC narrow control (isolates width from reward-seeking)

How on-policy is _onpolF really? It is the deterministic rollout of a single reward-optimizing
policy that was refit (ARS is an on-policy evolution-strategy: each iteration re-fits the policy
to returns of ITS OWN current rollouts) -> genuinely on-policy & self-reinforcing. It is NOT a
value-bootstrapped RL agent, and the encoder never shapes the policy, so the encoder is pure.
Reported honestly: ARS return curve + realized narrowing (raw eff_rank drop).
"""
from __future__ import annotations
import argparse, json, os, sys, time
from pathlib import Path
import numpy as np

HELIOS = Path("/root/tdmpc_glass/helios-rl")
sys.path.insert(0, str(HELIOS / "src"))
sys.path.insert(0, "/root/tdmpc_glass/mujoco_playground_repo")
sys.path.insert(0, "/root/tdmpc_glass/selib")
sys.path.insert(0, "/root/tdmpc_glass/exp/proposal_D2_pure_jepa")

ROOT = Path("/root/tdmpc_glass/exp/proposal_D2_pure_jepa")
GAMMA = 0.97


def make_env(task):
    from mujoco_playground import registry, wrapper
    env = registry.load(task, config_overrides={"impl": "jax"})
    env = wrapper.wrap_for_brax_training(env, episode_length=1000, action_repeat=1)
    return env


def eff_rank(Z):
    Z = np.asarray(Z, np.float64)
    n = Z.shape[0]
    Zc = Z - Z.mean(0, keepdims=True)
    cov = (Zc.T @ Zc) / max(n - 1, 1)
    ev = np.clip(np.linalg.eigvalsh(cov), 0, None); s = ev.sum()
    return float((s * s) / (np.square(ev).sum() + 1e-12)) if s > 0 else 0.0


def ridge_r2(Ztr, Ytr, Zte, Yte, alpha=1.0):
    n = Ztr.shape[0]
    Zc = np.concatenate([Ztr, np.ones((n, 1))], 1)
    Zce = np.concatenate([Zte, np.ones((Zte.shape[0], 1))], 1)
    A = Zc.T @ Zc
    reg = alpha * np.eye(A.shape[0]); reg[-1, -1] = 0.0
    W = np.linalg.solve(A + reg, Zc.T @ Ytr)
    pred = Zce @ W
    ss_res = ((Yte - pred) ** 2).sum(0)
    ss_tot = ((Yte - Yte.mean(0)) ** 2).sum(0) + 1e-12
    return float(np.mean(1.0 - ss_res / ss_tot))


def buffer_stats(O, G, RTG):
    N = O.shape[0]
    rng = np.random.default_rng(0)
    perm = rng.permutation(N); ntr = int(0.85 * N); tr, te = perm[:ntr], perm[ntr:]
    return {
        "N": int(N),
        "raw_eff_rank": eff_rank(O),
        "raw_std_mean": float(O.std(0).mean()),
        "rtg_mean": float(RTG.mean()), "rtg_std": float(RTG.std()),
        "raw_geom_r2": ridge_r2(O[tr], G[tr], O[te], G[te]),
        "raw_value_r2": ridge_r2(O[tr], RTG[tr].reshape(-1, 1), O[te], RTG[te].reshape(-1, 1)),
    }


def _finalize_and_save(task, datatag, O, A, O2, R, D, G, obs_dim, act_dim, extra=None):
    # discounted RTG backward, reset at episode boundary; then flatten + drop boundary transitions
    T, ne = R.shape
    RTG = np.zeros_like(R); running = np.zeros(ne, np.float32)
    for t in range(T - 1, -1, -1):
        running = R[t] + GAMMA * running * (1.0 - D[t]); RTG[t] = running
    flat = lambda x: x.reshape(T * ne, -1) if x.ndim == 3 else x.reshape(T * ne)
    O, A, O2, G = flat(O), flat(A), flat(O2), flat(G)
    R, D, RTG = flat(R), flat(D), flat(RTG)
    keep = D < 0.5
    O, A, O2, G, R, RTG = O[keep], A[keep], O2[keep], G[keep], R[keep], RTG[keep]
    fn = ROOT / f"data_{task}{datatag}.npz"
    np.savez_compressed(fn, O=O.astype(np.float32), A=A.astype(np.float32),
                        O2=O2.astype(np.float32), G=G.astype(np.float32),
                        R=R.astype(np.float32), RTG=RTG.astype(np.float32),
                        obs_dim=obs_dim, act_dim=act_dim)
    st = buffer_stats(O, G, RTG)
    if extra:
        st.update(extra)
    (ROOT / f"data_{task}{datatag}_stats.json").write_text(json.dumps(st, indent=2))
    print(f"[save {task}{datatag}] N={O.shape[0]} raw_eff_rank={st['raw_eff_rank']:.2f} "
          f"rtg_mean={st['rtg_mean']:.2f} raw_geomR2={st['raw_geom_r2']:.3f} "
          f"raw_valR2={st['raw_value_r2']:.3f}", flush=True)
    return st


# ---------------------------------------------------------------------------
# ARS: linear reward-seeking policy on RAW obs (v2 with obs normalization).
# On-policy evolution strategy: each iter re-fits M to returns of its OWN rollouts.
# ---------------------------------------------------------------------------
def ars_train(task, iters=40, n_dirs=16, top_b=8, alpha=0.04, noise=0.06, seed=0):
    import jax, jax.numpy as jnp
    env = make_env(task)
    obs_dim, act_dim = int(env.observation_size), int(env.action_size)
    _reset = jax.jit(env.reset); _step = jax.jit(env.step)
    ne = 2 * n_dirs
    rng = np.random.default_rng(seed)
    M = np.zeros((act_dim, obs_dim), np.float32)
    mean = np.zeros(obs_dim, np.float64); m2 = np.ones(obs_dim, np.float64); cnt = 1.0

    def rollout(Ms, key, mean, std, T=1000):
        # Ms: (ne, act, obs). Each env uses its own policy. Returns per-env total reward + visited obs.
        st = _reset(jax.random.split(key, ne))
        Ms_j = jnp.asarray(Ms); mean_j = jnp.asarray(mean.astype(np.float32)); std_j = jnp.asarray(std.astype(np.float32))
        tot = jnp.zeros(ne); visited = []
        for t in range(T):
            o = st.obs
            a = jnp.einsum('eao,eo->ea', Ms_j, (o - mean_j) / std_j)
            a = jnp.clip(a, -1.0, 1.0)
            st = _step(st, a)
            tot = tot + st.reward
            if t % 25 == 0:
                visited.append(np.asarray(o))
        return np.asarray(tot), np.concatenate(visited, 0)

    curve = []
    snaps = {}
    snap_iters = {max(1, iters // 3): "E", iters - 1: "F"}
    t0 = time.time()
    for it in range(iters):
        deltas = rng.standard_normal((n_dirs, act_dim, obs_dim)).astype(np.float32)
        std = np.sqrt(m2 / cnt) + 1e-6
        Ms = np.concatenate([M[None] + noise * deltas, M[None] - noise * deltas], 0)
        key = jax.random.PRNGKey(seed * 1000 + it)
        returns, vis = rollout(Ms, key, mean, std)
        r_plus, r_minus = returns[:n_dirs], returns[n_dirs:]
        # update running obs stats (Welford, batched)
        for row in vis[::7]:
            cnt += 1.0; delta = row - mean; mean += delta / cnt; m2 += delta * (row - mean)
        # ARS update: top-b directions by max(+,-)
        scores = np.maximum(r_plus, r_minus)
        idx = np.argsort(-scores)[:top_b]
        used = np.concatenate([r_plus[idx], r_minus[idx]])
        sigma_r = used.std() + 1e-6
        grad = np.zeros_like(M)
        for j in idx:
            grad += (r_plus[j] - r_minus[j]) * deltas[j]
        M = M + (alpha / (top_b * sigma_r)) * grad
        curve.append(float(returns.mean()))
        if it in snap_iters:
            snaps[snap_iters[it]] = (M.copy(), mean.copy(), std.copy())
        print(f"[ARS {task}] it={it} ret_mean={returns.mean():.1f} ret_max={returns.max():.1f} "
              f"{time.time()-t0:.0f}s", flush=True)
    if "E" not in snaps:  # tiny iters fallback
        snaps["E"] = (M.copy(), mean.copy(), np.sqrt(m2 / cnt) + 1e-6)
    if "F" not in snaps:
        snaps["F"] = (M.copy(), mean.copy(), np.sqrt(m2 / cnt) + 1e-6)
    return snaps, curve, obs_dim, act_dim


def collect_policy(task, M, mean, std, datatag, n_steps=2500, num_envs=16, seed=123, extra=None):
    import jax, jax.numpy as jnp
    env = make_env(task)
    obs_dim, act_dim = int(env.observation_size), int(env.action_size)
    _reset = jax.jit(env.reset); _step = jax.jit(env.step)
    key = jax.random.PRNGKey(seed); key, rk = jax.random.split(key)
    st = _reset(jax.random.split(rk, num_envs))
    M_j = jnp.asarray(M); mean_j = jnp.asarray(mean.astype(np.float32)); std_j = jnp.asarray(std.astype(np.float32))
    O, A, O2, R, D, G = [], [], [], [], [], []
    for t in range(n_steps):
        o = st.obs
        a = jnp.clip(jnp.einsum('ao,eo->ea', M_j, (o - mean_j) / std_j), -1.0, 1.0)
        qpos = np.asarray(st.data.qpos)
        nst = _step(st, a)
        O.append(np.asarray(o)); A.append(np.asarray(a)); O2.append(np.asarray(nst.obs))
        R.append(np.asarray(nst.reward).astype(np.float32)); D.append(np.asarray(nst.done).astype(np.float32))
        G.append(qpos.astype(np.float32))
        st = nst
    O = np.stack(O); A = np.stack(A); O2 = np.stack(O2); R = np.stack(R); D = np.stack(D); G = np.stack(G)
    return _finalize_and_save(task, datatag, O, A, O2, R, D, G, obs_dim, act_dim, extra=extra)


def make_narrowR(task, target_frac, tag, seed=0):
    """Reward-AGNOSTIC narrow control: subsample broad-random buffer to a ball around a random
    anchor state (in z-scored obs), keeping the closest `target_frac`. Isolates WIDTH from reward.
    Uses a DENSITY-peak anchor (a real data point with many near neighbours) so small fracs give a
    genuinely tight cluster -> low raw eff_rank."""
    d = np.load(ROOT / f"data_{task}.npz")
    O, A, O2, G, R, RTG = d["O"], d["A"], d["O2"], d["G"], d["R"], d["RTG"]
    obs_dim, act_dim = int(d["obs_dim"]), int(d["act_dim"])
    mu = O.mean(0); sd = O.std(0) + 1e-6
    Oz = (O - mu) / sd
    rng = np.random.default_rng(seed)
    # density-peak anchor: among a random candidate set, pick the point with the smallest
    # radius to its k-th nearest neighbour (densest neighbourhood) -> tightest achievable ball.
    cand = rng.choice(O.shape[0], size=min(400, O.shape[0]), replace=False)
    k = max(50, int(target_frac * O.shape[0]))
    best, best_r = cand[0], 1e18
    for c in cand:
        dd = np.partition(np.linalg.norm(Oz - Oz[c], axis=1), k)[:k].max()
        if dd < best_r:
            best_r, best = dd, c
    dist = np.linalg.norm(Oz - Oz[best], axis=1)
    keep = np.argsort(dist)[:k]
    O, A, O2, G, R, RTG = O[keep], A[keep], O2[keep], G[keep], R[keep], RTG[keep]
    fn = ROOT / f"data_{task}_{tag}.npz"
    np.savez_compressed(fn, O=O.astype(np.float32), A=A.astype(np.float32), O2=O2.astype(np.float32),
                        G=G.astype(np.float32), R=R.astype(np.float32), RTG=RTG.astype(np.float32),
                        obs_dim=obs_dim, act_dim=act_dim)
    st = buffer_stats(O, G, RTG); st["note"] = f"reward-agnostic narrow (frac={target_frac}) of broad-random"
    (ROOT / f"data_{task}_{tag}_stats.json").write_text(json.dumps(st, indent=2))
    print(f"[save {task}_{tag}] frac={target_frac} N={O.shape[0]} raw_eff_rank={st['raw_eff_rank']:.2f} "
          f"raw_geomR2={st['raw_geom_r2']:.3f} raw_valR2={st['raw_value_r2']:.3f}", flush=True)
    return st


def broad_stats(task, datatag=""):
    d = np.load(ROOT / f"data_{task}{datatag}.npz")
    st = buffer_stats(d["O"], d["G"], d["RTG"])
    (ROOT / f"data_{task}{datatag}_stats.json").write_text(json.dumps(st, indent=2))
    print(f"[stats {task}{datatag}] N={st['N']} raw_eff_rank={st['raw_eff_rank']:.2f} "
          f"rtg_mean={st['rtg_mean']:.2f} raw_geomR2={st['raw_geom_r2']:.3f} raw_valR2={st['raw_value_r2']:.3f}", flush=True)
    return st


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["gen", "stats"])
    ap.add_argument("--task", default="WalkerWalk")
    ap.add_argument("--iters", type=int, default=25)
    ap.add_argument("--gpu", type=int, default=0)
    args = ap.parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    os.environ["XLA_PYTHON_CLIENT_MEM_FRACTION"] = "0.30"
    if args.mode == "stats":
        broad_stats(args.task, "")
        broad_stats(args.task, "_online")
        return
    # 1. reward-seeking ARS policy (separate from encoder)
    snaps, curve, obs_dim, act_dim = ars_train(args.task, iters=args.iters, seed=0)
    ME, meanE, stdE = snaps["E"]; MF, meanF, stdF = snaps["F"]
    ars_info = {"return_curve": curve, "ret_start": curve[0], "ret_end": curve[-1],
                "ret_max": float(np.max(curve))}
    # 2. on-policy buffers (early = wider, final = narrow gait manifold)
    stE = collect_policy(args.task, ME, meanE, stdE, "_onpolE", extra={"ars": ars_info, "snap": "early"})
    stF = collect_policy(args.task, MF, meanF, stdF, "_onpolF", extra={"ars": ars_info, "snap": "final"})
    # 3. reward-agnostic narrow WIDTH SWEEP (the decisive knob)
    sweep = {}
    for frac, tag in [(0.02, "narrowR02"), (0.05, "narrowR05"), (0.10, "narrowR10"), (0.25, "narrowR25")]:
        sweep[tag] = make_narrowR(args.task, frac, tag)
    # 4. broad reference stats
    stB = broad_stats(args.task, "")
    out = {"task": args.task, "ars": ars_info, "broad": stB, "onpolE": stE, "onpolF": stF, "sweep": sweep}
    (ROOT / f"gen_{args.task}.json").write_text(json.dumps(out, indent=2))
    print(f"[GEN DONE {args.task}] ARS ret {curve[0]:.0f}->{curve[-1]:.0f} | "
          f"eff_rank broad={stB['raw_eff_rank']:.1f} onpolE={stE['raw_eff_rank']:.1f} "
          f"onpolF={stF['raw_eff_rank']:.1f} | sweep_eff_rank="
          + ",".join(f"{t}={v['raw_eff_rank']:.1f}" for t, v in sweep.items()), flush=True)


if __name__ == "__main__":
    main()
