#!/bin/bash
cd /root/tdmpc_glass/exp/proposal_D2_pure_jepa
# 1) wait for data-gen to finish
while pgrep -f "pure_jepa_onpolicy.py gen" >/dev/null; do sleep 20; done
echo "GEN_DONE $(date)" >> drive_onpolicy.log
# 2) train grid (self-manages concurrency, ends ALL_DONE_ONPOL)
bash launch_onpolicy.sh >> drive_onpolicy.log 2>&1
# 3) aggregate
/root/tdmpc_glass/venv/bin/python agg_onpolicy.py > onpolicy_summary.txt 2>> drive_onpolicy.log
echo "DRIVE_DONE $(date)" >> drive_onpolicy.log
