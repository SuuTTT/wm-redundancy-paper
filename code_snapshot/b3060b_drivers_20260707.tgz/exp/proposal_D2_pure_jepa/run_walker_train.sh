#!/bin/bash
cd /root/tdmpc_glass/exp/proposal_D2_pure_jepa
PY=/root/tdmpc_glass/venv/bin/python
mkdir -p onpol_runs logs
GPUS=(0 2 3)
JOBS=()
for dtag in "" _online _onpolE _onpolF _narrowR25 _narrowR10 _narrowR05 _narrowR02; do
  for sn in 0 1; do for s in 0 1; do JOBS+=("$dtag $sn $s"); done; done
done
i=0
for job in "${JOBS[@]}"; do
  set -- $job; dtag=$1; sn=$2; seed=$3; [ "$dtag" = "-" ] && dtag=""
  gpu=${GPUS[$((i % 3))]}
  tag="WalkerWalk${dtag}_none_sn${sn}_s${seed}"
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_MEM_FRACTION=0.20 \
    $PY pure_jepa_ext.py train --task WalkerWalk --cond none --seed $seed --simnorm $sn \
       --gpu $gpu --datatag "$dtag" --outdir onpol_runs > logs/onpol_$tag.log 2>&1 &
  i=$((i+1))
  if (( i % 3 == 0 )); then wait; fi
done
wait
echo "WALKER_TRAIN_DONE"
