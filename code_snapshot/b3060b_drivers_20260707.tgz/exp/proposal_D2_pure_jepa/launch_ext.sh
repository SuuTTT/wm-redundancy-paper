#!/bin/bash
# D2-EXT: 3-task fixed-lambda pure-JEPA grid + online-data probe.
# GPU FIX: pass --gpu $gpu so each process masks to its OWN physical GPU
# (old bug: env CUDA_VISIBLE_DEVICES was clobbered by hardcoded --gpu 0).
cd /root/tdmpc_glass/exp/proposal_D2_pure_jepa
PY=/root/tdmpc_glass/venv/bin/python
mkdir -p logs ext
JOBS=()
# 3 tasks x fixed-lambda arms x 3 seeds. arm encoded as cond|lamflag
# lamflag: for uniformity=0.5, vicreg=1.0 (via --lam); se via se_fixed --lam_se
for task in WalkerWalk CheetahRun ReacherEasy; do
  for s in 0 1 2; do
    JOBS+=("$task none 1.0 - $s ")
    JOBS+=("$task uniformity 0.5 - $s ")
    JOBS+=("$task vicreg 1.0 - $s ")
    JOBS+=("$task se_fixed 1.0 0.3 $s ")
    JOBS+=("$task se_fixed 1.0 1.0 $s ")
  done
done
# online-data probe on WalkerWalk (datatag _online): all 5 arms x 3 seeds
for s in 0 1 2; do
  JOBS+=("WalkerWalk none 1.0 - $s _online")
  JOBS+=("WalkerWalk uniformity 0.5 - $s _online")
  JOBS+=("WalkerWalk vicreg 1.0 - $s _online")
  JOBS+=("WalkerWalk se_fixed 1.0 0.3 $s _online")
  JOBS+=("WalkerWalk se_fixed 1.0 1.0 $s _online")
done

i=0
for job in "${JOBS[@]}"; do
  set -- $job; task=$1; cond=$2; lam=$3; lamse=$4; seed=$5; dtag=${6:-}
  gpu=$((i % 4))
  [ "$lamse" = "-" ] && lamse=1.0
  tag="${task}${dtag}_${cond}_lamse${lamse}_lam${lam}_s${seed}"
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_MEM_FRACTION=0.22 \
    $PY pure_jepa_ext.py train --task $task --cond $cond --seed $seed --simnorm 1 \
       --gpu $gpu --lam $lam --lam_se $lamse --datatag "$dtag" --outdir ext \
    > logs/ext_$tag.log 2>&1 &
  i=$((i+1))
  if (( i % 4 == 0 )); then wait; fi
done
wait
echo "ALL_DONE_EXT"
