"""Aggregate the on-policy / narrow-width pure-JEPA collapse test. Every number read from disk."""
import json, sys
from pathlib import Path
import numpy as np

ROOT = Path("/root/tdmpc_glass/exp/proposal_D2_pure_jepa")
RUNS = ROOT / "onpol_runs"

WALKER = ["", "_online", "_onpolE", "_onpolF", "_narrowR25", "_narrowR10", "_narrowR05", "_narrowR02"]
REACHER = ["", "_onpolE", "_onpolF", "_narrowR25", "_narrowR10", "_narrowR05", "_narrowR02"]
TASKS = {"WalkerWalk": WALKER, "ReacherEasy": REACHER}
LABEL = {"": "broad-random", "_online": "broad-smooth", "_onpolE": "onpol-early(ARS)",
         "_onpolF": "onpol-final(ARS)", "_narrowR25": "narrowR frac.25", "_narrowR10": "narrowR frac.10",
         "_narrowR05": "narrowR frac.05", "_narrowR02": "narrowR frac.02"}


def eff_rank(Z):
    Z = np.asarray(Z, np.float64); n = Z.shape[0]
    Zc = Z - Z.mean(0, keepdims=True); cov = (Zc.T @ Zc) / max(n - 1, 1)
    ev = np.clip(np.linalg.eigvalsh(cov), 0, None); s = ev.sum()
    return float((s * s) / (np.square(ev).sum() + 1e-12)) if s > 0 else 0.0


def ridge_r2(Ztr, Ytr, Zte, Yte, alpha=1.0):
    n = Ztr.shape[0]
    Zc = np.concatenate([Ztr, np.ones((n, 1))], 1); Zce = np.concatenate([Zte, np.ones((Zte.shape[0], 1))], 1)
    A = Zc.T @ Zc; reg = alpha * np.eye(A.shape[0]); reg[-1, -1] = 0.0
    W = np.linalg.solve(A + reg, Zc.T @ Ytr); pred = Zce @ W
    ss_res = ((Yte - pred) ** 2).sum(0); ss_tot = ((Yte - Yte.mean(0)) ** 2).sum(0) + 1e-12
    return float(np.mean(1.0 - ss_res / ss_tot))


def raw_baseline(task, tag):
    d = np.load(ROOT / f"data_{task}{tag}.npz")
    O, G, RTG = d["O"], d["G"], d["RTG"]
    N = O.shape[0]; rng = np.random.default_rng(0); perm = rng.permutation(N); nt = int(0.85 * N)
    tr, te = perm[:nt], perm[nt:]
    return {"N": int(N), "raw_eff_rank": eff_rank(O),
            "raw_geom_r2": ridge_r2(O[tr], G[tr], O[te], G[te]),
            "raw_value_r2": ridge_r2(O[tr], RTG[tr].reshape(-1, 1), O[te], RTG[te].reshape(-1, 1)),
            "rtg_mean": float(RTG.mean()), "rtg_std": float(RTG.std())}


def collect(task, tag, sn):
    ers, gs, vs = [], [], []
    for seed in [0, 1]:
        f = RUNS / f"run_{task}{tag}_none_sn{sn}_seed{seed}.json"
        if not f.exists():
            continue
        r = json.loads(f.read_text())
        ers.append(r["eff_rank"]); gs.append(r["geom_r2"]); vs.append(r["value_r2"])
    def ms(x): return [round(float(np.mean(x)), 4), round(float(np.std(x)), 4), len(x)] if x else [None, None, 0]
    return {"eff_rank": ms(ers), "geom_r2": ms(gs), "value_r2": ms(vs)}


summary = {}
for task, tags in TASKS.items():
    genf = ROOT / f"gen_{task}.json"
    gen = json.loads(genf.read_text()) if genf.exists() else {}
    summary[task] = {"ars": gen.get("ars"), "buffers": {}}
    for tag in tags:
        if not (ROOT / f"data_{task}{tag}.npz").exists():
            continue
        rb = raw_baseline(task, tag)
        row = {"label": LABEL.get(tag, tag), "raw": rb,
               "sn0": collect(task, tag, 0), "sn1": collect(task, tag, 1)}
        summary[task]["buffers"][tag or "broad"] = row

(ROOT / "onpolicy_summary.json").write_text(json.dumps(summary, indent=2))

# print table
for task, td in summary.items():
    ars = td.get("ars")
    if ars:
        print(f"\n### {task}  (ARS return {ars['ret_start']:.0f} -> {ars['ret_end']:.0f}, max {ars['ret_max']:.0f})")
    else:
        print(f"\n### {task}")
    print(f"{'buffer':<20}{'rawER':>7}{'rawG':>7}{'rawV':>7} | "
          f"{'sn0:ER':>8}{'G':>7}{'V':>7} | {'sn1:ER':>8}{'G':>7}{'V':>7}")
    for tag, row in td["buffers"].items():
        rb = row["raw"]
        def g(d, k):
            m = d[k][0]; return f"{m:.2f}" if m is not None else "  -  "
        print(f"{row['label']:<20}{rb['raw_eff_rank']:>7.2f}{rb['raw_geom_r2']:>7.2f}{rb['raw_value_r2']:>7.2f} | "
              f"{g(row['sn0'],'eff_rank'):>8}{g(row['sn0'],'geom_r2'):>7}{g(row['sn0'],'value_r2'):>7} | "
              f"{g(row['sn1'],'eff_rank'):>8}{g(row['sn1'],'geom_r2'):>7}{g(row['sn1'],'value_r2'):>7}")
print("\nwrote onpolicy_summary.json")
