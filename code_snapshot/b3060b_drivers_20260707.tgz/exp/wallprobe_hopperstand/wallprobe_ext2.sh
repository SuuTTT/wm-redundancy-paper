#!/usr/bin/env bash
# Wall-probe extension 2: sharpen the escape/solve RATE estimates in Part 9's graded-barrier framing.
# GPU0: PPO Stand seeds 45,46 sequential; GPU1: PPO Stand seeds 47,48 sequential (rate n=4 -> n=8);
# GPU2: SAC Stand seeds 45,46 sequential (rate n=4 -> n=6); GPU3: SAC HopperHop seeds 4,5 (escape n=3 -> n=5).
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
HOP=/root/tdmpc_glass/exp/sac_hopperhop_control
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$EXP/logs" "$EXP/runs_ppo" "$EXP/runs_sac" "$HOP/runs" "$HOP/logs"

ppo_chain() {
  local gpu=$1; shift
  for s in "$@"; do
    CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py \
        --env HopperStand --seed "$s" --num_timesteps 120000000 --num_evals 30 \
        --outdir "$EXP/runs_ppo" > "$EXP/logs/ppo_seed${s}.log" 2>&1
    echo "[ext2] ppo stand seed $s rc=$? $(date -u +%FT%TZ)" >> "$EXP/ext2_driver.log"
  done
}
sac_stand_chain() {
  for s in 45 46; do
    CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py \
        --env HopperStand --seed "$s" --num_timesteps 5000000 --num_evals 26 \
        --outdir "$EXP/runs_sac" > "$EXP/logs/sac_seed${s}.log" 2>&1
    echo "[ext2] sac stand seed $s rc=$? $(date -u +%FT%TZ)" >> "$EXP/ext2_driver.log"
  done
}
sac_hop_chain() {
  for s in 4 5; do
    CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py \
        --env HopperHop --seed "$s" --num_timesteps 5000000 --num_evals 26 \
        --outdir "$HOP/runs" > "$HOP/logs/seed${s}.log" 2>&1
    echo "[ext2] sac hop seed $s rc=$? $(date -u +%FT%TZ)" >> "$EXP/ext2_driver.log"
  done
}
ppo_chain 0 45 46 &
ppo_chain 1 47 48 &
sac_stand_chain &
sac_hop_chain &
wait
echo "WALLPROBE_EXT2_DONE $(date -u +%FT%TZ)" > "$EXP/WALLPROBE_EXT2_DONE"
