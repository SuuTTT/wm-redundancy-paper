#!/usr/bin/env bash
# Rate-hardening on b3060b: PPO HopperStand seeds 49-56 at FULL 285M (escape rate n=8->16),
# then SAC HopperStand seeds 47-50 (solve rate n=6->10). One chain per GPU.
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$EXP/logs" "$EXP/runs_ppo" "$EXP/runs_sac"
chain() {
  local gpu=$1 p1=$2 p2=$3 s1=$4
  for s in $p1 $p2; do
    CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py \
        --env HopperStand --seed "$s" --num_timesteps 285000000 --num_evals 30 \
        --outdir "$EXP/runs_ppo" > "$EXP/logs/ppo_seed${s}.log" 2>&1
    echo "[rh] ppo s$s rc=$? $(date -u +%FT%TZ)" >> "$EXP/rh_driver.log"
  done
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
    python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py \
      --env HopperStand --seed "$s1" --num_timesteps 5000000 --num_evals 26 \
      --outdir "$EXP/runs_sac" > "$EXP/logs/sac_seed${s1}.log" 2>&1
  echo "[rh] sac s$s1 rc=$? $(date -u +%FT%TZ)" >> "$EXP/rh_driver.log"
}
chain 0 49 50 47 &
chain 1 51 52 48 &
chain 2 53 54 49 &
chain 3 55 56 50 &
wait
echo "RATE_HARDEN_DONE $(date -u +%FT%TZ)" > "$EXP/RATE_HARDEN_DONE"
