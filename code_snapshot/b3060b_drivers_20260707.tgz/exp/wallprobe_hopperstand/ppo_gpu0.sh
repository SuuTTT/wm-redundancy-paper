#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
DRV=/root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
python -c "from mujoco_playground.config import dm_control_suite_params as p; c=p.brax_ppo_config('HopperStand'); print('[audit] brax_ppo_config(HopperStand) resolved (pre-override):'); print(c)" > "$EXP/logs/ppo_config_audit.log" 2>&1
CUDA_VISIBLE_DEVICES=0 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.5 MUJOCO_GL=egl \
  python -u "$DRV" --env HopperStand --seed 41 \
    --num_timesteps 120000000 --num_evals 30 --outdir "$EXP/runs_ppo" \
    > "$EXP/logs/ppo_seed41.log" 2>&1
echo "PPO_S41 rc=$? $(date -u +%FT%TZ)" >> "$EXP/logs/ppo_progress.log"
touch "$EXP/.ppo_gpu0_done"
