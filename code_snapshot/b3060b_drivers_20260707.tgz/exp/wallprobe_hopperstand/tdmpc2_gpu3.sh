#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
RL=/root/tdmpc_glass/helios-rl
cd "$RL" || exit 1
source ../venv/bin/activate
s=41
env PYTHONPATH=$RL/src:/root/tdmpc_glass/mujoco_playground_repo \
  MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.42 \
  TDMPC_EVAL_INTERVAL=50000 TDMPC_GLASS_OUTPUT_TAG=wallprobe_hstand_s${s} CUDA_VISIBLE_DEVICES=3 \
  python -u scripts/run_benchmark.py --algos tdmpc2 --tasks HopperStand --total_steps 1000000 \
    --seed $s --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 --no_plot \
    > "$EXP/logs/tdmpc2_seed${s}.log" 2>&1
echo "TDMPC2_S${s} rc=$? $(date -u +%FT%TZ)" >> "$EXP/logs/tdmpc2_progress.log"
{
  echo "WALLPROBE TDMPC2 HopperStand 1M seed 41 complete $(date -u +%FT%TZ)"
  ls "$RL"/exp/tdmpc_glass/ | grep wallprobe_hstand
} > "$EXP/WALLPROBE_TDMPC2_DONE"
