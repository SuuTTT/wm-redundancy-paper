#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$EXP/runs_sac1m" "$EXP/logs"
for s in 51 52 53; do
  CUDA_VISIBLE_DEVICES=0 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
    python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py \
      --env HopperStand --seed "$s" --num_timesteps 1000000 --num_evals 11 \
      --outdir "$EXP/runs_sac1m" > "$EXP/logs/sac1m_seed${s}.log" 2>&1
done &
export PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo
CUDA_VISIBLE_DEVICES=1 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax \
  TDMPC_GLASS_OUTPUT_TAG=wallprobe_hstand_s43 \
  python -u /root/tdmpc_glass/helios-rl/scripts/run_benchmark.py --algos tdmpc2 \
    --tasks HopperStand --total_steps 1000000 --seed 43 \
    --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 \
    --no_plot > "$EXP/logs/tdmpc2_seed43.log" 2>&1 &
wait
echo "STAND_BUDGET_DONE $(date -u +%FT%TZ)" > "$EXP/STAND_BUDGET_DONE"
