#!/usr/bin/env bash
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
while [ ! -f "$EXP/.ppo_gpu0_done" ] || [ ! -f "$EXP/.ppo_gpu1_done" ]; do sleep 300; done
source /root/tdmpc_glass/venv/bin/activate
python - > "$EXP/WALLPROBE_PPO_DONE" <<'PY'
import json, glob
print("WALLPROBE PPO-long HopperStand 120M num_evals=30 seeds 41/42")
for f in sorted(glob.glob("/root/tdmpc_glass/exp/wallprobe_hopperstand/runs_ppo/seed*.json")):
    d = json.load(open(f))
    print(f"seed{d['seed']}: peak={d.get('peak_reward')} final={d.get('final_reward')} done={d.get('done')} wall_s={d.get('total_wall_s')}")
PY
