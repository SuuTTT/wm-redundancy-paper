#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
DRV=/root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
for s in 41 42; do
  CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=.5 MUJOCO_GL=egl \
    python -u "$DRV" --env HopperStand --seed $s \
      --num_timesteps 5000000 --num_evals 26 --outdir "$EXP/runs_sac" \
      > "$EXP/logs/sac_seed${s}.log" 2>&1
  echo "SAC_S${s} rc=$? $(date -u +%FT%TZ)" >> "$EXP/logs/sac_progress.log"
done
python - > "$EXP/WALLPROBE_SAC_DONE" <<'PY'
import json, glob
print("WALLPROBE SAC HopperStand 5M num_evals=26 seeds 41/42")
for f in sorted(glob.glob("/root/tdmpc_glass/exp/wallprobe_hopperstand/runs_sac/seed*.json")):
    d = json.load(open(f))
    print(f"seed{d['seed']}: peak={d.get('peak_reward')} final={d.get('final_reward')} done={d.get('done')} wall_s={d.get('total_wall_s')}")
PY
