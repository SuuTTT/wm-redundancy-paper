#!/usr/bin/env bash
# Wall-probe seed extension: firms the hopper-morphology-wall claim.
# GPU0: PPO HopperStand seed 43; GPU1: PPO seed 44; GPU2: SAC seeds 43,44 sequential;
# GPU3: TD-MPC2 HopperStand seed 42 (n=1 -> n=2).
set -u
EXP=/root/tdmpc_glass/exp/wallprobe_hopperstand
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$EXP/logs" "$EXP/runs_ppo" "$EXP/runs_sac"

ppo_seed() {
  local gpu=$1 seed=$2
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
    python -u /root/tdmpc_glass/exp/ppo_hopperhop_sampleeff/ppo_hopperhop_driver.py \
      --env HopperStand --seed "$seed" --num_timesteps 120000000 --num_evals 30 \
      --outdir "$EXP/runs_ppo" > "$EXP/logs/ppo_seed${seed}.log" 2>&1
  echo "[ext] ppo seed $seed rc=$? $(date -u +%FT%TZ)" >> "$EXP/ext_driver.log"
}
sac_chain() {
  for s in 43 44; do
    CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
      python -u /root/tdmpc_glass/exp/sac_hopperhop_control/sac_hopperhop_driver.py \
        --env HopperStand --seed "$s" --num_timesteps 5000000 --num_evals 26 \
        --outdir "$EXP/runs_sac" > "$EXP/logs/sac_seed${s}.log" 2>&1
    echo "[ext] sac seed $s rc=$? $(date -u +%FT%TZ)" >> "$EXP/ext_driver.log"
  done
}
tdmpc2_seed() {
  export PYTHONPATH=/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo
  CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax \
    TDMPC_GLASS_OUTPUT_TAG=wallprobe_hstand_s42 \
    python -u /root/tdmpc_glass/helios-rl/scripts/run_benchmark.py --algos tdmpc2 \
      --tasks HopperStand --total_steps 1000000 --seed 42 \
      --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 \
      --no_plot > "$EXP/logs/tdmpc2_seed42.log" 2>&1
  echo "[ext] tdmpc2 seed 42 rc=$? $(date -u +%FT%TZ)" >> "$EXP/ext_driver.log"
}
ppo_seed 0 43 &
ppo_seed 1 44 &
sac_chain &
tdmpc2_seed &
wait
echo "WALLPROBE_EXT_DONE $(date -u +%FT%TZ)" > "$EXP/WALLPROBE_EXT_DONE"
