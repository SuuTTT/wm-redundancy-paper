#!/usr/bin/env bash
# Entropy-knob control on the HopperHop wall: does entropy_cost x3/x10 break it?
# GPU0: em3 s41; GPU1: em3 s42; GPU2: em10 s41; GPU3: em10 s42. 150M each (~1h).
set -u
EXP=/root/tdmpc_glass/exp/ppo_entropy_wall
cd /root/tdmpc_glass || exit 1
source venv/bin/activate
mkdir -p "$EXP/logs" "$EXP/runs"
run() {
  local gpu=$1 em=$2 seed=$3
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl \
    python -u $EXP/ppo_entropy_driver.py --env HopperHop --seed "$seed" \
      --entropy_mult "$em" --num_timesteps 150000000 --num_evals 30 \
      --outdir "$EXP/runs" > "$EXP/logs/em${em}_s${seed}.log" 2>&1
  echo "[ent] em$em s$seed rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
}
run 0 3 41 &
run 1 3 42 &
run 2 10 41 &
run 3 10 42 &
wait
echo "ENTROPY_SWEEP_DONE $(date -u +%FT%TZ)" > "$EXP/ENTROPY_SWEEP_DONE"
