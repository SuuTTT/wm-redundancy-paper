"""Brax-PPO driver with entropy-cost multiplier: does the hopper wall survive the
standard exploration knob? Clone of ppo_hopperhop_driver.py + --entropy_mult."""
import argparse, functools, json, os, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="HopperHop")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--num_timesteps", type=int, default=150_000_000)
    ap.add_argument("--num_evals", type=int, default=30)
    ap.add_argument("--entropy_mult", type=float, default=1.0)
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()

    os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
    os.environ.setdefault("MUJOCO_GL", "egl")

    import jax
    import jax.numpy as jnp
    if not hasattr(jax, "device_put_replicated"):
        def _dpr(x, devices):
            n = len(devices)
            return jax.tree_util.tree_map(lambda a: jnp.stack([jnp.asarray(a)] * n), x)
        jax.device_put_replicated = _dpr
    from brax.training.agents.ppo import networks as ppo_networks
    from brax.training.agents.ppo import train as ppo
    from mujoco_playground import registry, wrapper
    from mujoco_playground.config import dm_control_suite_params

    os.makedirs(args.outdir, exist_ok=True)
    out_json = os.path.join(args.outdir, f"seed{args.seed}_em{args.entropy_mult:g}.json")

    env_cfg = registry.get_default_config(args.env)
    ppo_params = dm_control_suite_params.brax_ppo_config(args.env)
    ppo_params.num_timesteps = args.num_timesteps
    ppo_params.num_evals = args.num_evals
    base_ent = float(ppo_params.entropy_cost)
    ppo_params.entropy_cost = base_ent * args.entropy_mult

    env = registry.load(args.env, config=env_cfg, config_overrides={"impl": "jax"})
    eval_env = registry.load(args.env, config=registry.get_default_config(args.env),
                             config_overrides={"impl": "jax"})

    training_params = dict(ppo_params)
    network_factory = ppo_networks.make_ppo_networks
    if "network_factory" in training_params:
        network_factory = functools.partial(
            ppo_networks.make_ppo_networks, **training_params.pop("network_factory"))
    num_eval_envs = training_params.pop("num_eval_envs", 128)

    curve = []
    t0 = time.monotonic()
    record = {"env": args.env, "seed": args.seed, "entropy_mult": args.entropy_mult,
              "base_entropy_cost": base_ent, "effective_entropy_cost": base_ent * args.entropy_mult,
              "num_timesteps": args.num_timesteps, "curve": curve, "done": False}
    def flush():
        with open(out_json, "w") as f:
            json.dump(record, f)

    def progress(step, metrics):
        r = float(metrics.get("eval/episode_reward", float("nan")))
        curve.append({"step": int(step), "reward": r, "wall": time.monotonic() - t0})
        print(f"[{args.env} s{args.seed} em{args.entropy_mult:g}] {step}: reward={r:.3f}", flush=True)
        flush()

    flush()
    ppo.train(environment=env, eval_env=eval_env,
              wrap_env_fn=wrapper.wrap_for_brax_training,
              network_factory=network_factory, num_eval_envs=num_eval_envs,
              progress_fn=progress, seed=args.seed, **training_params)
    record["done"] = True
    flush()
    print("DONE", flush=True)

if __name__ == "__main__":
    main()
