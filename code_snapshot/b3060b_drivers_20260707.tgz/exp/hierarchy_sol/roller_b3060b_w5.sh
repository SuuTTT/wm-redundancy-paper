#!/usr/bin/env bash
# b3060b wave-5: tighten best-horizon (h200) cell + its hyperparameter robustness. GPU1/2/3 only.
set -u
HL=/root/tdmpc_glass/helios-rl/hl_pickcube
OUT=/root/tdmpc_glass/exp/hierarchy_sol; LOGS=$OUT/logs
VENV=/root/tdmpc_glass/venv
PP="/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo"
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.5"
STATE=$LOGS/roller_b3060b_w5.state; GPUS=(1 2 3)
build_queue() {
  Q=()
  # h200 robustness: sigA (sig0.1) + lrB (lr0.02), mlp, 3 seeds each
  for s in 0 1 2; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 200 --sigma 0.1 --lr 0.03 --seed $s --tag h_opt_mlp_h200sigA_s$s --out_dir $OUT/arms/hier_options_mlp_h200sigA_s$s")
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 200 --sigma 0.05 --lr 0.02 --seed $s --tag h_opt_mlp_h200lrB_s$s --out_dir $OUT/arms/hier_options_mlp_h200lrB_s$s")
  done
  # global at h200 (does 1-level also benefit from longer horizon, or is the horizon gain mlp-specific?)
  for s in 0 1 2; do
    Q+=("options_train.py --mode global --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 200 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_global_h200_s$s --out_dir $OUT/arms/hier_options_global_h200_s$s")
  done
}
build_queue
echo "wave5 queue size ${#Q[@]} at $(date)" | tee -a "$STATE"
gpu_busy() { local g=$1; local a; a=$(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null|tr -d ' \n'); [ -n "$a" ]; }
launch() { local g=$1; shift; local cmd="$1"; local name; name=$(echo "$cmd"|grep -oE "out_dir [^ ]+"|sed 's#.*/##')
  echo "[w5 $(date +%H:%M:%S)] GPU$g <- $name" | tee -a "$STATE"
  setsid bash -c "cd $HL && source $VENV/bin/activate && env PYTHONPATH=$PP $COMMON CUDA_VISIBLE_DEVICES=$g python $cmd >> '$LOGS/$name.log' 2>&1" </dev/null & }
qi=0; END=$(( $(date +%s) + 9000 ))
while [ "$qi" -lt "${#Q[@]}" ] && [ "$(date +%s)" -lt "$END" ]; do
  for g in "${GPUS[@]}"; do
    [ "$qi" -ge "${#Q[@]}" ] && break
    if ! gpu_busy "$g"; then launch "$g" "${Q[$qi]}"; qi=$((qi+1)); sleep 40; fi
  done
  sleep 45
done
echo "wave5 done qi=$qi at $(date)" | tee -a "$STATE"
