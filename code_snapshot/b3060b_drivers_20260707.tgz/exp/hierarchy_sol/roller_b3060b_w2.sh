#!/usr/bin/env bash
# b3060b wave-2: top up under-sampled cells + extend the horizon curve. GPU1/2/3 only (GPU0=mahjong).
set -u
HL=/root/tdmpc_glass/helios-rl/hl_pickcube
OUT=/root/tdmpc_glass/exp/hierarchy_sol
LOGS=$OUT/logs
VENV=/root/tdmpc_glass/venv
PP="/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo"
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.5"
STATE=$LOGS/roller_b3060b_w2.state
GPUS=(1 2 3)

build_queue() {
  Q=()
  # extend h200 to n>=5 (tighten the best horizon cell)
  for s in 3 4 5 6; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 200 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_h200_s$s --out_dir $OUT/arms/hier_options_mlp_h200_s$s")
  done
  # map the horizon curve further: 250 and 300 steps (does longer keep helping or saturate?)
  for h in 250 300; do for s in 0 1 2; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 350 --eval_envs 512 --steps $h --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_h${h}_s$s --out_dir $OUT/arms/hier_options_mlp_h${h}_s$s")
  done; done
  # more global seeds to n=10 (match mlp n for the levels ablation CI)
  for s in 6 7 8 9; do
    Q+=("options_train.py --mode global --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_global_s$s --out_dir $OUT/arms/hier_options_global_s$s")
  done
  # more residual seeds to n=10
  for s in 6 7 8 9; do
    Q+=("residual_train.py --pop 128 --envs_per 2 --iters 400 --eval_envs 512 --alpha 0.3 --sigma 0.05 --lr 0.03 --seed $s --tag h_resid_s$s --out_dir $OUT/arms/hier_residual_s$s")
  done
}
build_queue
echo "wave2 queue size ${#Q[@]} at $(date)" | tee -a "$STATE"

gpu_busy() { local g=$1; local a; a=$(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null|tr -d ' \n'); [ -n "$a" ]; }
launch() { local g=$1; shift; local cmd="$1"; local name; name=$(echo "$cmd"|grep -oE "out_dir [^ ]+"|sed 's#.*/##')
  echo "[w2 $(date +%H:%M:%S)] GPU$g <- $name" | tee -a "$STATE"
  setsid bash -c "cd $HL && source $VENV/bin/activate && env PYTHONPATH=$PP $COMMON CUDA_VISIBLE_DEVICES=$g python $cmd >> '$LOGS/$name.log' 2>&1" </dev/null & }

qi=0; END=$(( $(date +%s) + 18000 ))
while [ "$qi" -lt "${#Q[@]}" ] && [ "$(date +%s)" -lt "$END" ]; do
  for g in "${GPUS[@]}"; do
    [ "$qi" -ge "${#Q[@]}" ] && break
    if ! gpu_busy "$g"; then launch "$g" "${Q[$qi]}"; qi=$((qi+1)); sleep 35; fi
  done
  sleep 45
done
echo "wave2 done qi=$qi at $(date)" | tee -a "$STATE"
