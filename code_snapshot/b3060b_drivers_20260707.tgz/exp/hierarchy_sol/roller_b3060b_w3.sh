#!/usr/bin/env bash
# b3060b wave-3: tighten key cells to n=10 + ES-hyperparameter robustness of the 2-level>1-level result.
# GPU1/2/3 only (GPU0=mahjong). Fills the remaining ~4.5h window with high-value seeds.
set -u
HL=/root/tdmpc_glass/helios-rl/hl_pickcube
OUT=/root/tdmpc_glass/exp/hierarchy_sol
LOGS=$OUT/logs
VENV=/root/tdmpc_glass/venv
PP="/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo"
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.5"
STATE=$LOGS/roller_b3060b_w3.state
GPUS=(1 2 3)

build_queue() {
  Q=()
  # 1) top h200 (best horizon cell) to n=10
  for s in 7 8 9; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 200 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_h200_s$s --out_dir $OUT/arms/hier_options_mlp_h200_s$s")
  done
  # 2) ES-hyperparam ROBUSTNESS: does mlp(2-level) > global(1-level) survive sigma/lr changes?
  #    variant A: higher sigma 0.1, variant B: lower lr 0.02. mlp + global, 3 seeds each.
  for cfg in "sigA --sigma 0.1 --lr 0.03" "lrB --sigma 0.05 --lr 0.02"; do
    cn=${cfg%% *}; rest=${cfg#* }
    for mode in mlp global; do for s in 0 1 2; do
      Q+=("options_train.py --mode $mode --pop 96 --envs_per 2 --iters 350 --eval_envs 512 --steps 150 $rest --seed $s --tag h_opt_${mode}_${cn}_s$s --out_dir $OUT/arms/hier_options_${mode}_${cn}_s$s")
    done; done
  done
}
build_queue
echo "wave3 queue size ${#Q[@]} at $(date)" | tee -a "$STATE"

gpu_busy() { local g=$1; local a; a=$(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null|tr -d ' \n'); [ -n "$a" ]; }
launch() { local g=$1; shift; local cmd="$1"; local name; name=$(echo "$cmd"|grep -oE "out_dir [^ ]+"|sed 's#.*/##')
  echo "[w3 $(date +%H:%M:%S)] GPU$g <- $name" | tee -a "$STATE"
  setsid bash -c "cd $HL && source $VENV/bin/activate && env PYTHONPATH=$PP $COMMON CUDA_VISIBLE_DEVICES=$g python $cmd >> '$LOGS/$name.log' 2>&1" </dev/null & }

qi=0; END=$(( $(date +%s) + 16000 ))
while [ "$qi" -lt "${#Q[@]}" ] && [ "$(date +%s)" -lt "$END" ]; do
  for g in "${GPUS[@]}"; do
    [ "$qi" -ge "${#Q[@]}" ] && break
    if ! gpu_busy "$g"; then launch "$g" "${Q[$qi]}"; qi=$((qi+1)); sleep 35; fi
  done
  sleep 45
done
echo "wave3 done qi=$qi at $(date)" | tee -a "$STATE"
