#!/usr/bin/env python3
"""Re-score EXISTING hierarchy ES checkpoints (best_theta.npy) under RELAXED
success criteria that DROP the upright-orientation requirement.

Full success used in the campaign: box_target>=0.9 where
  box_target = 1 - tanh(5*(0.9*pos_err + 0.1*rot_err))   (pick.py:222)
=> blends POSITION and ORIENTATION. box_target>=0.9 needs
   0.9*pos_err + 0.1*rot_err <= atanh(0.1)/5 ~= 0.0201  (very tight, +upright)

Relaxed criteria computed here from RAW telemetry (per env, any-step):
  - full        : box_target>=0.9                (replicate campaign metric)
  - pos_err     : ||box_pos - target_pos|| < THR for THR in {0.05,0.08,0.10}
                  (POSITION-ONLY: ignore rotation entirely)
  - pos_at_end  : pos_err<THR at FINAL step (must arrive AND stay, not just pass)
  - lift        : box lifted > 0.06 m off table (grasp+lift success)
Deterministic eval: fixed PRNGKey, fixed eval_envs. Reports n=eval_envs.
Everything from real rollouts; nothing fabricated.
"""
import os
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.45")
import argparse, json, glob, time
from pathlib import Path
import numpy as np
import jax, jax.numpy as jp
from mujoco_playground import registry

HERE = Path("/root/tdmpc_glass/helios-rl/hl_pickcube")
import sys; sys.path.insert(0, str(HERE))
import param_controller as PC

CTX_DIM = 6
KV_DIM = PC.KV_DIM
MLP_H = 32

def pi_hi_global(theta, ctx):
    return jp.tanh(theta)

def pi_hi_mlp(theta, ctx):
    (W1, b1), (W2, b2) = theta
    h = jp.tanh(ctx @ W1 + b1)
    return jp.tanh(h @ W2 + b2)

def unflatten_mlp(vec):
    i = 0
    def take(n):
        nonlocal i
        out = vec[i:i+n]; i += n; return out
    W1 = take(CTX_DIM*MLP_H).reshape(CTX_DIM, MLP_H)
    b1 = take(MLP_H)
    W2 = take(MLP_H*KV_DIM).reshape(MLP_H, KV_DIM)
    b2 = take(KV_DIM)
    return [(W1, b1), (W2, b2)]

def build_eval(env, n_steps):
    ctrl = PC.make_param_controller(env)
    reset = jax.jit(jax.vmap(env.reset))
    step = jax.vmap(env.step)
    act_vmap = jax.vmap(ctrl.act)
    init_cs_single = ctrl.init_state()
    mocap_target = env._mocap_target

    def rollout(theta, keys, mode):
        pi_hi = pi_hi_global if mode == "global" else pi_hi_mlp
        n = keys.shape[0]
        state = reset(keys)
        state = step(state, jp.zeros((n, 8)))
        cs = jax.tree_util.tree_map(
            lambda x: jp.broadcast_to(x, (n,) + x.shape), init_cs_single)
        box0 = state.data.xpos[:, env._obj_body]
        box0z = box0[:, 2]
        target = state.info["target_pos"]
        ctx = jax.vmap(PC.context_of)(box0, target)
        d = jax.vmap(lambda c: pi_hi(theta, c))(ctx)
        kv = jax.vmap(PC.d_to_knobs)(d)

        def body(carry, _):
            state, cs = carry
            action, cs = act_vmap(state, cs, kv)
            state = step(state, action)
            box = state.data.xpos[:, env._obj_body]
            tpos = state.info["target_pos"]
            pos_err = jp.linalg.norm(box - tpos, axis=-1)
            tele = {
                "box_target": state.metrics["box_target"],
                "pos_err": pos_err,
                "box_z": box[:, 2],
            }
            return (state, cs), tele

        (state, cs), tele = jax.lax.scan(body, (state, cs), None, length=n_steps)
        bt = tele["box_target"]            # (T, n)
        pe = tele["pos_err"]               # (T, n)
        lift = tele["box_z"] - box0z[None, :]
        out = {
            "full_succ": (bt >= 0.9).any(axis=0).astype(jp.float32),
            "bt_max": bt.max(axis=0),
            "pos_min": pe.min(axis=0),           # closest the box ever got
            "pos_end": pe[-1],                    # at final step
            "pos05_any": (pe < 0.05).any(axis=0).astype(jp.float32),
            "pos08_any": (pe < 0.08).any(axis=0).astype(jp.float32),
            "pos10_any": (pe < 0.10).any(axis=0).astype(jp.float32),
            "pos05_end": (pe[-1] < 0.05).astype(jp.float32),
            "pos08_end": (pe[-1] < 0.08).astype(jp.float32),
            "pos10_end": (pe[-1] < 0.10).astype(jp.float32),
            "lift_succ": (lift > 0.06).any(axis=0).astype(jp.float32),
        }
        return {k: jp.mean(v) for k, v in out.items()}

    return jax.jit(rollout, static_argnames=("mode",))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--glob", default="/root/tdmpc_glass/exp/hierarchy_sol/arms/hier_options_*_s*")
    ap.add_argument("--eval_envs", type=int, default=1024)
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--out", default="/root/tdmpc_glass/exp/hierarchy_sol/RESCORE_POSONLY.json")
    args = ap.parse_args()

    env = registry.load("PandaPickCube", config_overrides={"impl": "jax"})
    roll = build_eval(env, args.steps)
    keys = jax.random.split(jax.random.PRNGKey(args.seed), args.eval_envs)

    dirs = sorted(glob.glob(args.glob))
    dirs = [d for d in dirs if os.path.exists(os.path.join(d, "best_theta.npy"))]
    print(f"found {len(dirs)} checkpoints; eval_envs={args.eval_envs} steps={args.steps} seed={args.seed}", flush=True)

    results = {}
    t0 = time.time()
    for d in dirs:
        name = os.path.basename(d)
        mode = "mlp" if "mlp" in name else "global"
        vec = np.load(os.path.join(d, "best_theta.npy"))
        vec = jp.asarray(vec)
        if mode == "mlp":
            theta = unflatten_mlp(vec)
        else:
            theta = vec
        try:
            r = roll(theta, keys, mode)
            r = {k: float(v) for k, v in r.items()}
        except Exception as e:
            r = {"error": str(e)}
        r["mode"] = mode
        results[name] = r
        print(f"{name:32s} full={r.get('full_succ',float('nan')):.4f} "
              f"pos05={r.get('pos05_any',float('nan')):.4f} pos08={r.get('pos08_any',float('nan')):.4f} "
              f"pos10={r.get('pos10_any',float('nan')):.4f} pos08_end={r.get('pos08_end',float('nan')):.4f} "
              f"lift={r.get('lift_succ',float('nan')):.4f}", flush=True)

    # aggregate by family (mlp vs global)
    def agg(names):
        keys_m = ["full_succ","pos05_any","pos08_any","pos10_any",
                  "pos05_end","pos08_end","pos10_end","lift_succ","bt_max","pos_min","pos_end"]
        out = {}
        for k in keys_m:
            vals = [results[n][k] for n in names if k in results[n]]
            if vals:
                out[k+"_mean"] = round(float(np.mean(vals)), 4)
                out[k+"_max"] = round(float(np.max(vals)), 4)
        out["n_seeds"] = len(names)
        return out

    mlp_names = [n for n in results if "mlp" in n and "error" not in results[n]]
    glob_names = [n for n in results if "global" in n and "error" not in results[n]]
    summary = {
        "eval_envs": args.eval_envs, "steps": args.steps, "seed": args.seed,
        "metric_defs": {
            "full_succ": "box_target>=0.9 (campaign metric: blends 0.9*pos_err+0.1*rot_err)",
            "pos0X_any": "||box-target||<0.0X m at ANY step (POSITION-ONLY, ignore rot)",
            "pos0X_end": "||box-target||<0.0X m at FINAL step (arrive AND stay)",
            "lift_succ": "box lifted >0.06 m off table",
        },
        "mlp_2level": agg(mlp_names),
        "global_1level": agg(glob_names),
        "per_arm": results,
    }
    Path(args.out).write_text(json.dumps(summary, indent=2))
    print("\n=== AGGREGATE ===")
    print("mlp (2-level)   :", json.dumps(summary["mlp_2level"]))
    print("global (1-level):", json.dumps(summary["global_1level"]))
    print(f"wrote {args.out}  elapsed={time.time()-t0:.0f}s")

if __name__ == "__main__":
    main()
