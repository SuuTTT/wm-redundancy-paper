#!/usr/bin/env bash
# Wait for wave-3 roller to exit, then launch wave-4 (single-roller, no race).
cd /root/tdmpc_glass/exp/hierarchy_sol
while pgrep -f "roller_b3060b_w3.sh" | grep -qv "$$"; do
  # also break if w3 state says done
  grep -q "wave3 done" logs/roller_b3060b_w3.state 2>/dev/null && break
  sleep 30
done
echo "w3 finished at $(date), starting w4" >> logs/chain_w4.log
nohup setsid bash roller_b3060b_w4.sh >logs/roller_b3060b_w4.out 2>&1 </dev/null &
echo "w4 launched pid $!" >> logs/chain_w4.log
