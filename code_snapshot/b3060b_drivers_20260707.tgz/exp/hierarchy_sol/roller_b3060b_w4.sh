#!/usr/bin/env bash
# b3060b wave-4: ANCHOR-CONFIRMATION. Longer-iters (700) mlp + global to show the ~0.2 success
# ceiling is a true plateau (not under-training). The default-400-iter runs already plateau/oscillate
# at ~0.15-0.22 from it~365; this doubles the budget to confirm. GPU1/2/3 only (GPU0=mahjong).
set -u
HL=/root/tdmpc_glass/helios-rl/hl_pickcube
OUT=/root/tdmpc_glass/exp/hierarchy_sol
LOGS=$OUT/logs
VENV=/root/tdmpc_glass/venv
PP="/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo"
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.5"
STATE=$LOGS/roller_b3060b_w4.state
GPUS=(1 2 3)

build_queue() {
  Q=()
  # longer-iters mlp (2-level) and global (1-level) at the best/default horizon, 3 seeds each.
  # also one h200 long-iters (best cell) to see if the higher-horizon plateau is higher.
  for s in 0 1 2; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 700 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_long_s$s --out_dir $OUT/arms/hier_options_mlp_long_s$s")
  done
  for s in 0 1 2; do
    Q+=("options_train.py --mode global --pop 96 --envs_per 2 --iters 700 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_global_long_s$s --out_dir $OUT/arms/hier_options_global_long_s$s")
  done
  for s in 0 1 2; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 700 --eval_envs 512 --steps 200 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_h200long_s$s --out_dir $OUT/arms/hier_options_mlp_h200long_s$s")
  done
}
build_queue
echo "wave4 queue size ${#Q[@]} at $(date)" | tee -a "$STATE"

gpu_busy() { local g=$1; local a; a=$(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null|tr -d ' \n'); [ -n "$a" ]; }
launch() { local g=$1; shift; local cmd="$1"; local name; name=$(echo "$cmd"|grep -oE "out_dir [^ ]+"|sed 's#.*/##')
  echo "[w4 $(date +%H:%M:%S)] GPU$g <- $name" | tee -a "$STATE"
  setsid bash -c "cd $HL && source $VENV/bin/activate && env PYTHONPATH=$PP $COMMON CUDA_VISIBLE_DEVICES=$g python $cmd >> '$LOGS/$name.log' 2>&1" </dev/null & }

qi=0; END=$(( $(date +%s) + 13000 ))
while [ "$qi" -lt "${#Q[@]}" ] && [ "$(date +%s)" -lt "$END" ]; do
  for g in "${GPUS[@]}"; do
    [ "$qi" -ge "${#Q[@]}" ] && break
    if ! gpu_busy "$g"; then launch "$g" "${Q[$qi]}"; qi=$((qi+1)); sleep 40; fi
  done
  sleep 45
done
echo "wave4 done qi=$qi at $(date)" | tee -a "$STATE"
