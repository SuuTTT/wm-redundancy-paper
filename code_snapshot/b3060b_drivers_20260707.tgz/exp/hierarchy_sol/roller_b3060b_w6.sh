#!/usr/bin/env bash
# b3060b wave-6: final CI-tightening filler with NON-CONFLICTING seeds (10-15). GPU1/2/3 only.
set -u
HL=/root/tdmpc_glass/helios-rl/hl_pickcube
OUT=/root/tdmpc_glass/exp/hierarchy_sol; LOGS=$OUT/logs
VENV=/root/tdmpc_glass/venv
PP="/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo"
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.5"
STATE=$LOGS/roller_b3060b_w6.state; GPUS=(1 2 3)
build_queue() {
  Q=()
  # extra h200 seeds (best cell) with fresh seed ids 10-14 -> push n higher
  for s in 10 11 12 13 14; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 200 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_h200_s$s --out_dir $OUT/arms/hier_options_mlp_h200_s$s")
  done
  # extra mlp default seeds 10-13 -> even tighter CI on the headline cell
  for s in 10 11 12 13; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_s$s --out_dir $OUT/arms/hier_options_mlp_s$s")
  done
}
build_queue
echo "wave6 queue size ${#Q[@]} at $(date)" | tee -a "$STATE"
gpu_busy() { local g=$1; local a; a=$(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null|tr -d ' \n'); [ -n "$a" ]; }
launch() { local g=$1; shift; local cmd="$1"; local name; name=$(echo "$cmd"|grep -oE "out_dir [^ ]+"|sed 's#.*/##')
  echo "[w6 $(date +%H:%M:%S)] GPU$g <- $name" | tee -a "$STATE"
  setsid bash -c "cd $HL && source $VENV/bin/activate && env PYTHONPATH=$PP $COMMON CUDA_VISIBLE_DEVICES=$g python $cmd >> '$LOGS/$name.log' 2>&1" </dev/null & }
qi=0; END=$(( $(date +%s) + 6000 ))
while [ "$qi" -lt "${#Q[@]}" ] && [ "$(date +%s)" -lt "$END" ]; do
  for g in "${GPUS[@]}"; do
    [ "$qi" -ge "${#Q[@]}" ] && break
    if ! gpu_busy "$g"; then launch "$g" "${Q[$qi]}"; qi=$((qi+1)); sleep 40; fi
  done
  sleep 45
done
echo "wave6 done qi=$qi at $(date)" | tee -a "$STATE"
