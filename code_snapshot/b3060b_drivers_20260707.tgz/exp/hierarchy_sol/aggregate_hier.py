#!/usr/bin/env python3
"""Aggregate the hierarchical-abstraction sample-efficiency campaign.

Reads:
  - hierarchical/ablation arms: $OUT/arms/*/RESULTS.json (env_steps + held-out TRUE success
    + per-iter history -> env-steps-to-threshold).
  - flat TD-MPC2 real-success CSVs copied to $OUT/flat/ (box_target>=0.9, deterministic eval).

Produces: $OUT/HIER_VERDICT.json and $OUT/HIER_WRITEUP.md
Metric: env-steps to first reach success>=THR (speed-of-learning), peak success, n seeds.
Honest: only real held-out success; flat PPO uses the documented official anchor (return-only CSV).
"""
import json, glob, os, csv
from pathlib import Path
from statistics import mean, pstdev

OUT = Path(os.environ.get("HIER_OUT", "/root/tdmpc_glass/exp/hierarchy_sol"))
ARMS = OUT / "arms"
FLAT = OUT / "flat"
THRESHOLDS = [0.1, 0.3, 0.5, 0.8]

def steps_to_threshold(history, thr, key="eval_success"):
    """First env_steps where eval_success >= thr (from per-iter history)."""
    for rec in history:
        v = rec.get(key)
        if v is not None and v >= thr:
            return int(rec.get("env_steps", -1))
    return None

def load_hier_arm(d):
    rj = d / "RESULTS.json"
    if not rj.exists():
        return None
    try:
        r = json.loads(rj.read_text())
    except Exception:
        return None
    hist = r.get("history", [])
    s2t = {f"{thr}": steps_to_threshold(hist, thr) for thr in THRESHOLDS}
    return {
        "name": d.name,
        "status": r.get("status"),
        "env_steps_used": r.get("env_steps_used"),
        "success_peak": r.get("success_peak"),
        "success_final": r.get("success_final"),
        "reached": (r.get("final_eval") or {}).get("reached"),
        "grasp": (r.get("phase_telemetry") or {}).get("grasp_ok"),
        "lift_ok": (r.get("phase_telemetry") or {}).get("lift_ok"),
        "place_reached": (r.get("phase_telemetry") or {}).get("place_reached"),
        "steps_to_thr": s2t,
        "iters_done": r.get("iters_done"),
        "mode": (r.get("param_space") or {}).get("mode"),
    }

def arm_family(name):
    # strip trailing _s<seed>
    import re
    return re.sub(r"_s\d+$", "", name)

def agg_family(rows):
    """Aggregate seeds within a family."""
    peaks = [x["success_peak"] for x in rows if x["success_peak"] is not None]
    finals = [x["success_final"] for x in rows if x["success_final"] is not None]
    out = {
        "n_seeds": len(rows),
        "n_done": sum(1 for x in rows if x["status"] == "done"),
        "peak_mean": round(mean(peaks), 4) if peaks else None,
        "peak_std": round(pstdev(peaks), 4) if len(peaks) > 1 else 0.0,
        "peak_max": round(max(peaks), 4) if peaks else None,
        "final_mean": round(mean(finals), 4) if finals else None,
    }
    # median env-steps-to-threshold across seeds (only seeds that reached it)
    for thr in THRESHOLDS:
        vals = [x["steps_to_thr"][str(thr)] for x in rows if x["steps_to_thr"].get(str(thr)) is not None]
        out[f"steps_to_{thr}_median"] = int(sorted(vals)[len(vals)//2]) if vals else None
        out[f"steps_to_{thr}_n_reached"] = len(vals)
    # subtask competence (mean over seeds, last value)
    for k in ("reached", "grasp", "lift_ok", "place_reached"):
        vv = [x[k] for x in rows if x.get(k) is not None]
        out[k+"_mean"] = round(mean(vv), 4) if vv else None
    return out

def load_flat_csvs():
    """Flat TD-MPC2 real-success: peak pi/mppi success + step-to-threshold."""
    res = {}
    for f in sorted(glob.glob(str(FLAT / "*realsuccess*.csv"))):
        name = Path(f).stem
        rows = list(csv.DictReader(open(f)))
        if not rows:
            continue
        def col(r, c):
            try: return float(r.get(c, "nan"))
            except: return float("nan")
        peak_pi = max((col(r, "pi_success") for r in rows), default=0.0)
        peak_mppi = max((col(r, "mppi_success") for r in rows), default=0.0)
        peak_bt = max((max(col(r,"pi_box_target_max"), col(r,"mppi_box_target_max")) for r in rows), default=0.0)
        last_step = int(float(rows[-1]["step"]))
        # step to success>=thr (best of pi/mppi)
        s2t = {}
        for thr in THRESHOLDS:
            st = None
            for r in rows:
                if max(col(r,"pi_success"), col(r,"mppi_success")) >= thr:
                    st = int(float(r["step"])); break
            s2t[str(thr)] = st
        res[name] = {"peak_pi_success": round(peak_pi,4), "peak_mppi_success": round(peak_mppi,4),
                     "peak_box_target": round(peak_bt,4), "last_step": last_step, "steps_to_thr": s2t}
    return res

def main():
    arms = []
    for d in sorted(ARMS.glob("*")):
        if d.is_dir():
            a = load_hier_arm(d)
            if a: arms.append(a)
    families = {}
    for a in arms:
        families.setdefault(arm_family(a["name"]), []).append(a)
    fam_agg = {fam: agg_family(rows) for fam, rows in families.items()}
    flat = load_flat_csvs()

    PPO_OFFICIAL = {"success": 0.66, "env_steps": 33_000_000, "source": "brax official anchor (project KB)"}

    verdict = {
        "campaign": "hierarchical_abstraction_sample_efficiency",
        "task": "PandaPickCube (long-horizon: reach->grasp->lift->place)",
        "metric": "env-steps to held-out TRUE success>=THR (box_target>=0.9); peak success; n seeds",
        "thresholds": THRESHOLDS,
        "hier_families": fam_agg,
        "flat_tdmpc2_realsuccess": flat,
        "ppo_official_anchor": PPO_OFFICIAL,
        "per_seed_arms": arms,
    }
    (OUT / "HIER_VERDICT.json").write_text(json.dumps(verdict, indent=2))

    # ---- markdown ----
    L = ["# Hierarchical Abstraction Sample-Efficiency Verdict", "",
         "Task: **PandaPickCube** (long-horizon reach->grasp->lift->place). Metric: **env-steps to held-out TRUE success** (box_target>=0.9), peak success, n seeds. All numbers from disk (RESULTS.json / *_realsuccess.csv).", "",
         "## Speed-of-learning table (hierarchical & ablation arms)", "",
         "| arm | n(done) | peak succ (mean±sd) | peak max | steps→0.1 (med) | steps→0.3 | steps→0.5 | reached | grasp | lift | place |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    def fmt(x): return "-" if x is None else (f"{x:,}" if isinstance(x,int) else f"{x}")
    for fam in sorted(fam_agg):
        a = fam_agg[fam]
        L.append("| {} | {}/{} | {}±{} | {} | {} | {} | {} | {} | {} | {} | {} |".format(
            fam, a["n_done"], a["n_seeds"], fmt(a["peak_mean"]), fmt(a["peak_std"]), fmt(a["peak_max"]),
            fmt(a["steps_to_0.1_median"]), fmt(a["steps_to_0.3_median"]), fmt(a["steps_to_0.5_median"]),
            fmt(a["reached_mean"]), fmt(a["grasp_mean"]), fmt(a["lift_ok_mean"]), fmt(a["place_reached_mean"])))
    L += ["", "## Flat baselines (single-level)", "",
          "| arm | peak pi succ | peak mppi succ | peak box_target | last step | steps→0.5 |",
          "|---|---|---|---|---|---|"]
    for n, f in sorted(flat.items()):
        L.append("| {} | {} | {} | {} | {} | {} |".format(n, f["peak_pi_success"], f["peak_mppi_success"],
                  f["peak_box_target"], f"{f['last_step']:,}", fmt(f["steps_to_thr"].get("0.5"))))
    L += ["", f"- **Flat PPO (official anchor):** success {PPO_OFFICIAL['success']} @ {PPO_OFFICIAL['env_steps']:,} env-steps ({PPO_OFFICIAL['source']}).", ""]
    (OUT / "HIER_WRITEUP.md").write_text("\n".join(L) + "\n")
    print("wrote HIER_VERDICT.json and HIER_WRITEUP.md")
    print(f"families: {list(fam_agg.keys())}")
    for fam in sorted(fam_agg):
        a = fam_agg[fam]
        print(f"  {fam}: n={a['n_seeds']} done={a['n_done']} peak={a['peak_mean']} max={a['peak_max']}")

if __name__ == "__main__":
    main()
