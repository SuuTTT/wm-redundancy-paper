#!/usr/bin/env bash
# b3060b roller: keep GPU 1,2,3 busy ~8h with the hierarchical-abstraction matrix.
# GPU0 = mahjong, NEVER touched. Reuses hl_pickcube options_train.py / residual_train.py.
# Each run reports REAL held-out success vs env_steps -> RESULTS.json. No --save_full_state (ES writes only KB).
set -u
HL=/root/tdmpc_glass/helios-rl/hl_pickcube
OUT=/root/tdmpc_glass/exp/hierarchy_sol
LOGS=$OUT/logs
mkdir -p "$OUT/arms" "$LOGS"
VENV=/root/tdmpc_glass/venv
PP="/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo"
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.5"
STATE=$LOGS/roller_b3060b.state
GPUS=(1 2 3)

# Each queue entry: a full command (script + args + out_dir name). out_dir under $OUT/arms/.
# Matrix:
#  A) hier_options mlp  (2-level, context-conditioned subgoals)         seeds 3..9   (s0-2 already in wave1)
#  B) hier_options global (ABLATION: context-FREE = degenerate 1-level)  seeds 0..5
#  C) hier_residual (ABLATION: shallower HL+raw-residual hierarchy)      seeds 0..5
#  D) option-horizon ABLATION: steps in {100,200} for mlp               seeds 0..2 each
build_queue() {
  Q=()
  # A) more mlp seeds (tight CI on the 2-level arm)
  for s in 3 4 5 6 7 8 9; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_s$s --out_dir $OUT/arms/hier_options_mlp_s$s")
  done
  # B) global (context-free) ablation
  for s in 0 1 2 3 4 5; do
    Q+=("options_train.py --mode global --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_global_s$s --out_dir $OUT/arms/hier_options_global_s$s")
  done
  # C) residual ablation (HL + learned raw-action residual)
  for s in 0 1 2 3 4 5; do
    Q+=("residual_train.py --pop 128 --envs_per 2 --iters 400 --eval_envs 512 --alpha 0.3 --sigma 0.05 --lr 0.03 --seed $s --tag h_resid_s$s --out_dir $OUT/arms/hier_residual_s$s")
  done
  # D) option-horizon ablation (subgoal horizon = episode steps)
  for s in 0 1 2; do
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 100 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_h100_s$s --out_dir $OUT/arms/hier_options_mlp_h100_s$s")
    Q+=("options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 200 --sigma 0.05 --lr 0.03 --seed $s --tag h_opt_mlp_h200_s$s --out_dir $OUT/arms/hier_options_mlp_h200_s$s")
  done
}
build_queue
echo "queue size ${#Q[@]} at $(date)" | tee -a "$STATE"

gpu_busy() { # gpu -> 0 if a process of OURS is on it
  local g=$1
  local apps; apps=$(nvidia-smi -i $g --query-compute-apps=pid --format=csv,noheader,nounits 2>/dev/null | tr -d ' \n')
  [ -n "$apps" ]
}
launch() { # gpu  cmd
  local g=$1; shift
  local cmd="$1"
  local name; name=$(echo "$cmd" | grep -oE "out_dir [^ ]+" | sed 's#.*/##')
  echo "[roll $(date +%H:%M:%S)] GPU$g <- $name" | tee -a "$STATE"
  setsid bash -c "cd $HL && source $VENV/bin/activate && env PYTHONPATH=$PP $COMMON CUDA_VISIBLE_DEVICES=$g python $cmd >> '$LOGS/$name.log' 2>&1" </dev/null &
}

qi=0
END=$(( $(date +%s) + 28000 ))  # ~7.8h
while [ "$qi" -lt "${#Q[@]}" ] && [ "$(date +%s)" -lt "$END" ]; do
  for g in "${GPUS[@]}"; do
    [ "$qi" -ge "${#Q[@]}" ] && break
    if ! gpu_busy "$g"; then
      launch "$g" "${Q[$qi]}"
      qi=$((qi+1))
      sleep 35
    fi
  done
  sleep 45
done
echo "roller_b3060b done qi=$qi at $(date)" | tee -a "$STATE"
