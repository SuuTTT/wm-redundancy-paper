#!/usr/bin/env bash
# Hierarchical-abstraction sample-efficiency campaign — b3060b (GPU 1,2,3 only; GPU0=mahjong, untouched).
# Reuses hl_pickcube infra: options_train.py (2-level skill-options), residual_train.py (HL+residual).
# Each arm reports REAL held-out success (box_target>=0.9) vs env_steps in RESULTS.json. No --save_full_state.
set -u
HL=/root/tdmpc_glass/helios-rl/hl_pickcube
OUT=/root/tdmpc_glass/exp/hierarchy_sol
LOGS=$OUT/logs
mkdir -p "$OUT/arms" "$LOGS"
VENV=/root/tdmpc_glass/venv
PP="/root/tdmpc_glass/helios-rl/src:/root/tdmpc_glass/mujoco_playground_repo"
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.5"

run() {  # name gpu cmd...
  local name=$1 gpu=$2; shift 2
  local lg="$LOGS/$name.log"
  echo "[launch] $name -> GPU$gpu  log=$lg"
  setsid bash -c "cd $HL && source $VENV/bin/activate && env PYTHONPATH=$PP $COMMON CUDA_VISIBLE_DEVICES=$gpu $* >> '$lg' 2>&1" < /dev/null &
  sleep 20
}

# ---- Hierarchical arms: learned 2-level skill-options (mlp = context-conditioned subgoals) ----
# 3 seeds, full ES budget. Genuine 2-level hierarchy: pi_hi emits option params, analytic LL executes.
run hier_options_mlp_s0 1 "python options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed 0 --tag h_opt_mlp_s0 --out_dir $OUT/arms/hier_options_mlp_s0"
run hier_options_mlp_s1 2 "python options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed 1 --tag h_opt_mlp_s1 --out_dir $OUT/arms/hier_options_mlp_s1"
run hier_options_mlp_s2 3 "python options_train.py --mode mlp --pop 96 --envs_per 2 --iters 400 --eval_envs 512 --steps 150 --sigma 0.05 --lr 0.03 --seed 2 --tag h_opt_mlp_s2 --out_dir $OUT/arms/hier_options_mlp_s2"

echo "[launch] wave-1 (hier options mlp x3 seeds) launched on GPU 1,2,3"
