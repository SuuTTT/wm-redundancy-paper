#!/usr/bin/env bash
cd /root/tdmpc_glass/exp/hierarchy_sol
# wait until wave-4 roller has exited (state says done OR no roller proc)
while ! grep -q "wave4 done" logs/roller_b3060b_w4.state 2>/dev/null; do
  ps aux | grep roller_b3060b_w4.sh | grep -qv "grep" || break
  sleep 30
done
echo "w4 finished at $(date), starting w5" >> logs/chain_w5.log
nohup setsid bash roller_b3060b_w5.sh >logs/roller_b3060b_w5.out 2>&1 </dev/null &
echo "w5 launched pid $!" >> logs/chain_w5.log
