#!/usr/bin/env bash
set -u
RL=/root/tdmpc_glass/helios-rl; EXP=/root/tdmpc_glass/exp/tdmpc2_hopperhop_cov
COMMON="MJPG_IMPL=jax MUJOCO_GL=egl XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.42"
cd $RL
for s in 1 2; do
  gpu=$((s-1))  # seed1->GPU0, seed2->GPU1
  setsid bash -c "cd $RL && source ../venv/bin/activate 2>/dev/null; env PYTHONPATH=$RL/src:/root/tdmpc_glass/mujoco_playground_repo $COMMON A1_COVERAGE=1 A1_COLLECT=plan TDMPC_EVAL_INTERVAL=50000 TDMPC_GLASS_OUTPUT_TAG=tdmpc2hop_s${s} CUDA_VISIBLE_DEVICES=$gpu python -u scripts/run_benchmark.py --algos tdmpc2 --tasks HopperHop --total_steps 5000000 --seed $s --no_plot > $EXP/logs/seed${s}.log 2>&1" </dev/null &
done
wait
echo "TDMPC2_HOP_COV_DONE $(date)" >> $EXP/logs/drive.log
