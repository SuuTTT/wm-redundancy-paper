#!/usr/bin/env bash
set -u
EXP=/root/tdmpc_glass/exp; OUT=$EXP/C_hier_new; LOGS=$OUT/logs_fourroom; mkdir -p $LOGS $OUT/runs_fourroom
VENV=/root/tdmpc_glass/venv
for s in 3 4 5; do
  setsid bash -c "cd $EXP && source $VENV/bin/activate && CUDA_VISIBLE_DEVICES=2 XLA_PYTHON_CLIENT_MEM_FRACTION=0.25 python feudal_maze.py --arm flat --maze fourroom --seed $s --steps 400000 --out_dir $OUT/runs_fourroom >> $LOGS/flat_s${s}.log 2>&1" </dev/null &
  setsid bash -c "cd $EXP && source $VENV/bin/activate && CUDA_VISIBLE_DEVICES=3 XLA_PYTHON_CLIENT_MEM_FRACTION=0.25 python feudal_maze.py --arm feudal --maze fourroom --seed $s --steps 400000 --out_dir $OUT/runs_fourroom >> $LOGS/feudal_s${s}.log 2>&1" </dev/null &
  wait
done
echo "FOURROOM2_DONE $(date)" >> $LOGS/driver.log
