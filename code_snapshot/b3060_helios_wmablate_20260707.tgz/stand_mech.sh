#!/usr/bin/env bash
# 4th-task mechanism table: full 5-arm per-loss ablation on HopperStand (the wall morphology),
# seeds 1-4, one seed-chain per GPU. Launch AFTER ku64 finishes (GPU2 frees).
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/wm_head_ablation_stand
mkdir -p "$OUT/logs" "$OUT/jsonl"
DLOG=$OUT/driver.log
echo "[standmech] START $(date -u +%FT%TZ)" | tee -a "$DLOG"
seed_chain() {
  local gpu=$1 seed=$2
  for a in none value policy reward consistency; do
    echo "[standmech] gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=1000000 bash $REPO/run_arm_stand.sh
    echo "[standmech] gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
}
seed_chain 0 1 &
seed_chain 1 2 &
seed_chain 2 3 &
seed_chain 3 4 &
wait
touch "$OUT/STAND_MECH_DONE"
echo "[standmech] DONE $(date -u +%FT%TZ)" | tee -a "$DLOG"
