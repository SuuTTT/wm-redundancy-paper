#!/usr/bin/env bash
# HopperHop WM-ablation seeds 3/4 on GPU2/3 (freed by CheetahRun completion).
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/wm_head_ablation_hop
STEPS=${STEPS:-1000000}
ARMS="none value consistency reward policy"
mkdir -p "$OUT"
DLOG=$OUT/driver_s34.log
echo "[driver_hop_s34] START $(date -u +%FT%TZ)" | tee -a "$DLOG"
run_seed_on_gpu() {
  local gpu=$1 seed=$2
  for a in $ARMS; do
    echo "[driver_hop_s34] gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=$STEPS bash $REPO/run_arm_hop.sh
    echo "[driver_hop_s34] gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
  touch "$OUT/gpu${gpu}_seed${seed}.done"
}
run_seed_on_gpu 2 3 &
P2=$!
run_seed_on_gpu 3 4 &
P3=$!
wait $P2 $P3
touch "$OUT/WM_ABLATION_HOP_S34_DONE"
echo "[driver_hop_s34] DONE $(date -u +%FT%TZ)" | tee -a "$DLOG"
