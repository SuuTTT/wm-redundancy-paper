"""SE-community subgoal HL for hierarchical exploration (Thread E / A3).

SE's real strength is COMMUNITY + HIERARCHY DISCOVERY, never used for control here
(prior work used SE only as a latent *regularizer* — D1/D2 null). This module uses
SE's community-partition OUTPUT to drive exploration:

  1. Periodically build a symmetric kNN graph over replay-buffer TD-MPC2 latents and
     partition it with selib min-2D structural entropy (louvain_se) into communities
     (abstract states). Community centroids = candidate subgoals.
  2. A high level (HL) assigns each env an UNDER-VISITED community as its current subgoal.
  3. The low level (LL = existing TD-MPC2 policy/planner) is steered toward that subgoal
     via a potential-based goal-distance shaping reward (progress = prev_dist - dist),
     normalized. Reassign the subgoal every K per-env steps or when reached.

TRACTABLE-VERSION NOTE (honest): this is the reward-shaping realization of the
option/subgoal HL. The plan explicitly sanctions "reward+goal-distance" as the LL
mechanism. It is NOT a separate goal-conditioned MPPI controller — that would need to
re-jit the planner reward; reward shaping keeps the LL/optimizer/budget IDENTICAL to
flat TD-MPC2, so the matched-budget control is exact (flat = coef 0 / mode off).
All host-side numpy + one selib partition every rebuild_every env-steps.
"""
import sys
import numpy as np

if "/root/helios-rl/selib" not in sys.path:
    sys.path.insert(0, "/root/helios-rl/selib")


def _knn_affinity(Z, knn):
    Zn = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-9)
    S = Zn @ Zn.T
    np.fill_diagonal(S, -1.0)
    A = np.zeros_like(S)
    idx = np.argpartition(-S, knn, axis=1)[:, :knn]
    rows = np.repeat(np.arange(S.shape[0]), knn)
    cols = idx.reshape(-1)
    A[rows, cols] = np.clip(S[rows, cols], 0.0, None)
    return np.maximum(A, A.T)


class SESubgoalHL:
    def __init__(self, n_envs, latent_dim, coef=0.3, knn=10, max_comm=32,
                 rebuild_every=50_000, reassign_every_env=64, buf_cap=4096,
                 reach_frac=0.5, top_m=8, seed=0):
        self.N = n_envs
        self.coef = float(coef)
        self.knn = int(knn)
        self.max_comm = int(max_comm)
        self.rebuild_every = int(rebuild_every)      # in ENV steps
        self.reassign_every = int(reassign_every_env)  # in PER-ENV (collection) steps
        self.reach_frac = float(reach_frac)
        self.top_m = int(top_m)
        self.rng = np.random.default_rng(seed)
        self.zbuf = np.zeros((buf_cap, latent_dim), np.float32)
        self.zcap = buf_cap
        self.zn = 0
        self.zi = 0
        self.centroids = None                # (C, latent)
        self.visits = None                   # (C,)
        self.reach_thresh = None
        self.env_goal = -np.ones(n_envs, np.int64)
        self.env_prev_d = np.zeros(n_envs, np.float32)
        self.nstep = 0                       # collection steps since last reassign boundary
        self.last_rebuild_env = -10**18
        # running std of raw progress for normalization
        self.r_mean = 0.0
        self.r_var = 1.0
        self.r_n = 0
        self.logs = []                       # partition summaries (harvestable)

    def push(self, Z):
        Z = np.asarray(Z, np.float32)
        for j in range(Z.shape[0]):
            self.zbuf[self.zi] = Z[j]
            self.zi = (self.zi + 1) % self.zcap
            self.zn = min(self.zn + 1, self.zcap)

    def _partition(self, env_steps):
        import networkx as nx
        from selib.seopt import louvain_se, _merge_down_to_k
        n = min(self.zn, 800)
        # most-recent n latents
        if self.zn < self.zcap:
            Zs = self.zbuf[max(0, self.zn - n):self.zn].copy()
        else:
            order = (self.zi - 1 - np.arange(n)) % self.zcap
            Zs = self.zbuf[order].copy()
        A = _knn_affinity(Zs, self.knn)
        G = nx.from_numpy_array(A)
        labels = np.asarray(louvain_se(G, seed=0))
        C = int(labels.max()) + 1
        if C > self.max_comm:
            labels = np.asarray(_merge_down_to_k(G, list(labels), self.max_comm, seed=0))
            C = int(labels.max()) + 1
        cents = np.stack([Zs[labels == c].mean(0) for c in range(C)]).astype(np.float32)
        # typical centroid spacing -> reach threshold
        cc = np.sqrt(((cents[:, None, :] - cents[None, :, :]) ** 2).sum(-1))
        np.fill_diagonal(cc, np.inf)
        self.reach_thresh = self.reach_frac * float(np.median(cc.min(1)))
        self.centroids = cents
        self.visits = np.ones(C, np.float64)   # laplace-smoothed
        self.env_goal[:] = -1
        sizes = sorted((labels == c).sum() for c in range(C))
        summary = dict(env_steps=int(env_steps), n_comm=int(C), n_nodes=int(len(labels)),
                       sizes_min=int(sizes[0]), sizes_max=int(sizes[-1]),
                       sizes_med=int(np.median(sizes)), reach_thresh=self.reach_thresh)
        self.logs.append(summary)
        print(f"  [SE-subgoal] partition @ env_steps={env_steps:,}: {C} communities "
              f"(nodes={len(labels)}, sizes min/med/max={sizes[0]}/{int(np.median(sizes))}/{sizes[-1]}, "
              f"reach_thresh={self.reach_thresh:.3f})", flush=True)
        return summary

    def _dists_to(self, Z, cent_idx):
        c = self.centroids[cent_idx]                 # (N, latent)
        return np.sqrt(((Z - c) ** 2).sum(-1))

    def step(self, Z_new, env_steps):
        """Z_new: (N, latent) current latents. Returns shaping bonus (N,) already
        scaled by coef and normalized. Mutates internal HL state."""
        Z_new = np.asarray(Z_new, np.float32)
        self.push(Z_new)
        if self.centroids is None or (env_steps - self.last_rebuild_env) >= self.rebuild_every:
            if self.zn >= max(200, self.knn * 4):
                self._partition(env_steps)
                self.last_rebuild_env = env_steps
        if self.centroids is None:
            return np.zeros(self.N, np.float32)

        C = self.centroids.shape[0]
        # coverage: nearest-centroid assignment of current latents
        d_all = np.sqrt(((Z_new[:, None, :] - self.centroids[None, :, :]) ** 2).sum(-1))  # (N,C)
        cur_comm = d_all.argmin(1)
        np.add.at(self.visits, cur_comm, 1.0)

        self.nstep += 1
        boundary = (self.nstep % self.reassign_every) == 0
        has_goal = self.env_goal >= 0
        d_goal = np.where(has_goal, d_all[np.arange(self.N), np.clip(self.env_goal, 0, C - 1)], np.inf)
        reached = has_goal & (d_goal < self.reach_thresh)
        reassign = (~has_goal) | reached | boundary

        if reassign.any():
            # rank communities by visits ascending; spread reassigned envs across the
            # top_m least-visited communities (diversify targets, avoid herding)
            order = np.argsort(self.visits)                       # least-visited first
            pool = order[:min(self.top_m, C)]
            ridx = np.where(reassign)[0]
            picks = pool[self.rng.integers(0, len(pool), size=len(ridx))]
            self.env_goal[ridx] = picks

        # distances to (possibly updated) goals
        d_now = d_all[np.arange(self.N), np.clip(self.env_goal, 0, C - 1)]
        progress = self.env_prev_d - d_now                        # +ve = moved closer
        progress[reassign] = 0.0                                  # no spurious jump on (re)assign
        self.env_prev_d = d_now.astype(np.float32)

        # running-std normalization (match other intrinsics' scale handling)
        b = progress.astype(np.float64)
        self.r_n += b.size
        dm = b.mean() - self.r_mean
        self.r_mean += dm * (b.size / max(self.r_n, 1))
        self.r_var = 0.99 * self.r_var + 0.01 * float(b.var() + 1e-8)
        norm = self.coef * (progress / (np.sqrt(self.r_var) + 1e-8))
        return norm.astype(np.float32)
