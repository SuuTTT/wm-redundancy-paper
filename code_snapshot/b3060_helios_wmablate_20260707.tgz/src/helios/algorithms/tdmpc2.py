"""TD-MPC2 JAX implementation — v24 milestone.

Milestone: MPPI=357@3M, stable 340–357 from 1.25M onwards on HopperHop.
Key innovations vs prior versions:
- SimNorm(V=8) encoder and dynamics (bounded latents)
- Two-hot distributional Q/reward with symlog/symexp
- MPPI planner with elite-based selection, pi-trajectory seeding
- RunningScale (IQR-based, EMA tau=0.01) capped at [1.0, 4.0] — prevents
  gradient crushing while maintaining stability (v24 key fix over v18)
- lax.scan fused multi-update loop (K gradient steps in one JIT dispatch)

Architecture:
    latent_dim=512, hidden=(512,512), num_bins=101, vmin/vmax=±20
    MPPI: H=3, NS=512, num_elites=64, num_pi_trajs=24, n_iter=6
    std range: [0.05, 2.0]

Ref: Hansen et al. (2023) TD-MPC2 — https://arxiv.org/abs/2310.16828
"""
from __future__ import annotations

import os as _os
import numpy as np
import jax
import jax.numpy as jnp
import flax.linen as nn
import optax


# ---------------------------------------------------------------------------
# SimNorm and math utilities
# ---------------------------------------------------------------------------


def simnorm(x: jax.Array, V: int = 8) -> jax.Array:
    """Simplex normalisation: partition into V groups, softmax each group."""
    s = x.shape
    x = x.reshape(*s[:-1], V, s[-1] // V)
    x = jax.nn.softmax(x, axis=-1)
    return x.reshape(*s)


# ---------------------------------------------------------------------------
# unif_dmc study: relational anti-collapse terms on the SimNorm latent.
# Env-gated (UNIF_COEF / VICREG_COEF) so the traced graph is byte-identical to
# vanilla TD-MPC2 when both are 0 (default) -> fleet-safe matched control.
# ---------------------------------------------------------------------------
def uniformity_loss(z, t: float = 2.0):
    """Wang & Isola (2020) UNIFORMITY: log E_{i!=j} exp(-t ||z_i - z_j||^2).
    Purely pairwise relational repulsion on the batch latents (MINIMIZED)."""
    g = z @ z.T
    dd = jnp.diag(g)
    D = jnp.clip(dd[:, None] + dd[None, :] - 2.0 * g, 0.0, None)
    B = z.shape[0]
    mask = 1.0 - jnp.eye(B)
    logits = jnp.where(mask > 0, -t * D, -jnp.inf)
    lse = jax.nn.logsumexp(logits)
    return lse - jnp.log(mask.sum())


def vicreg_loss(z, eps: float = 1e-4):
    """Per-dim VICReg anti-collapse: variance hinge + off-diagonal covariance.
    (No invariance term; the consistency loss is TD-MPC2's invariance analog.)"""
    zc = z - z.mean(0, keepdims=True)
    std = jnp.sqrt(zc.var(0) + eps)
    var_loss = jnp.mean(jax.nn.relu(1.0 - std))
    N, D = z.shape
    cov = (zc.T @ zc) / (N - 1)
    off = cov - jnp.diag(jnp.diag(cov))
    cov_loss = jnp.sum(off ** 2) / D
    return var_loss + cov_loss


def value_aware_uniformity_loss(z, v, t: float = 2.0, attract: float = 0.5):
    """VALUE-AWARE anti-collapse (valunif).

    Plain Wang&Isola UNIFORMITY repels *all* pairs equally, which spreads apart
    states that should be VALUE-CLOSE and destroys value-sufficiency (the failure
    mode we isolated on DMControl). This term makes the anti-collapse signal
    value-aware by GATING the repulsion with value distance and adding a matched
    attraction:

      v_i    : per-state scalar value V(s_i)=max(min_k Q_k(z_i, pi(z_i)),0), STOP-GRAD
               (the same quantity used to form the TD target; used here only as a label).
      sigma  : batch std of v (adaptive scale, no extra hyperparameter).
      close  = exp(-|v_i-v_j|/sigma)   ~1 value-similar, ~0 value-different
      far    = 1 - close               repulsion weight (value-different pairs only)

      repel  = log E_{i!=j} far_ij * exp(-t ||z_i-z_j||^2)      (uniformity, value-gated)
      attr   = E_{i!=j} close_ij * ||z_i-z_j||^2                (pull value-close together)
      loss   = repel + attract * attr

    Grad flows to the ENCODER through ||z_i-z_j||^2 (z carries grad); v is stop-grad.
    Collapse resistance is preserved (value-different pairs are pushed apart) WITHOUT
    repelling value-similar states; if uniformity hurts because it ignores value
    structure, this is the matched fix.
    """
    B = z.shape[0]
    g = z @ z.T
    dd = jnp.diag(g)
    D = jnp.clip(dd[:, None] + dd[None, :] - 2.0 * g, 0.0, None)   # ||z_i - z_j||^2
    vd = jnp.abs(v[:, None] - v[None, :])                          # value distance
    sigma = jnp.maximum(jnp.std(v), 1e-3)
    close = jnp.exp(-vd / sigma)
    far = 1.0 - close
    mask = 1.0 - jnp.eye(B)
    # value-gated repulsion (uniformity restricted to value-different pairs)
    logits = jnp.where(mask > 0, jnp.log(far + 1e-6) - t * D, -jnp.inf)
    repel = jax.nn.logsumexp(logits) - jnp.log(jnp.sum(mask * far) + 1e-6)
    # value-close attraction
    wclose = mask * close
    attr = jnp.sum(wclose * D) / (jnp.sum(wclose) + 1e-6)
    return repel + attract * attr




# ---------------------------------------------------------------------------
# SE arm (se / se_unif): differentiable min-2D-SE (Li & Pan 2016) on a kNN
# latent graph. Ported verbatim from hjepa_navctrl/se_latent.py (the nav study
# SE loss). Env-gated by SE_COEF so the traced graph is byte-identical to
# vanilla TD-MPC2 when SE_COEF==0. Called INSIDE the already-jitted loss, so no
# @jax.jit decorators here (k, K are concrete Python ints read from env at trace
# time -> static, exactly like UNIF_COEF).
#   H^2 = -sum_v (d_v/2m) log2(d_v/Vol_c(v)) - sum_k (cut_k/2m) log2(Vol_k/2m)
# MINIMIZED: pushes the batch-latent kNN graph toward clearer community
# structure (low structural entropy).
# ---------------------------------------------------------------------------
_SE_LOG2 = jnp.log(2.0)

def _se_pairwise_sq(z):
    g = z @ z.T
    d = jnp.diag(g)
    return jnp.clip(d[:, None] + d[None, :] - 2.0 * g, 0.0, None)

def _se_pairwise_sq2(z, c):
    zz = (z * z).sum(1)[:, None]
    cc = (c * c).sum(1)[None, :]
    return jnp.clip(zz + cc - 2.0 * z @ c.T, 0.0, None)

def _se_build_knn_affinity(z, k, eps=1e-8):
    B = z.shape[0]
    D = _se_pairwise_sq(z)
    Dm = D + jnp.eye(B) * 1e9
    idx = jax.lax.stop_gradient(jnp.argsort(Dm, axis=1)[:, :k])
    mask = jnp.zeros((B, B)).at[jnp.arange(B)[:, None], idx].set(1.0)
    mask = jnp.maximum(mask, mask.T)
    kept = jnp.where(mask > 0, D, jnp.nan)
    sigma2 = jax.lax.stop_gradient(jnp.nanmedian(kept) + eps)
    W = jnp.exp(-D / (2.0 * sigma2)) * mask
    W = W * (1.0 - jnp.eye(B))
    return W

def _se_kmeans_onehot(z, K, key, iters=8):
    z = jax.lax.stop_gradient(z)
    B = z.shape[0]
    c0 = z[jax.random.choice(key, B, (K,), replace=False)]
    def step(c, _):
        D = _se_pairwise_sq2(z, c)
        lab = jnp.argmin(D, axis=1)
        onehot = jax.nn.one_hot(lab, K)
        cnt = onehot.sum(0)[:, None] + 1e-8
        c = (onehot.T @ z) / cnt
        return c, lab
    c, _ = jax.lax.scan(step, c0, None, length=iters)
    lab = jnp.argmin(_se_pairwise_sq2(z, c), axis=1)
    return jax.nn.one_hot(lab, K)

def _se_from_W_S(W, S, eps=1e-12):
    d = W.sum(1)
    twom = d.sum() + eps
    Vol = S.T @ d
    internal = jnp.einsum("ik,ij,jk->k", S, W, S)
    cut = Vol - internal
    Vol_v = S @ Vol
    node = -jnp.sum(jnp.where(d > 0, (d / twom) * jnp.log(jnp.clip(d / (Vol_v + eps), eps, None)) / _SE_LOG2, 0.0))
    comm = -jnp.sum(jnp.where((cut > 0) & (Vol > 0), (cut / twom) * jnp.log(jnp.clip(Vol / twom, eps, None)) / _SE_LOG2, 0.0))
    return node + comm

def se2d_loss_core(z, key, k=10, K=8):
    """Differentiable 2D structural entropy (bits) of the batch latents kNN
    graph under a JAX k-means partition. MINIMIZED. Matches selib
    metrics.structural_entropy_2d / hjepa_navctrl.se_latent.se2d_loss."""
    W = _se_build_knn_affinity(z, k)
    S = _se_kmeans_onehot(z, K, key)
    return _se_from_W_S(W, S)


def log_std_fn(x: jax.Array, low: float = -10.0, dif: float = 12.0) -> jax.Array:
    """Map raw network output to log_std in [low, low+dif]."""
    return low + 0.5 * dif * (jnp.tanh(x) + 1.0)


def gaussian_logprob(eps: jax.Array, log_std: jax.Array) -> jax.Array:
    """Log probability of eps under N(0,1) reparameterized with log_std."""
    residual = -0.5 * (eps ** 2) - log_std
    log_prob = residual - 0.9189385175704956  # -0.5 * log(2π)
    return jnp.sum(log_prob, axis=-1, keepdims=True)


def squash(
    mu: jax.Array, pi: jax.Array, log_pi: jax.Array
) -> tuple[jax.Array, jax.Array, jax.Array]:
    """Apply tanh squashing with Jacobian correction to log_pi."""
    mu = jnp.tanh(mu)
    pi = jnp.tanh(pi)
    squashed_pi = jnp.log(jax.nn.relu(1 - pi ** 2) + 1e-6)
    log_pi = log_pi - jnp.sum(squashed_pi, axis=-1, keepdims=True)
    return mu, pi, log_pi


def symlog(x: jax.Array) -> jax.Array:
    """Symmetric log: sign(x) * log(1 + |x|)."""
    return jnp.sign(x) * jnp.log(1 + jnp.abs(x))


def symexp(x: jax.Array) -> jax.Array:
    """Inverse of symlog: sign(x) * (exp(|x|) - 1)."""
    return jnp.sign(x) * (jnp.exp(jnp.abs(x)) - 1)


def two_hot(
    x: jax.Array, vmin: float = -20.0, vmax: float = 20.0, num_bins: int = 101
) -> jax.Array:
    """Two-hot encoding in symlog space.

    Clips symlog(x) to [vmin, vmax] then distributes weight between the two
    nearest bin indices proportionally.
    """
    x = jnp.clip(symlog(x), vmin, vmax)
    bin_size = (vmax - vmin) / (num_bins - 1)
    bin_index = (x - vmin) / bin_size
    lower = jnp.floor(bin_index).astype(jnp.int32)
    upper = jnp.ceil(bin_index).astype(jnp.int32)
    p_upper = bin_index - lower
    p_lower = 1.0 - p_upper
    lower_hot = jax.nn.one_hot(lower, num_bins) * p_lower[..., None]
    upper_hot = jax.nn.one_hot(upper, num_bins) * p_upper[..., None]
    return lower_hot + upper_hot


def soft_ce(pred: jax.Array, target: jax.Array) -> jax.Array:
    """Cross-entropy loss for distributional targets."""
    return -jnp.sum(target * jax.nn.log_softmax(pred, axis=-1), axis=-1)


def two_hot_inv(
    logits: jax.Array, vmin: float = -20.0, vmax: float = 20.0, num_bins: int = 101
) -> jax.Array:
    """Decode distributional logits back to scalar in original space."""
    probs = jax.nn.softmax(logits, axis=-1)
    bins = jnp.linspace(vmin, vmax, num_bins)
    return symexp(jnp.sum(probs * bins, axis=-1))


# ---------------------------------------------------------------------------
# Network modules
# ---------------------------------------------------------------------------


class NormMLP(nn.Module):
    """Dense → LayerNorm → SiLU stack with a final linear output."""

    dims: tuple[int, ...]
    out: int

    @nn.compact
    def __call__(self, x: jax.Array) -> jax.Array:
        for d in self.dims:
            x = nn.Dense(d)(x)
            x = nn.LayerNorm()(x)
            x = nn.silu(x)
        return nn.Dense(self.out)(x)


class GroupAttn(nn.Module):
    """iter-27 arch A/B (attn): group-wise self-attention over SimNorm's V latent
    groups. The pre-norm latent (latent_dim) is reshaped into V tokens of dim
    latent_dim//V; a 1-block pre-LN transformer (multi-head attention + gated FFN)
    lets the V soft-categorical groups exchange information before the simplex
    projection; then it's flattened back to latent_dim. SimNorm/FSQ is applied by
    the caller afterward, so the latent geometry is unchanged — only the backbone
    that produces the pre-norm vector differs from the plain NormMLP. Single-variable
    swap vs --dyn_arch mlp."""

    V: int = 8
    heads: int = 4

    @nn.compact
    def __call__(self, x: jax.Array) -> jax.Array:
        D = x.shape[-1] // self.V
        t = x.reshape(x.shape[:-1] + (self.V, D))
        t = t + nn.MultiHeadDotProductAttention(num_heads=self.heads)(nn.LayerNorm()(t))
        r = nn.LayerNorm()(t)
        t = t + nn.Dense(D)(nn.silu(nn.Dense(2 * D)(r)))
        return t.reshape(x.shape)


class ResGatedMLP(nn.Module):
    """iter-27 arch A/B (resmlp): deeper gated-residual backbone replacing the plain
    NormMLP. Project to `width`, then `blocks` pre-LN gated residual blocks
    (SiLU(Dense) * sigmoid(Dense) gate, residual-added), final linear to `out`. More
    depth + gating than the 2-layer NormMLP at a comparable width. Single-variable
    swap vs --dyn_arch mlp."""

    width: int
    out: int
    blocks: int = 4

    @nn.compact
    def __call__(self, x: jax.Array) -> jax.Array:
        h = nn.Dense(self.width)(x)
        for _ in range(self.blocks):
            r = nn.LayerNorm()(h)
            a = nn.silu(nn.Dense(self.width)(r))
            g = nn.sigmoid(nn.Dense(self.width)(r))
            h = h + a * g
        return nn.Dense(self.out)(h)


def _arch_backbone(arch: str, x: jax.Array, hidden, latent_dim: int, V: int) -> jax.Array:
    """iter-27: produce the pre-norm latent vector via the chosen backbone. Used by
    Encoder/Dynamics/JumpyDynamics so the arch swap is a one-line branch each."""
    if arch == "resmlp":
        return ResGatedMLP(hidden[0], latent_dim)(x)
    if arch == "attn":
        return GroupAttn(V)(NormMLP(hidden, latent_dim)(x))
    return NormMLP(hidden, latent_dim)(x)


def fsq(x: jax.Array, levels: int = 5) -> jax.Array:
    """iter-16: Finite Scalar Quantization latent bound (DC-MPC-style discrete
    codes, table-free). tanh-bound each dim, round to `levels` uniform values in
    [-1, 1], straight-through estimator for gradients. Replaces SimNorm when
    latent_norm='fsq' — a representation SWAP (direction #3 of the Six-Mirages
    post-mortem), not an auxiliary loss."""
    z = jnp.tanh(x)
    zq = jnp.round((z * 0.5 + 0.5) * (levels - 1)) / (levels - 1) * 2.0 - 1.0
    return z + jax.lax.stop_gradient(zq - z)


class Encoder(nn.Module):
    """Encodes observations to SimNorm- (or FSQ-) bounded latent vectors."""

    latent_dim: int
    hidden: tuple[int, ...] = (512, 512)
    V: int = 8
    latent_norm: str = "simnorm"  # iter-16: "simnorm" | "fsq"
    fsq_levels: int = 5
    arch: str = "mlp"  # iter-27: "mlp" | "attn" | "resmlp"

    @nn.compact
    def __call__(self, obs: jax.Array) -> jax.Array:
        h = _arch_backbone(self.arch, obs, self.hidden, self.latent_dim, self.V)
        if self.latent_norm == "fsq":
            return fsq(h, self.fsq_levels)
        return simnorm(h, self.V)


class Dynamics(nn.Module):
    """Predicts next latent from (z, a) using SimNorm- (or FSQ-) bounded output."""

    latent_dim: int
    hidden: tuple[int, ...] = (512, 512)
    V: int = 8
    latent_norm: str = "simnorm"  # iter-16: "simnorm" | "fsq"
    fsq_levels: int = 5
    arch: str = "mlp"  # iter-27: "mlp" | "attn" | "resmlp"

    @nn.compact
    def __call__(self, z: jax.Array, a: jax.Array) -> jax.Array:
        h = _arch_backbone(
            self.arch, jnp.concatenate([z, a], -1), self.hidden, self.latent_dim, self.V
        )
        if self.latent_norm == "fsq":
            return fsq(h, self.fsq_levels)
        return simnorm(h, self.V)


class JumpyDynamics(nn.Module):
    """iter-22: k-step JUMPY latent model. Predicts z_{t+k} directly from z_t and the
    concatenated k-action sequence (k*act_dim) — one model call per k steps, so MPPI can
    plan a long effective horizon WITHOUT compounding the 1-step model k times. SimNorm
    output keeps the same latent geometry as the 1-step dynamics."""

    latent_dim: int
    hidden: tuple[int, ...] = (512, 512)
    V: int = 8
    arch: str = "mlp"  # iter-27: "mlp" | "attn" | "resmlp"

    @nn.compact
    def __call__(self, z: jax.Array, a_concat: jax.Array) -> jax.Array:
        return simnorm(
            _arch_backbone(
                self.arch, jnp.concatenate([z, a_concat], -1), self.hidden, self.latent_dim, self.V
            ),
            self.V,
        )


class JumpyReward(nn.Module):
    """iter-22: k-step macro-reward predictor — sum of the k rewards over a jump, from z_t and
    the concatenated k-action sequence. Distributional (two-hot, symlog handles the larger
    summed range). Lets jumpy-MPPI accumulate reward over macro-steps without intermediate z."""

    hidden: tuple[int, ...] = (512, 512)
    num_bins: int = 101

    @nn.compact
    def __call__(self, z: jax.Array, a_concat: jax.Array) -> jax.Array:
        x = jnp.concatenate([z, a_concat], -1)
        for d in self.hidden:
            x = nn.silu(nn.LayerNorm()(nn.Dense(d)(x)))
        return nn.Dense(self.num_bins)(x)


class RewardHead(nn.Module):
    """Distributional reward predictor (101-bin two-hot)."""

    hidden: tuple[int, ...] = (512, 512)
    num_bins: int = 101

    @nn.compact
    def __call__(self, z: jax.Array, a: jax.Array) -> jax.Array:
        return NormMLP(self.hidden, self.num_bins)(jnp.concatenate([z, a], -1))


class QEnsemble(nn.Module):
    """Two-head Q ensemble with distributional outputs (101-bin two-hot).

    Returns shape (..., 2, num_bins). Take jnp.min over axis=-2 after
    two_hot_inv to get the min-Q value estimate.
    """

    hidden: tuple[int, ...] = (512, 512)
    num_bins: int = 101

    @nn.compact
    def __call__(self, z: jax.Array, a: jax.Array) -> jax.Array:
        x = jnp.concatenate([z, a], -1)
        return jnp.stack(
            [NormMLP(self.hidden, self.num_bins)(x),
             NormMLP(self.hidden, self.num_bins)(x)],
            axis=-2,
        )


class Pi(nn.Module):
    """Stochastic Gaussian policy with tanh squashing.

    Outputs (mean, log_std). Use sample_pi() to sample an action.
    For deterministic execution: action = tanh(mean).
    """

    action_dim: int
    hidden: tuple[int, ...] = (512, 512)
    log_std_min: float = -10.0
    log_std_dif: float = 12.0

    @nn.compact
    def __call__(self, z: jax.Array) -> tuple[jax.Array, jax.Array]:
        x = NormMLP(self.hidden, self.action_dim * 2)(z)
        mean, log_std = jnp.split(x, 2, axis=-1)
        log_std = log_std_fn(log_std, self.log_std_min, self.log_std_dif)
        return mean, log_std


def sample_pi(
    mean_logstd: tuple[jax.Array, jax.Array], key: jax.Array
) -> tuple[jax.Array, jax.Array, jax.Array]:
    """Sample a tanh-squashed action from the policy distribution.

    Args:
        mean_logstd: (mean, log_std) from Pi.__call__
        key: PRNGKey

    Returns:
        (action, log_prob, scaled_entropy)
    """
    mean, log_std = mean_logstd
    eps = jax.random.normal(key, mean.shape)
    log_prob = gaussian_logprob(eps, log_std)
    size = eps.shape[-1]
    scaled_log_prob = log_prob * size
    action_pre = mean + eps * jnp.exp(log_std)
    _, action, log_prob = squash(mean, action_pre, log_prob)
    entropy_scale = scaled_log_prob / (log_prob + 1e-8)
    scaled_entropy = -log_prob * entropy_scale
    return action, log_prob, scaled_entropy


# ---------------------------------------------------------------------------
# Multi-environment replay buffer
# ---------------------------------------------------------------------------


class MultiEnvBuffer:
    """Per-environment ring buffer storing (obs, act, rew, done) transitions.

    Stores separate circular buffers for each environment to allow
    sampling contiguous sequences without episode boundary contamination.

    Args:
        cap:     Per-environment buffer capacity.
        n_envs:  Number of parallel environments.
        obs_dim: Observation dimensionality.
        act_dim: Action dimensionality.
        seq_len: Sequence length T (horizon H+1) for each sampled batch.
    """

    def __init__(
        self,
        cap: int,
        n_envs: int,
        obs_dim: int,
        act_dim: int,
        seq_len: int,
    ) -> None:
        self.cap = cap
        self.N = n_envs
        self.T = seq_len
        self.obs  = np.zeros((n_envs, cap, obs_dim), np.float32)
        self.acts = np.zeros((n_envs, cap, act_dim), np.float32)
        self.rews = np.zeros((n_envs, cap), np.float32)
        self.done = np.zeros((n_envs, cap), np.float32)
        self.ptr  = np.zeros(n_envs, np.int64)
        self.size = np.zeros(n_envs, np.int64)

    def add_batch(
        self,
        obs_b: np.ndarray,
        acts_b: np.ndarray,
        rews_b: np.ndarray,
        done_b: np.ndarray,
    ) -> None:
        """Insert one transition per environment."""
        p = self.ptr
        self.obs[np.arange(self.N), p]  = obs_b
        self.acts[np.arange(self.N), p] = acts_b
        self.rews[np.arange(self.N), p] = rews_b
        self.done[np.arange(self.N), p] = done_b
        self.ptr  = (p + 1) % self.cap
        self.size = np.minimum(self.size + 1, self.cap)

    def total_size(self) -> int:
        return int(self.size.sum())

    def sample(self, B: int, rng: np.random.Generator) -> tuple | None:
        """Sample B independent sequences of length T."""
        valid = np.where(self.size >= self.T + 1)[0]
        if len(valid) == 0:
            return None
        env_ids = rng.choice(valid, size=B, replace=True)
        sizes   = self.size[env_ids]
        starts  = (rng.random(B) * (sizes - self.T)).astype(np.int64)
        idx     = starts[:, None] + np.arange(self.T)[None, :]
        return (
            self.obs[env_ids[:, None], idx],
            self.acts[env_ids[:, None], idx],
            self.rews[env_ids[:, None], idx],
            self.done[env_ids[:, None], idx],
        )

    def sample_k(
        self, K: int, B: int, rng: np.random.Generator
    ) -> tuple | None:
        """Sample K×B sequences in one vectorised numpy call.

        Returns arrays shaped (K, B, T, dim) suitable for lax.scan.
        """
        valid = np.where(self.size >= self.T + 1)[0]
        if len(valid) == 0:
            return None
        KB      = K * B
        env_ids = rng.choice(valid, size=KB, replace=True)
        sizes   = self.size[env_ids]
        starts  = (rng.random(KB) * (sizes - self.T)).astype(np.int64)
        idx     = starts[:, None] + np.arange(self.T)[None, :]
        obs_kb  = self.obs [env_ids[:, None], idx]
        acts_kb = self.acts[env_ids[:, None], idx]
        rews_kb = self.rews[env_ids[:, None], idx]
        done_kb = self.done[env_ids[:, None], idx]
        obs_dim = obs_kb.shape[-1]
        act_dim = acts_kb.shape[-1]
        return (
            obs_kb.reshape(K, B, self.T, obs_dim),
            acts_kb.reshape(K, B, self.T, act_dim),
            rews_kb.reshape(K, B, self.T),
            done_kb.reshape(K, B, self.T),
        )


# ---------------------------------------------------------------------------
# Update function factory
# ---------------------------------------------------------------------------


def make_update_fn(
    enc: Encoder,
    dyn: Dynamics,
    rew_net: RewardHead,
    q_net: QEnsemble,
    pi_net: Pi,
    tx: optax.GradientTransformation,
    gamma: float = 0.99,
    rho: float = 0.5,
    tau: float = 0.01,
    rew_scale: float = 10.0,
    scale_min: float = 1.0,
    scale_max: float = 4.0,
    latent_action_smooth_coef: float = 0.0,
    consistency_coef: float = 2.0,
    smoothing_enabled: bool = True,
    mpc_distill_enabled: bool = False,
    bisim_coef: float = 0.0,
    jumpy_net: "JumpyDynamics | None" = None,
    jumpy_rew_net: "JumpyReward | None" = None,
    jumpy_k: int = 0,
    jumpy_coef: float = 1.0,
    jumpy_ve_coef: float = 0.0,   # iter-25 probe#2: value-equivalent macro head (0=off=state-faithful)
    calib_coef: float = 0.0,      # iter-30: calibration-shaped jumpy disagreement (0=off; needs jumpy_k>0)
    calib_q: float = 0.9,         # iter-30: pinball quantile — train disc to upper-bound err at this quantile
    rnd_net=None,                 # A2: RND net for latent-novelty predictor training (None=off)
    rnd_tgt_params=None,          # A2: fixed random target params
    rnd_coef: float = 0.0,        # A2: predictor training weight (0=off)
) -> tuple:
    """Build (single_step, multi_step) JIT-compiled update functions.

    RunningScale (v24):
        Tracks IQR (5th–95th percentile) of Q_pi values via EMA (tau=0.01).
        Capped to [scale_min, scale_max] = [1.0, 4.0].
        Pi loss = -mean(min(Q/scale)) over the rollout horizon.

    Args:
        enc, dyn, rew_net, q_net, pi_net: Flax modules (uninitialised).
        tx:         Optax gradient transform (applied to all params).
        gamma:      Discount factor.
        rho:        Consistency loss horizon decay (weight = rho^t).
        tau:        EMA coefficient for target params and RunningScale.
        rew_scale:  Reward scaling factor (targets multiplied, MPPI divided).
        scale_min:  RunningScale lower bound (prevents gradient collapse).
        scale_max:  RunningScale upper bound (v24 fix — prevents over-normalisation).

    Returns:
        (single_step, multi_step) — both @jax.jit compiled.
    """

    def loss_fn(params, tp, obs_b, act_b, rew_b, done_b, rng, scale,
                mpc_obs_anchor, mpc_action_target, mpc_distill_coef):
        B, T, _ = obs_b.shape
        z_all = enc.apply(params["enc"], obs_b.reshape(B * T, -1)).reshape(B, T, -1)
        z0    = z_all[:, 0]
        acts_T = jnp.transpose(act_b[:, :-1], (1, 0, 2))

        def dyn_step(z, a):
            return dyn.apply(params["dyn"], z, a), z

        z_final, zs_prefix = jax.lax.scan(dyn_step, z0, acts_T)
        zs = jnp.concatenate(
            [jnp.transpose(zs_prefix, (1, 0, 2)), z_final[:, None, :]], 1
        )

        z_tgt   = jax.lax.stop_gradient(z_all)
        weights = jnp.array([rho ** t for t in range(T - 1)])
        z_t_T   = jnp.transpose(zs[:, :-1],  (1, 0, 2))
        a_T     = acts_T
        r_T     = jnp.transpose(rew_b[:, :-1],  (1, 0))
        d_T     = jnp.transpose(done_b[:, :-1], (1, 0))
        z_t1_T  = jnp.transpose(z_tgt[:, 1:],   (1, 0, 2))
        zs_t1_T = jnp.transpose(zs[:, 1:],      (1, 0, 2))

        def step_loss(carry, inp):
            k, s = carry
            w, z_t, a_t, r_t, d_t, z_tgt_t1, zs_t1 = inp

            # Consistency loss
            cl = w * jnp.mean(jnp.sum((zs_t1 - z_tgt_t1) ** 2, -1))

            # Reward loss (distributional)
            pr = rew_net.apply(params["rew"], z_t, a_t)
            rl = w * jnp.mean(soft_ce(pr, two_hot(r_t)))

            # Value / Q loss
            z_n = jax.lax.stop_gradient(z_tgt_t1)
            k, _ = jax.random.split(k)
            tp_mean_std = pi_net.apply(tp["pi"], z_n)
            pi_a_mean = jnp.tanh(tp_mean_std[0])
            q_next_logits = q_net.apply(tp["q"], z_n, pi_a_mean)
            q_next_vals   = two_hot_inv(q_next_logits)
            v_n = jnp.maximum(jnp.min(q_next_vals, -1), 0.0)
            td  = r_t + gamma * (1 - d_t) * jax.lax.stop_gradient(v_n)
            qp  = q_net.apply(params["q"], z_t, a_t)
            vl  = w * jnp.mean(jnp.sum(soft_ce(qp, two_hot(td)[:, None, :]), -1))

            # Policy loss with RunningScale (v24)
            pi_mean_std = pi_net.apply(params["pi"], jax.lax.stop_gradient(z_t))
            pi2_mean    = jnp.tanh(pi_mean_std[0])
            q_pi2_logits = q_net.apply(
                jax.lax.stop_gradient(params["q"]),
                jax.lax.stop_gradient(z_t),
                pi2_mean,
            )
            q_pi2_vals = two_hot_inv(q_pi2_logits)  # (B, 2)

            q_flat = q_pi2_vals.flatten()
            p5     = jnp.percentile(q_flat, 5)
            p95    = jnp.percentile(q_flat, 95)
            # SCALE_MAX env overrides the v24 RunningScale cap (default 4.0). It saturates at 4.0
            # the whole run on manipulation → value-scale can't track the IQR → advantages over-
            # normalized → late-training oscillation. Raising the cap is the collapse-fix probe.
            _smax = float(_os.environ.get("SCALE_MAX", str(scale_max)))
            new_s  = jnp.clip(
                (1 - tau) * s + tau * jnp.maximum(p95 - p5, 1.0),
                scale_min,
                _smax,
            )
            pl = -w * jnp.mean(jnp.min(q_pi2_vals / new_s, -1))

            return (k, new_s), (cl, rl, vl, pl)

        (_, final_scale), (cls, rls, vls, pls) = jax.lax.scan(
            step_loss,
            (rng, scale),
            (weights, z_t_T, a_T, r_T, d_T, z_t1_T, zs_t1_T),
        )
        n = T - 1
        # WM-HEAD ABLATION (Thread A): zero ONE aux loss term via env ABLATE.
        # process-constant -> read at trace time -> constant-folded (graph identical to vanilla when 'none').
        _abl = _os.environ.get("ABLATE", "none")
        _m_c = 0.0 if _abl == "consistency" else 1.0
        _m_r = 0.0 if _abl == "reward" else 1.0
        _m_v = 0.0 if _abl == "value" else 1.0
        _m_p = 0.0 if _abl == "policy" else 1.0
        total = (_m_c * consistency_coef * jnp.sum(cls) + _m_r * 2 * jnp.sum(rls)
                 + _m_v * jnp.sum(vls) + _m_p * 0.1 * jnp.sum(pls)) / n

        # unif_dmc: env-gated relational anti-collapse on encoder latents (grad to enc).
        _unif_coef = float(_os.environ.get("UNIF_COEF", "0.0"))
        _unif_t = float(_os.environ.get("UNIF_T", "2.0"))
        _vicreg_coef = float(_os.environ.get("VICREG_COEF", "0.0"))
        _valunif_coef = float(_os.environ.get("VALUNIF_COEF", "0.0"))
        _se_coef = float(_os.environ.get("SE_COEF", "0.0"))
        _se_k = int(_os.environ.get("SE_K", "10"))
        _se_K = int(_os.environ.get("SE_KC", "8"))
        if _unif_coef > 0.0 or _vicreg_coef > 0.0 or _valunif_coef > 0.0 or _se_coef > 0.0:
            _zf = z_all.reshape(-1, z_all.shape[-1])
            if _unif_coef > 0.0:
                total = total + _unif_coef * uniformity_loss(_zf, t=_unif_t)
            if _vicreg_coef > 0.0:
                total = total + _vicreg_coef * vicreg_loss(_zf)
            if _se_coef > 0.0:
                # min-2D-SE on the L16 SimNorm latent kNN graph; grad to encoder.
                _se_key = jax.random.fold_in(rng, 991)
                total = total + _se_coef * se2d_loss_core(_zf, _se_key, k=_se_k, K=_se_K)
            if _valunif_coef > 0.0:
                # value-aware anti-collapse: derive a per-state value label (stop-grad)
                # from the current pi & Q nets, exactly as the TD target does.
                _zsg = jax.lax.stop_gradient(_zf)
                _pi_m = jnp.tanh(pi_net.apply(params["pi"], _zsg)[0])
                _q_log = q_net.apply(jax.lax.stop_gradient(params["q"]), _zsg, _pi_m)
                _v = jax.lax.stop_gradient(jnp.maximum(jnp.min(two_hot_inv(_q_log), -1), 0.0))
                _valunif_att = float(_os.environ.get("VALUNIF_ATTRACT", "0.5"))
                total = total + _valunif_coef * value_aware_uniformity_loss(
                    _zf, _v, t=_unif_t, attract=_valunif_att)

        # ── BS-MPC-style pairwise bisimulation auxiliary (iter-14 reference arm).
        # Python-guarded on the closed-over float `bisim_coef`: when 0.0 (default) this
        # block is not traced, so the graph is byte-identical to vanilla TD-MPC2 (fleet-safe).
        # Permuted-pair O(B) form of the π*-bisimulation metric (Zhang 2021 / BS-MPC 2410.04553):
        #   ( ||h(s_i)-h(s_j)||_1  -  |r_i-r_j|  -  gamma*||sg(z'_i)-sg(z'_j)||_2 )^2
        # Grad flows to the ENCODER via z_all (z_tgt is stop-grad); trains latent *distance*
        # to reflect reward+next-latent (behavioral) distance — the signal vanilla lacks.
        if bisim_coef > 0.0:
            L = z_all.shape[-1]
            ze = z_all[:, :-1].reshape(-1, L)                       # encoder latents (grad)
            zn = z_tgt[:, 1:].reshape(-1, L)                        # next latents (stop-grad)
            rr = rew_b[:, :-1].reshape(-1)
            M = ze.shape[0]
            perm = jax.random.permutation(jax.random.fold_in(rng, 7), M)
            pred = jnp.sum(jnp.abs(ze - ze[perm]), -1)
            tgt = jnp.abs(rr - rr[perm]) + gamma * jnp.sqrt(
                jnp.sum((zn - zn[perm]) ** 2, -1) + 1e-8)
            total = total + bisim_coef * jnp.mean((pred - tgt) ** 2)

        # Latent action smoothing — Python-conditional so the graph
        # matches the pre-smoothing version exactly when disabled (Phase-m fix).
        if smoothing_enabled:
            def _pi_mean_at_z(z_step):
                m, _ = pi_net.apply(params["pi"], jax.lax.stop_gradient(z_step))
                return jnp.tanh(m)
            all_pi_mean = jax.vmap(_pi_mean_at_z)(z_t_T)  # (T-1, B, act_dim)
            smooth_loss = jnp.mean(jnp.sum((all_pi_mean[1:] - all_pi_mean[:-1]) ** 2, axis=-1))
            total = total + latent_action_smooth_coef * smooth_loss
        if mpc_distill_enabled:
            z_anchor = enc.apply(params["enc"], mpc_obs_anchor)
            pi_anchor_mean, _ = pi_net.apply(params["pi"], jax.lax.stop_gradient(z_anchor))
            pi_anchor_mean = jnp.tanh(pi_anchor_mean)
            mpc_loss = jnp.mean(jnp.sum((pi_anchor_mean - jax.lax.stop_gradient(mpc_action_target)) ** 2, axis=-1))
            total = total + mpc_distill_coef * mpc_loss
        else:
            mpc_loss = jnp.array(0.0)

        # ── iter-22 JUMPY k-step latent model + horizon-consistency (Python-guarded on the
        # static int jumpy_k, so graph is byte-identical to vanilla when jumpy_k==0). The
        # MECHANISM CHECK (jumpy_err vs iter1_err) is the cheap kill-probe: a k-step head is
        # only worth building MPPI on if it predicts z_{t+k} MORE accurately than iterating
        # the 1-step model k times. Trains params["jdyn"]; encoder fed via z0 (grad), target
        # z_{t+k} is stop-grad.
        jumpy_cons = jnp.array(0.0); jumpy_hc = jnp.array(0.0); jumpy_rew = jnp.array(0.0)
        jumpy_err = jnp.array(0.0); iter1_err = jnp.array(0.0); jumpy_ve = jnp.array(0.0)
        calib_loss = jnp.array(0.0)
        if jumpy_k > 0:
            kk = int(jumpy_k); adim = act_b.shape[-1]
            a_k = act_b[:, :kk].reshape(B, kk * adim)
            jpred = jumpy_net.apply(params["jdyn"], z0, a_k)            # predicted z_{t+k}
            z_k_tgt = z_tgt[:, kk]                                       # sg actual z_{t+k}
            jumpy_cons = jnp.mean(jnp.sum((jpred - z_k_tgt) ** 2, -1))
            total = total + jumpy_coef * jumpy_cons
            # iter-25 probe#2 — VALUE-EQUIVALENT macro head: the predicted z_{t+k} must preserve the
            # control-relevant quantity (VALUE), not just reconstruct the latent. V(z)=min-head
            # two_hot_inv(Q(z,pi(z))); stop-grad Q/pi params so the gradient trains ONLY jdyn (jpred).
            jumpy_ve = jnp.array(0.0)
            if jumpy_ve_coef > 0.0:
                _qp = jax.lax.stop_gradient(params["q"]); _pp = jax.lax.stop_gradient(params["pi"])
                def _V(zz):
                    _mu, _ = pi_net.apply(_pp, zz)
                    return jnp.min(two_hot_inv(q_net.apply(_qp, zz, jnp.tanh(_mu))), axis=-1)
                jumpy_ve = jnp.mean((_V(jpred) - jax.lax.stop_gradient(_V(z_k_tgt))) ** 2)
                total = total + jumpy_ve_coef * jumpy_ve
            # jumpy macro-reward head: predict sum of the k rewards over the jump
            if jumpy_rew_net is not None:
                rJ = jumpy_rew_net.apply(params["jrew"], z0, a_k)
                rJ_tgt = jnp.sum(rew_b[:, :kk], axis=1)
                jumpy_rew = jnp.mean(soft_ce(rJ, two_hot(rJ_tgt)))
                total = total + jumpy_coef * jumpy_rew
            # mechanism diagnostic (no grad): RMS latent error, jumpy vs iterated-1-step at k
            jumpy_err = jnp.sqrt(jnp.mean(jnp.sum((jax.lax.stop_gradient(jpred) - z_k_tgt) ** 2, -1)))
            iter1_err = jnp.sqrt(jnp.mean(jnp.sum((zs[:, kk] - z_k_tgt) ** 2, -1)))
            # ── iter-30 CALIBRATION-SHAPED disagreement (Python-guarded on the closed-over float
            # calib_coef: when 0.0 (default) this block is not traced — graph identical to iter-22).
            # Validated diagnostic: disc = ||jdyn − iterated-1-step|| tracks true k-step err
            # (Spearman 0.72); ratio median(disc)/median(err) <1 = overconfident (Cab measured 0.95).
            # Train d to sit at the calib_q-quantile UPPER BOUND of e via pinball loss on (e − d).
            # Stop-grad BOTH the encoder target (z_k_tgt already sg via z_tgt) AND the iterated
            # 1-step path (sg over zs[:, kk]) so the gradient shapes ONLY the JUMPY HEAD's
            # disagreement geometry (jpred appears in both e and d) — not the 1-step model.
            if calib_coef > 0.0:
                z_iter1 = jax.lax.stop_gradient(zs[:, kk])
                e_cal = jnp.sqrt(jnp.sum((jpred - z_k_tgt) ** 2, -1) + 1e-8)   # (B,) true k-step err
                d_cal = jnp.sqrt(jnp.sum((jpred - z_iter1) ** 2, -1) + 1e-8)   # (B,) disagreement
                u_cal = e_cal - d_cal
                calib_loss = jnp.mean(jnp.maximum(calib_q * u_cal, (calib_q - 1.0) * u_cal))
                total = total + calib_coef * calib_loss
            # horizon-consistency: composed 2k-jump must match actual z_{2k} (window permitting)
            if 2 * kk <= (T - 1):
                a_k2 = act_b[:, kk:2 * kk].reshape(B, kk * adim)
                jpred2 = jumpy_net.apply(params["jdyn"], jpred, a_k2)
                jumpy_hc = jnp.mean(jnp.sum((jpred2 - z_tgt[:, 2 * kk]) ** 2, -1))
                total = total + jumpy_coef * jumpy_hc

        # ── A2: RND predictor training (Python-guarded on rnd_coef; grad flows ONLY to
        # params["rnd_prd"] via stop-grad on the encoder latents; graph identical when 0).
        if rnd_coef > 0.0:
            _zr = jax.lax.stop_gradient(z_all.reshape(-1, z_all.shape[-1]))
            _rtgt = jax.lax.stop_gradient(rnd_net.apply(rnd_tgt_params, _zr))
            _rprd = rnd_net.apply(params["rnd_prd"], _zr)
            rnd_loss = jnp.mean(jnp.sum((_rprd - _rtgt) ** 2, -1))
            total = total + rnd_coef * rnd_loss
        else:
            rnd_loss = jnp.array(0.0)

        aux = {
            "c": jnp.sum(cls) / n,
            "r": jnp.sum(rls) / n,
            "v": jnp.sum(vls) / n,
            "p": jnp.sum(pls) / n,
            "mpc": mpc_loss,
            "scale": final_scale,
            "jumpy_cons": jumpy_cons,
            "jumpy_ve": jumpy_ve,
            "jumpy_hc": jumpy_hc,
            "jumpy_rew": jumpy_rew,
            "jumpy_err": jumpy_err,
            "iter1_err": iter1_err,
            "calib": calib_loss,
            "rnd_loss": rnd_loss,
            "abl_mc": _m_c, "abl_mr": _m_r, "abl_mv": _m_v, "abl_mp": _m_p,
        }
        return total, aux

    @jax.jit
    def single_step(params, tp, opt, ob, ab, rb, db, rng, scale,
                    mpc_obs_anchor, mpc_action_target, mpc_distill_coef):
        (loss, aux), grads = jax.value_and_grad(loss_fn, has_aux=True)(
            params, tp, ob, ab, rb, db, rng, scale,
            mpc_obs_anchor, mpc_action_target, mpc_distill_coef,
        )
        upd, nopt = tx.update(grads, opt, params)
        new_params = optax.apply_updates(params, upd)
        new_tp = jax.tree_util.tree_map(
            lambda t, p: (1 - tau) * t + tau * p, tp, new_params
        )
        return new_params, new_tp, nopt, loss, aux

    @jax.jit
    def multi_step(params, tp, opt, all_obs, all_acts, all_rews, all_done, key, scale,
                   mpc_obs_anchor, mpc_action_target, mpc_distill_coef):
        """K gradient updates in one JIT dispatch via jax.lax.scan.

        Scale is carried across gradient steps so that the RunningScale
        accumulates over K updates before being returned.
        """

        def one_step(carry, batch):
            params, tp, opt, key, scale = carry
            ob, ab, rb, db = batch
            key, uk = jax.random.split(key)
            (loss, aux), grads = jax.value_and_grad(loss_fn, has_aux=True)(
                params, tp, ob, ab, rb, db, uk, scale,
                mpc_obs_anchor, mpc_action_target, mpc_distill_coef,
            )
            # FREEZE_DYN=1: zero the dynamics-net gradients → keep dyn at random init (H4 test:
            # is the LEARNED dynamics redundant given a value-sufficient latent?). Captured at trace time.
            if _os.environ.get("FREEZE_DYN", "") == "1" and "dyn" in grads:
                grads = {**grads, "dyn": jax.tree_util.tree_map(jnp.zeros_like, grads["dyn"])}
            upds, nopt = tx.update(grads, opt, params)
            new_params = optax.apply_updates(params, upds)
            new_tp = jax.tree_util.tree_map(
                lambda t, p: (1 - tau) * t + tau * p, tp, new_params
            )
            return (new_params, new_tp, nopt, key, aux["scale"]), (loss, aux)

        (params, tp, opt, key, scale), (losses, auxs) = jax.lax.scan(
            one_step,
            (params, tp, opt, key, scale),
            (all_obs, all_acts, all_rews, all_done),
        )
        last_aux = jax.tree_util.tree_map(lambda x: x[-1], auxs)
        return params, tp, opt, key, scale, losses[-1], last_aux

    return single_step, multi_step


# ---------------------------------------------------------------------------
# A2 novelty-MPPI: RND novelty over the SimNorm latent (Plan2Explore-in-TD-MPC2)
# ---------------------------------------------------------------------------
class RNDNet(nn.Module):
    """Small MLP z -> feature. Fixed random target + trained predictor; novelty=pred error."""
    hidden: tuple = (256,)
    out: int = 64

    @nn.compact
    def __call__(self, z: jax.Array) -> jax.Array:
        x = z
        for d in self.hidden:
            x = nn.relu(nn.Dense(d)(x))
        return nn.Dense(self.out)(x)


# ---------------------------------------------------------------------------
# MPPI planner factory
# ---------------------------------------------------------------------------


def make_mppi_fn(
    enc: Encoder,
    dyn: Dynamics,
    rew_net: RewardHead,
    q_net: QEnsemble,
    pi_net: Pi,
    horizon: int = 3,
    n_samples: int = 512,
    num_elites: int = 64,
    num_pi_trajs: int = 24,
    n_iter: int = 6,
    min_std: float = 0.05,
    max_std: float = 2.0,
    act_low: float = -1.0,
    act_high: float = 1.0,
    act_dim: int = 4,
    gamma: float = 0.99,
    rew_scale: float = 10.0,
    rnd_net=None,
    rnd_tgt_params=None,
    novelty_beta: float = 0.0,
    novelty_type: str = "rnd",
):
    """Build the JIT-compiled MPPI planning function (v24 parity).

    Features:
    - num_pi_trajs stochastic pi-trajectory seeds per iteration
    - n_noise = n_samples - num_pi_trajs Gaussian noise trajectories
    - Elite-based update: mean/std from top num_elites by return
    - std clamped to [min_std, max_std]
    - t0 flag resets mu/std on episode start
    - gamma-weighted reward accumulation + terminal value from Q

    Returns:
        plan(params, obs, mu, std, key, t0)
            → (action, new_mu, new_std)
    """
    n_noise  = n_samples - num_pi_trajs
    _gammas  = jnp.array([gamma ** t for t in range(horizon)])
    _gamma_H = float(gamma ** horizon)
    _NOV_BETA = float(novelty_beta)
    _NOV_TYPE = str(novelty_type)

    @jax.jit
    def plan(
        params: dict,
        obs: jax.Array,
        mu: jax.Array,
        std: jax.Array,
        key: jax.Array,
        t0: jax.Array,
    ) -> tuple[jax.Array, jax.Array, jax.Array]:
        """Plan one step.

        Args:
            params: model params dict with keys enc/dyn/rew/q/pi.
            obs:    (obs_dim,) current observation.
            mu:     (H, act_dim) warm-start mean (zeros on fresh episode).
            std:    (H, act_dim) warm-start std (max_std on fresh episode).
            key:    PRNGKey.
            t0:     bool scalar — True on episode start, resets mu/std.

        Returns:
            action:  (act_dim,) deterministic action (mu[0] after planning).
            new_mu:  (H, act_dim) shifted warm-start for next step.
            new_std: (H, act_dim) shifted std for next step.
        """
        mu  = jnp.where(t0, jnp.zeros_like(mu),  mu)
        std = jnp.where(t0, jnp.full_like(std, max_std), std)

        z0_single = enc.apply(params["enc"], obs[None])[0]

        def pi_rollout_stoch(key):
            def pi_step(z, k):
                mean_a, log_std_a = pi_net.apply(params["pi"], z[None])
                mean_a    = mean_a[0]
                log_std_a = log_std_a[0]
                eps = jax.random.normal(k, mean_a.shape)
                a   = jnp.tanh(mean_a + eps * jnp.exp(log_std_a))
                z2  = dyn.apply(params["dyn"], z[None], a[None])[0]
                return z2, a

            keys_h = jax.random.split(key, horizon)
            _, traj = jax.lax.scan(pi_step, z0_single, keys_h)
            return traj  # (H, act_dim)

        key, pk = jax.random.split(key)
        pi_keys  = jax.random.split(pk, num_pi_trajs)
        pi_trajs = jax.vmap(pi_rollout_stoch)(pi_keys)  # (num_pi_trajs, H, act_dim)

        def one_iter(carry, _):
            mu_i, std_i, k = carry
            k, sk = jax.random.split(k)

            noise      = jax.random.normal(sk, (n_noise, horizon, act_dim)) * std_i[None]
            noise_acts = jnp.clip(mu_i[None] + noise, act_low, act_high)
            acts       = jnp.concatenate([pi_trajs, noise_acts], axis=0)

            z0_batch = jnp.tile(z0_single[None], (n_samples, 1))

            if _NOV_BETA > 0.0:
                def rollout_one(z_i, a_seq):
                    def env_step(z, a):
                        r_logits = rew_net.apply(params["rew"], z[None], a[None])
                        r  = two_hot_inv(r_logits).squeeze()
                        z2 = dyn.apply(params["dyn"], z[None], a[None]).squeeze(0)
                        return z2, (r, z2)

                    zf, (rs, zs_traj) = jax.lax.scan(env_step, z_i, a_seq)
                    pi_a_mean, _ = pi_net.apply(params["pi"], zf[None])
                    pi_a_squashed = jnp.tanh(pi_a_mean)
                    q_logits = q_net.apply(params["q"], zf[None], pi_a_squashed)
                    vt = jnp.maximum(jnp.min(two_hot_inv(q_logits)), 0.0).squeeze()
                    ret = jnp.sum(_gammas * rs) + _gamma_H * vt
                    if _NOV_TYPE == "disagreement":
                        qv = two_hot_inv(q_logits).reshape(-1)   # (2,) two Q-heads
                        nov = jnp.abs(qv[0] - qv[1])
                    else:  # rnd novelty over predicted SimNorm latents
                        tgt = jax.lax.stop_gradient(rnd_net.apply(rnd_tgt_params, zs_traj))
                        prd = rnd_net.apply(params["rnd_prd"], zs_traj)
                        nov = jnp.sum(jnp.mean((prd - tgt) ** 2, axis=-1))
                    return ret, nov

                rets, novs = jax.vmap(rollout_one)(z0_batch, acts)
                nov_n = (novs - jnp.mean(novs)) / (jnp.std(novs) + 1e-6)
                score = rets + _NOV_BETA * nov_n
            else:
                def rollout_one(z_i, a_seq):
                    def env_step(z, a):
                        r_logits = rew_net.apply(params["rew"], z[None], a[None])
                        r  = two_hot_inv(r_logits).squeeze()
                        z2 = dyn.apply(params["dyn"], z[None], a[None]).squeeze(0)
                        return z2, r

                    zf, rs = jax.lax.scan(env_step, z_i, a_seq)
                    pi_a_mean, _ = pi_net.apply(params["pi"], zf[None])
                    pi_a_squashed = jnp.tanh(pi_a_mean)
                    q_logits = q_net.apply(params["q"], zf[None], pi_a_squashed)
                    vt = jnp.maximum(jnp.min(two_hot_inv(q_logits)), 0.0).squeeze()
                    return jnp.sum(_gammas * rs) + _gamma_H * vt

                rets = jax.vmap(rollout_one)(z0_batch, acts)
                score = rets

            _, elite_idx = jax.lax.top_k(score, num_elites)
            elite_acts = acts[elite_idx]
            new_mu  = jnp.mean(elite_acts, axis=0)
            new_std = jnp.clip(jnp.std(elite_acts, axis=0) + 1e-6, min_std, max_std)
            return (new_mu, new_std, k), None

        (muf, stdf, _), _ = jax.lax.scan(one_iter, (mu, std, key), None, length=n_iter)

        action  = jnp.clip(muf[0], act_low, act_high)
        new_mu  = jnp.concatenate([muf[1:],  jnp.zeros((1, act_dim))],        axis=0)
        new_std = jnp.concatenate([stdf[1:], jnp.full((1, act_dim), max_std)], axis=0)
        return action, new_mu, new_std

    return plan


# ---------------------------------------------------------------------------
# iter-22 — JUMPY MPPI: plan N macro-steps over the k-step jumpy model
# ---------------------------------------------------------------------------


def make_jumpy_mppi_fn(
    enc: Encoder,
    jdyn: JumpyDynamics,
    jrew: JumpyReward,
    q_net: QEnsemble,
    pi_net: Pi,
    k: int,
    n_macro: int = 3,
    n_samples: int = 512,
    num_elites: int = 64,
    n_iter: int = 6,
    min_std: float = 0.05,
    max_std: float = 2.0,
    act_low: float = -1.0,
    act_high: float = 1.0,
    act_dim: int = 4,
    gamma: float = 0.99,
):
    """Jumpy MPPI: plan n_macro macro-steps (each = k primitive actions) over the JUMPY model,
    so effective horizon = n_macro*k with only n_macro model applications (no compounding the
    1-step model). Per-sample return = Σ_i γ^{ik} r_J(z_i, a_i) + γ^{n_macro*k} min-Q(z_N,π(z_N)).
    Receding-horizon: apply the first PRIMITIVE action, replan. mu/std shape (n_macro, k, act_dim).
    """
    _gammas = jnp.array([gamma ** (i * k) for i in range(n_macro)])
    _gamma_T = float(gamma ** (n_macro * k))
    akd = k * act_dim

    @jax.jit
    def plan(params, obs, mu, std, key, t0):
        mu = jnp.where(t0, jnp.zeros_like(mu), mu)
        std = jnp.where(t0, jnp.full_like(std, max_std), std)
        z0 = enc.apply(params["enc"], obs[None])[0]

        def one_iter(carry, _):
            mu_i, std_i, kkey = carry
            kkey, sk = jax.random.split(kkey)
            noise = jax.random.normal(sk, (n_samples, n_macro, k, act_dim)) * std_i[None]
            acts = jnp.clip(mu_i[None] + noise, act_low, act_high)   # (S, n_macro, k, act_dim)

            def rollout(a_seq):  # a_seq (n_macro, k, act_dim)
                def macro(z, a_macro):
                    a_c = a_macro.reshape(akd)
                    r = two_hot_inv(jrew.apply(params["jrew"], z[None], a_c[None])).squeeze()
                    z2 = jdyn.apply(params["jdyn"], z[None], a_c[None])[0]
                    return z2, r
                zf, rs = jax.lax.scan(macro, z0, a_seq)
                pa, _ = pi_net.apply(params["pi"], zf[None])
                vt = jnp.maximum(jnp.min(two_hot_inv(q_net.apply(params["q"], zf[None], jnp.tanh(pa)))), 0.0).squeeze()
                return jnp.sum(_gammas * rs) + _gamma_T * vt

            rets = jax.vmap(rollout)(acts)
            _, ei = jax.lax.top_k(rets, num_elites)
            ea = acts[ei]
            return (jnp.mean(ea, 0), jnp.clip(jnp.std(ea, 0) + 1e-6, min_std, max_std), kkey), None

        (muf, stdf, _), _ = jax.lax.scan(one_iter, (mu, std, key), None, length=n_iter)
        action = jnp.clip(muf[0, 0], act_low, act_high)             # first primitive action
        # warm-start: shift primitive actions by 1 over the flattened (n_macro*k) sequence
        flat = muf.reshape(n_macro * k, act_dim)
        flat = jnp.concatenate([flat[1:], jnp.zeros((1, act_dim))], 0)
        new_mu = flat.reshape(n_macro, k, act_dim)
        new_std = jnp.full((n_macro, k, act_dim), max_std)
        return action, new_mu, new_std

    return plan


# ---------------------------------------------------------------------------
# Default hyperparameters (v24 milestone)
# ---------------------------------------------------------------------------

DEFAULTS = dict(
    # Architecture
    latent_dim    = 512,
    hidden        = (512, 512),
    num_bins      = 101,
    vmin          = -20.0,
    vmax          = 20.0,
    V             = 8,          # SimNorm groups
    # Training
    lr            = 3e-4,
    gamma         = 0.99,
    tau           = 0.01,       # EMA coefficient (target params + RunningScale)
    rho           = 0.5,        # Consistency loss horizon decay
    rew_scale     = 10.0,
    K_UPDATE      = 64,
    BS            = 256,
    N_ENVS        = 256,
    WARMUP_ENV    = 25_000,
    EXPL_NOISE    = 0.3,
    EXPL_UNTIL    = 25_000,
    # RunningScale (v24)
    scale_min     = 1.0,
    scale_max     = 4.0,
    # MPPI (v24 parity)
    H             = 3,
    NS            = 512,
    NUM_ELITES    = 64,
    NUM_PI_TRAJS  = 24,
    NI            = 6,
    MIN_STD       = 0.05,
    MAX_STD       = 2.0,
    # Loss coefficients (v13 stable)
    consistency_coef = 2.0,
    reward_coef      = 2.0,
    value_coef       = 1.0,
    pi_coef          = 0.1,
)
