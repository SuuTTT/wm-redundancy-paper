#!/usr/bin/env bash
# Paper-4 sufficiency arm 1: consistency-OFF HopperHop 5M x4 (seeds 21-24 = fresh tags)
set -u
cd /root/helios_wmablate || exit 1
for i in 0 1 2 3; do
  s=$((21+i))
  GPU=$i ABLATE=consistency TASK=HopperHop SEED=$s TOTAL_STEPS=5000000 bash run_arm.sh &
done
wait
echo DONE > /root/helios_wmablate/exp/SUFF5M_DONE
