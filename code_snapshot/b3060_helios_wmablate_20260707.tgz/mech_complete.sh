#!/usr/bin/env bash
# Mechanism-table completion (launch on b3060 AFTER 5M anchors finish):
# GPU0: CheetahRun seed3 chain (none,value,policy); GPU1: CheetahRun seed4 chain (same);
# GPU2: WalkerRun consistency s3 + reward s3; GPU3: WalkerRun consistency s4 + reward s4.
# Brings CheetahRun decisive arms and WalkerRun all arms to n=4.
set -u
REPO=/root/helios_wmablate
CH=$REPO/exp/wm_head_ablation_cheetah
WK=$REPO/exp/wm_head_ablation_walk
mkdir -p "$CH/logs" "$CH/jsonl" "$WK/logs" "$WK/jsonl"
DLOG=$REPO/exp/mech_complete_driver.log
echo "[mech] START $(date -u +%FT%TZ)" | tee -a "$DLOG"
cheetah_chain() {
  local gpu=$1 seed=$2
  for a in none value policy; do
    echo "[mech] cheetah gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=1000000 bash $REPO/run_arm.sh
    echo "[mech] cheetah gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
}
walker_chain() {
  local gpu=$1 seed=$2
  for a in consistency reward; do
    echo "[mech] walker gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=1000000 bash $REPO/run_arm_walk.sh
    echo "[mech] walker gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
}
cheetah_chain 0 3 &
cheetah_chain 1 4 &
walker_chain 2 3 &
walker_chain 3 4 &
wait
touch "$REPO/exp/MECH_COMPLETE_DONE"
echo "[mech] DONE $(date -u +%FT%TZ)" | tee -a "$DLOG"
