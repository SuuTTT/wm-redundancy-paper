#!/usr/bin/env bash
# WM-head ablation on WALKERRUN (3rd task for the value-pathway mechanism; learnable+dense
# so it tests generality beyond the exploration regime). 5 arms x 2 seeds split over 4 GPUs.
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/wm_head_ablation_walk
STEPS=${STEPS:-1000000}
mkdir -p "$OUT/logs" "$OUT/jsonl"
DLOG=$OUT/driver.log
echo "[driver_walk] START $(date -u +%FT%TZ)" | tee -a "$DLOG"
run_chain() {
  local gpu=$1 seed=$2; shift 2
  for a in "$@"; do
    echo "[driver_walk] gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=$STEPS bash $REPO/run_arm_walk.sh
    echo "[driver_walk] gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
}
run_chain 0 1 none value consistency &
run_chain 1 1 reward policy &
run_chain 2 2 none value consistency &
run_chain 3 2 reward policy &
wait
touch "$OUT/WM_ABLATION_WALK_DONE"
echo "[driver_walk] DONE $(date -u +%FT%TZ)" | tee -a "$DLOG"
