#!/usr/bin/env bash
# TD-MPC2 HopperHop 5M anchors seeds 33/34 (firms the flagship efficiency anchor n=2 -> n=4).
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/hop5m_anchors
mkdir -p "$OUT/logs"
PY=/root/helios-rl/.venv/bin/python
export PYTHONPATH=$REPO/src:/root/mujoco_playground_repo
export XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax
run_seed() {
  local gpu=$1 seed=$2
  CUDA_VISIBLE_DEVICES=$gpu TDMPC_GLASS_OUTPUT_TAG=hop5m_s$seed \
    $PY -u $REPO/scripts/run_benchmark.py --algos tdmpc2 --tasks HopperHop \
      --total_steps 5000000 --seed $seed \
      --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 \
      --no_plot > "$OUT/logs/seed${seed}.log" 2>&1
  echo "[anchors] seed $seed rc=$? $(date -u +%FT%TZ)" >> "$OUT/driver.log"
}
run_seed 0 33 &
run_seed 1 34 &
wait
touch "$OUT/HOP5M_ANCHORS_DONE"
