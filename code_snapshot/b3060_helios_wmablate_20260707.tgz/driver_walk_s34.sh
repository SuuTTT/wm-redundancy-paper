#!/usr/bin/env bash
# WalkerRun ablation seeds 3/4, decisive arms only (none, value, policy):
# firms the 3rd-task mechanism cells from n=2 to n=4. GPU2=seed3, GPU3=seed4.
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/wm_head_ablation_walk
mkdir -p "$OUT/logs" "$OUT/jsonl"
DLOG=$OUT/driver_s34.log
echo "[driver_walk_s34] START $(date -u +%FT%TZ)" | tee -a "$DLOG"
run_chain() {
  local gpu=$1 seed=$2
  for a in none value policy; do
    echo "[driver_walk_s34] gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=1000000 bash $REPO/run_arm_walk.sh
    echo "[driver_walk_s34] gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
}
run_chain 2 3 &
run_chain 3 4 &
wait
touch "$OUT/WM_ABLATION_WALK_S34_DONE"
echo "[driver_walk_s34] DONE $(date -u +%FT%TZ)" | tee -a "$DLOG"
