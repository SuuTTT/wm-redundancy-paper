#!/usr/bin/env bash
set -u
EXP=/root/helios_wmablate/exp/novelty_sweep
PY=/root/helios-rl/.venv/bin/python
export PYTHONPATH=/root/helios_wmablate/src:/root/mujoco_playground_repo
cd /root/helios_wmablate || exit 1
arm() {
  local gpu=$1 type=$2 beta=$3 seed=$4
  local tag=nov_${type}${beta}_s${seed}
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax NOVELTY_TYPE=$type NOVELTY_BETA=$beta TDMPC_GLASS_OUTPUT_TAG=$tag $PY -u scripts/run_benchmark.py --algos tdmpc2 --tasks HopperHop --total_steps 1000000 --seed $seed --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 --no_plot > $EXP/logs/$tag.log 2>&1
  echo "[nov] $tag rc=$? $(date -u +%FT%TZ)" >> $EXP/driver.log
}
arm 0 disagreement 0.3 61 &
arm 1 disagreement 1.0 62 &
arm 2 rnd 0.3 63 &
arm 3 rnd 1.0 64 &
wait
echo DONE > $EXP/NOV_SWEEP_DONE
