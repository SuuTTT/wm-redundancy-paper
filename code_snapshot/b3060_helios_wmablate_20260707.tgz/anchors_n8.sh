#!/usr/bin/env bash
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/hop5m_anchors
PY=/root/helios-rl/.venv/bin/python
export PYTHONPATH=$REPO/src:/root/mujoco_playground_repo
mkdir -p $OUT/logs
run_seed() { local gpu=$1 seed=$2; CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax TDMPC_GLASS_OUTPUT_TAG=hop5m_s$seed $PY -u $REPO/scripts/run_benchmark.py --algos tdmpc2 --tasks HopperHop --total_steps 5000000 --seed $seed --k_update 128 --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 --no_plot > $OUT/logs/seed${seed}.log 2>&1; echo "[a8] s$seed rc=$? $(date -u +%FT%TZ)" >> $OUT/driver.log; }
run_seed 0 35 &
run_seed 1 36 &
run_seed 2 37 &
run_seed 3 38 &
wait
echo DONE > $OUT/HOP5M_N8_DONE
