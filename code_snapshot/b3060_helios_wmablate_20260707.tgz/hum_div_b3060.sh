#!/usr/bin/env bash
# Humanoid divergence hardening on b3060 (helios_wmablate copy, ABLATE unset = full model):
# GPU0/1: HumanoidWalk 4M seeds 45/46 -> divergence-rate n 5->7.
# GPU2/3: stability-knob probe seed 41 with k_update 64 / 32 (vs default 128) ->
#         does lowering the update-to-data ratio prevent the nan?
set -u
REPO=/root/helios_wmablate
EXP=$REPO/exp/hum_divergence
mkdir -p "$EXP/logs"
cd $REPO || exit 1
PY=/root/helios-rl/.venv/bin/python
export PYTHONPATH=$REPO/src:/root/mujoco_playground_repo
run() {
  local gpu=$1 seed=$2 ku=$3 tag=$4
  CUDA_VISIBLE_DEVICES=$gpu XLA_PYTHON_CLIENT_PREALLOCATE=false MUJOCO_GL=egl MJPG_IMPL=jax \
    TDMPC_GLASS_OUTPUT_TAG=$tag \
    $PY -u $REPO/scripts/run_benchmark.py --algos tdmpc2 \
      --tasks HumanoidWalk --total_steps 4000000 --seed "$seed" \
      --k_update "$ku" --mppi_n_samples 2048 --mppi_horizon 3 --expl_until 25000 \
      --no_plot > "$EXP/logs/${tag}.log" 2>&1
  echo "[hd] $tag rc=$? $(date -u +%FT%TZ)" >> "$EXP/driver.log"
}
run 0 45 128 humdiv_s45 &
run 1 46 128 humdiv_s46 &
run 2 41 64  humdiv_ku64_s41 &
run 3 41 32  humdiv_ku32_s41 &
wait
echo "HUM_DIV_B3060_DONE $(date -u +%FT%TZ)" > "$EXP/HUM_DIV_B3060_DONE"
