#!/usr/bin/env python3
"""Proposal A1: state-coverage of PLANNING (MPPI) vs PI-ONLY (policy prior, no plan).
Reuses helios tdmpc2 nets + make_mppi_fn, loads best_mppi/best_pi checkpoints,
rolls out both arms, computes coverage metrics. CPU-only (never touches SE GPUs)."""
import os, sys, time, json, pickle
os.environ.setdefault("JAX_PLATFORMS", "cpu")  # override via env for GPU
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.15")
import numpy as np, jax, jax.numpy as jnp
from mujoco_playground import registry, wrapper
from helios.algorithms.tdmpc2 import (
    Encoder, Dynamics, RewardHead, QEnsemble, Pi, make_mppi_fn, DEFAULTS,
)

ENV_ID   = sys.argv[1]                        # e.g. LeapCubeReorient
CKDIR    = sys.argv[2]                        # checkpoints dir with best_pi.pkl / best_mppi.pkl
N_EPS    = int(sys.argv[3]) if len(sys.argv) > 3 else 6
MAXSTEPS = int(sys.argv[4]) if len(sys.argv) > 4 else 300
OUT      = sys.argv[5] if len(sys.argv) > 5 else f"/root/helios-rl/exp/proposal_A1_exploration/{ENV_ID}_cov.json"

d = DEFAULTS
LAT, HID, V, NB = d["latent_dim"], d["hidden"], d["V"], d["num_bins"]
H, NS, EL, PT, NI = d["H"], d["NS"], d["NUM_ELITES"], d["NUM_PI_TRAJS"], d["NI"]
MIN_STD, MAX_STD, GAMMA, RSCALE = d["MIN_STD"], d["MAX_STD"], d["gamma"], d["rew_scale"]

print(f"[{ENV_ID}] loading env ...", flush=True)
env = registry.load(ENV_ID, config_overrides={"impl": "jax"})
env = wrapper.wrap_for_brax_training(env, episode_length=1000, action_repeat=1)
obs_dim, act_dim = env.observation_size, env.action_size
print(f"  obs={obs_dim} act={act_dim}  H={H} NS={NS} elites={EL} pi_trajs={PT} n_iter={NI}", flush=True)

enc = Encoder(latent_dim=LAT, hidden=HID, V=V)
dyn = Dynamics(latent_dim=LAT, hidden=HID, V=V)
rew = RewardHead(hidden=HID, num_bins=NB)
qn  = QEnsemble(hidden=HID, num_bins=NB)
pin = Pi(action_dim=act_dim, hidden=HID)
plan = make_mppi_fn(enc, dyn, rew, qn, pin, horizon=H, n_samples=NS, num_elites=EL,
                    num_pi_trajs=PT, n_iter=NI, min_std=MIN_STD, max_std=MAX_STD,
                    act_low=-1.0, act_high=1.0, act_dim=act_dim, gamma=GAMMA, rew_scale=RSCALE)

@jax.jit
def pi_act(params, obs):
    z = enc.apply(params["enc"], obs[None])
    mu, _ = pin.apply(params["pi"], z)
    return jnp.tanh(mu[0])

@jax.jit
def env_reset(key): return env.reset(jax.random.split(key, 1))
@jax.jit
def env_step(state, act): return env.step(state, act[None])

_is_pick = ("PandaPickCube" in ENV_ID)

def rollout_pi(params, n_eps, seed0):
    key = jax.random.PRNGKey(seed0); rets=[]; succ=[]; states=[]
    for ep in range(n_eps):
        key, rk = jax.random.split(key); st = env_reset(rk)
        obs = jnp.asarray(st.obs[0]); er=0.0; s=0.0
        for t in range(MAXSTEPS):
            states.append(np.asarray(obs))
            a = pi_act(params, obs); st = env_step(st, a)
            er += float(st.reward[0])
            if _is_pick: s = max(s, float(np.asarray(st.metrics["box_target"]).reshape(-1)[0]))
            if bool(st.done[0] > 0.5): break
            obs = jnp.asarray(st.obs[0])
        rets.append(er); succ.append(s)
    return np.array(rets), np.array(succ), np.array(states)

def rollout_mppi(params, n_eps, seed0):
    key = jax.random.PRNGKey(seed0); rets=[]; succ=[]; states=[]
    for ep in range(n_eps):
        key, rk = jax.random.split(key); st = env_reset(rk)
        obs = jnp.asarray(st.obs[0])
        mu = jnp.zeros((H, act_dim)); std = jnp.full((H, act_dim), MAX_STD)
        t0 = jnp.bool_(True); er=0.0; s=0.0
        key, pk = jax.random.split(key)
        for t in range(MAXSTEPS):
            states.append(np.asarray(obs))
            a, mu, std = plan(params, obs, mu, std, pk, t0)
            t0 = jnp.bool_(False); key, pk = jax.random.split(key)
            st = env_step(st, a); er += float(st.reward[0])
            if _is_pick: s = max(s, float(np.asarray(st.metrics["box_target"]).reshape(-1)[0]))
            if bool(st.done[0] > 0.5): break
            obs = jnp.asarray(st.obs[0])
        rets.append(er); succ.append(s)
    return np.array(rets), np.array(succ), np.array(states)

def coverage_metrics(states_by_arm):
    """Fit shared standardization + PCA(5) on the UNION so grids are comparable."""
    allS = np.concatenate([v for v in states_by_arm.values()], 0)
    mu = allS.mean(0); sd = allS.std(0) + 1e-8
    Z = (allS - mu) / sd
    # PCA via SVD on union
    Zc = Z - Z.mean(0)
    U, S, Vt = np.linalg.svd(Zc, full_matrices=False)
    K = min(5, Vt.shape[0]); comp = Vt[:K]
    # shared grid bounds in PCA space
    P_all = Zc @ comp.T
    lo, hi = P_all.min(0), P_all.max(0); rng = (hi - lo) + 1e-8
    B = 8
    out = {}
    for arm, S_arm in states_by_arm.items():
        Za = (S_arm - mu) / sd - Z.mean(0)
        P = Za @ comp.T
        idx = np.clip(((P - lo) / rng * B).astype(int), 0, B - 1)
        cells = [tuple(r) for r in idx]
        uniq, cnt = np.unique(np.array(cells), axis=0, return_counts=True)
        p = cnt / cnt.sum(); occ_ent = float(-(p * np.log(p)).sum())
        n_distinct = int(len(uniq))
        # dispersion in full standardized obs space (subsample for speed)
        Sn = (S_arm - mu) / sd
        m = min(len(Sn), 1500)
        sub = Sn[np.random.RandomState(0).choice(len(Sn), m, replace=False)] if len(Sn) > m else Sn
        # mean pairwise dist + mean 10-NN dist
        from scipy.spatial.distance import pdist
        try:
            pd = pdist(sub); mean_pair = float(pd.mean())
        except Exception:
            mean_pair = float("nan")
        # 10-NN mean
        D = np.sqrt(((sub[:, None, :] - sub[None, :, :]) ** 2).sum(-1)) if m <= 1500 else None
        if D is not None:
            np.fill_diagonal(D, np.inf); k = min(10, m - 1)
            knn = np.sort(D, 1)[:, :k].mean(1); mean_knn = float(knn.mean())
        else:
            mean_knn = float("nan")
        out[arm] = dict(n_states=int(len(S_arm)), occ_entropy_pca5_b8=round(occ_ent, 4),
                        n_distinct_cells=n_distinct, mean_pairwise_dist=round(mean_pair, 4),
                        mean_10nn_dist=round(mean_knn, 4))
    return out

results = {"env_id": ENV_ID, "n_eps": N_EPS, "max_steps": MAXSTEPS,
           "mppi_hparams": dict(H=H, NS=NS, elites=EL, pi_trajs=PT, n_iter=NI)}
states = {}
_force = os.environ.get("FORCE_CK", "")   # if set, BOTH arms load this file (same-weights ablation)
for arm, fname, roller in [("pi_only", _force or "best_pi.pkl", rollout_pi),
                           ("planning_mppi", _force or "best_mppi.pkl", rollout_mppi)]:
    path = os.path.join(CKDIR, fname)
    ck = pickle.load(open(path, "rb")); params = ck["params"]
    print(f"[{ENV_ID}] rollout {arm} (ck steps={ck.get('env_steps')}) ...", flush=True)
    t = time.time(); rets, succ, S = roller(params, N_EPS, seed0=12345)
    print(f"  {arm}: ret={rets.mean():.2f}+-{rets.std():.2f} n_states={len(S)} ({time.time()-t:.0f}s)", flush=True)
    results[arm] = dict(ck_env_steps=int(ck.get("env_steps", -1)), ck_pi_reward=float(ck.get("pi_reward", float("nan"))),
                        ck_mppi_reward=float(ck.get("mppi_reward", float("nan"))),
                        rollout_return_mean=round(float(rets.mean()), 3), rollout_return_std=round(float(rets.std()), 3),
                        success_mean=round(float(succ.mean()), 3))
    states[arm] = S

cov = coverage_metrics(states)
for arm in states: results[arm].update(cov[arm])
os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump(results, open(OUT, "w"), indent=2)
print("WROTE", OUT, flush=True)
print(json.dumps(results, indent=2), flush=True)
