#!/usr/bin/env python3
import os
os.environ.setdefault("MUJOCO_GL","egl")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE","false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION","0.25")
import argparse, numpy as np, jax, jax.numpy as jp
from mujoco_playground import registry
from scripted_pick import ScriptedPickController

ap=argparse.ArgumentParser()
ap.add_argument("--n",type=int,default=10)
ap.add_argument("--len",type=int,default=150)
ap.add_argument("--seed",type=int,default=0)
ap.add_argument("--verbose",action="store_true")
args=ap.parse_args()

env=registry.load("PandaPickCube",config_overrides={"impl":"jax"})
reset=jax.jit(env.reset); step=jax.jit(env.step)
ctrl=ScriptedPickController(env)
key=jax.random.PRNGKey(args.seed)
results=[]
for ep in range(args.n):
    key,rk=jax.random.split(key)
    s=reset(rk); s=step(s,jp.zeros(8))  # populate kinematics
    ctrl.reset()
    box0=float(np.array(s.data.xpos[env._obj_body])[2])
    max_bt=0.0; reached=0.0; max_lift=0.0; succ=False
    for t in range(args.len-1):
        a=ctrl(s)
        s=step(s,jp.asarray(a))
        bt=float(s.metrics["box_target"]); max_bt=max(max_bt,bt)
        reached=max(reached,float(s.info["reached_box"]))
        bz=float(np.array(s.data.xpos[env._obj_body])[2])
        max_lift=max(max_lift,bz-box0)
        if bt>=0.9: succ=True
        if bool(s.done>0.5): break
    results.append(dict(ep=ep,success=succ,max_box_target=round(max_bt,3),
                        reached=reached,max_lift=round(max_lift,3),end_phase=ctrl.phase))
    print(f"ep{ep}: succ={succ} max_bt={max_bt:.3f} reached={reached:.0f} "
          f"max_lift={max_lift:.3f} phase={ctrl.phase}",flush=True)
ns=sum(r["success"] for r in results)
nr=sum(r["reached"]>0.5 for r in results)
ml=max(r["max_lift"] for r in results)
print("\n==== SUMMARY ====")
print(f"success(box_target>=0.9): {ns}/{len(results)} = {ns/len(results):.0%}")
print(f"reached_box rate: {nr}/{len(results)} = {nr/len(results):.0%}")
print(f"max lift across eps: {ml:.3f} m")
import json; print("JSON",json.dumps(results))
