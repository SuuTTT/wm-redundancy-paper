#!/usr/bin/env bash
# REAL-SUCCESS PandaPickCube campaign: vanilla vs jumpy TD-MPC2, 3 seeds each (6 runs).
# Scored on REAL task success (box_target>=0.9), 1.5M steps, eval every 50k.
# Static round-robin GPU pin: at most 1 of MY runs per GPU at a time; refill as runs finish.
# Coexists with the CPU-only scripted-pick agent (which keeps small <800MB GPU allocs) -
# we do NOT gate on free memory (would falsely mark GPUs busy); each run uses ~1-1.5GB of 12GB.
set -u
REPO=/root/helios-rl
export PYTHONPATH=$REPO/src:/root/mujoco_playground_repo
LOGDIR=$REPO/ghm_logs
STATE=$LOGDIR/realsucc_campaign_state
mkdir -p "$STATE"
LOG=$LOGDIR/realsucc_campaign.log
say(){ echo "[$(date -u +%FT%TZ)] $*" | tee -a "$LOG"; }

# name|args|seed
RUNS=(
  "vanilla_s1|--jumpy_k 0|1"
  "vanilla_s2|--jumpy_k 0|2"
  "vanilla_s3|--jumpy_k 0|3"
  "jumpy_s1|--jumpy_k 8 --jumpy_plan --jumpy_n_macro 3 --mppi_horizon 16|1"
  "jumpy_s2|--jumpy_k 8 --jumpy_plan --jumpy_n_macro 3 --mppi_horizon 16|2"
  "jumpy_s3|--jumpy_k 8 --jumpy_plan --jumpy_n_macro 3 --mppi_horizon 16|3"
)
TOTAL_STEPS=1500000
NGPU=4
MAXATT=3

launch_one(){  # $1=gpu  $2=spec
  local gpu="$1" spec="$2"
  local name="${spec%%|*}"; local rest="${spec#*|}"
  local args="${rest%%|*}"; local seed="${rest##*|}"
  local rl="$LOGDIR/realsucc_${name}.log"
  echo "$gpu" > "$STATE/${name}.gpu"
  date -u +%s > "$STATE/${name}.started"
  say "LAUNCH $name on GPU$gpu (seed=$seed args=[$args])"
  setsid bash -c "
    cd $REPO
    source .venv/bin/activate 2>/dev/null
    export PYTHONPATH=$REPO/src:/root/mujoco_playground_repo
    MJPG_IMPL=jax CUDA_VISIBLE_DEVICES=$gpu TDMPC_EVAL_INTERVAL=50000 \
      TDMPC_GLASS_OUTPUT_TAG=realsucc_${name} \
      python3 scripts/run_benchmark.py --algos tdmpc2 --tasks PandaPickCube \
        $args --seed $seed --total_steps $TOTAL_STEPS >> $rl 2>&1
    rc=\$?
    rm -f $STATE/${name}.running
    if [ \$rc -eq 0 ] && grep -q 'All runs completed' $rl 2>/dev/null; then
      touch $STATE/${name}.done
    else
      touch $STATE/${name}.failed
    fi
  " < /dev/null > /dev/null 2>&1 &
  touch "$STATE/${name}.running"
  sleep 60   # stagger JIT compiles (host RAM)
}

run_alive(){ [ -f "$STATE/$1.running" ]; }
run_done(){  [ -f "$STATE/$1.done" ]; }
gpu_busy_by_me(){  # $1=gpu : is any of MY runs currently running on this gpu?
  local g="$1" s nm
  for s in "${RUNS[@]}"; do nm="${s%%|*}"
    run_alive "$nm" && [ "$(cat "$STATE/$nm.gpu" 2>/dev/null)" = "$g" ] && return 0
  done
  return 1
}

say "=== REAL-SUCCESS campaign start: ${#RUNS[@]} runs x ${TOTAL_STEPS} steps on ${NGPU} GPUs ==="
while :; do
  remaining=0
  for spec in "${RUNS[@]}"; do
    name="${spec%%|*}"
    run_done "$name" && continue
    # retry failed (clear markers up to MAXATT)
    if [ -f "$STATE/${name}.failed" ]; then
      att=$(cat "$STATE/${name}.attempts" 2>/dev/null || echo 1)
      if [ "$att" -ge "$MAXATT" ]; then say "GIVEUP $name after $att attempts"; continue; fi
      echo $((att+1)) > "$STATE/${name}.attempts"
      rm -f "$STATE/${name}.failed" "$STATE/${name}.started"
      say "RETRY $name (attempt $((att+1)))"
    fi
    remaining=$((remaining+1))
    run_alive "$name" && continue            # already running
    [ -f "$STATE/${name}.started" ] && continue  # started but marker race; skip this pass
    # find a GPU with no live run of mine
    for g in $(seq 0 $((NGPU-1))); do
      if ! gpu_busy_by_me "$g"; then launch_one "$g" "$spec"; break; fi
    done
  done
  [ "$remaining" -eq 0 ] && break
  sleep 90
done
say "=== ALL RUNS DONE ==="
