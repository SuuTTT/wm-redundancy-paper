#!/usr/bin/env python3
"""Quick no-render success/return eval over several PandaPickCube checkpoints
to find a competent deterministic policy before rendering."""
import os, pickle, glob, sys
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.3")
import numpy as np, jax, jax.numpy as jnp
from mujoco_playground import registry
from helios.algorithms.tdmpc2 import Encoder, Pi

env = registry.load("PandaPickCube", config_overrides={"impl": "jax"})
act_dim = env.action_size
enc = Encoder(latent_dim=512, hidden=(512, 512), V=8)
pi = Pi(action_dim=act_dim, hidden=(512, 512))
reset = jax.jit(env.reset); step = jax.jit(env.step)

def eval_ckpt(path, n_ep=6, ep_len=150, thresh=0.9):
    params = pickle.load(open(path, "rb"))["params"]
    @jax.jit
    def act_of(o):
        z = enc.apply(params["enc"], o[None]); mu, _ = pi.apply(params["pi"], z)
        return jnp.tanh(mu)[0]
    key = jax.random.PRNGKey(0); rets = []; succ = 0; max_bts = []
    for ep in range(n_ep):
        key, rk = jax.random.split(key); st = reset(rk)
        cum = 0.0; mbt = 0.0; ok = False
        for t in range(ep_len - 1):
            a = act_of(jnp.asarray(st.obs)); st = step(st, a)
            cum += float(st.reward); bt = float(st.metrics["box_target"])
            mbt = max(mbt, bt)
            if bt >= thresh: ok = True
            if bool(st.done > 0.5): break
        rets.append(cum); succ += int(ok); max_bts.append(round(mbt, 3))
    return succ, n_ep, rets, max_bts

for path in sorted(sys.argv[1:]):
    s, n, rets, mbts = eval_ckpt(path)
    print(f"{os.path.basename(path):35s} success={s}/{n} ret_mean={np.mean(rets):7.1f} "
          f"max_box_target={mbts}", flush=True)
