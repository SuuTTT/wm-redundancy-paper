#!/usr/bin/env python3
"""Roll out the TD-MPC2 PLANNED policy (full MPPI + jumpy-macro-MPPI) on PandaPickCube
and measure REAL pick-and-place success, faithfully reusing run_benchmark's planner builders.

Success criterion (env-canonical, same as render_demo.py / pick.py):
  box_target = (1 - tanh(5*(0.9*pos_err + 0.1*rot_err))) * reached_box   (>=0.9 -> success)
We ALSO report raw reached_box (gripper grasped) and box height (did cube leave the table /
reach the elevated target). Planning hyperparams match the +60% eval exactly:
  jumk2: JUMPY_K=2 JUMPY_NMACRO=12 MPPI_H=4 NS=512  (eff horizon 24)
  jumk8: JUMPY_K=8 JUMPY_NMACRO=3  MPPI_H=16 NS=512 (eff horizon 24)
"""
import argparse, os, pickle, json
from pathlib import Path

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("MJPG_IMPL", "jax")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.25")

import numpy as np
import jax
import jax.numpy as jnp

from mujoco_playground import registry
from helios.algorithms.tdmpc2 import (
    Encoder, Dynamics, RewardHead, QEnsemble, Pi, JumpyDynamics, JumpyReward,
    make_mppi_fn, make_jumpy_mppi_fn, DEFAULTS,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--task", default="PandaPickCube")
    ap.add_argument("--tag", required=True)
    ap.add_argument("--mode", choices=["mppi", "jumpy"], required=True)
    ap.add_argument("--n_episodes", type=int, default=10)
    ap.add_argument("--episode_length", type=int, default=150)
    ap.add_argument("--out_dir", default="/root/helios-rl/demo_videos")
    ap.add_argument("--n_render", type=int, default=3)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--width", type=int, default=480)
    # planner hyperparams (must match the eval that produced +60%)
    ap.add_argument("--mppi_horizon", type=int, default=3)
    ap.add_argument("--jumpy_k", type=int, default=0)
    ap.add_argument("--jumpy_n_macro", type=int, default=3)
    ap.add_argument("--n_samples", type=int, default=512)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--success_thresh", type=float, default=0.9)
    args = ap.parse_args()

    d = DEFAULTS
    latent_dim = d["latent_dim"]; hidden = d["hidden"]; V = d["V"]
    num_bins = d["num_bins"]; gamma = d["gamma"]; rew_scale = d["rew_scale"]
    elites = d["NUM_ELITES"]; pi_trajs = d["NUM_PI_TRAJS"]; NI = d["NI"]
    MIN_STD = d["MIN_STD"]; MAX_STD = d["MAX_STD"]
    NS = args.n_samples
    H = args.mppi_horizon

    env = registry.load(args.task, config_overrides={"impl": "jax"})
    obs_dim, act_dim = env.observation_size, env.action_size
    obj_body = int(env._obj_body)
    print(f"env {args.task} obs={obs_dim} act={act_dim} dt={env.dt} obj_body={obj_body}", flush=True)

    enc_net = Encoder(latent_dim=latent_dim, hidden=hidden, V=V)
    dyn_net = Dynamics(latent_dim=latent_dim, hidden=hidden, V=V)
    rew_net = RewardHead(hidden=hidden, num_bins=num_bins)
    q_net = QEnsemble(hidden=hidden, num_bins=num_bins)
    pi_net = Pi(action_dim=act_dim, hidden=hidden)

    with open(args.ckpt, "rb") as f:
        ckpt = pickle.load(f)
    params = ckpt["params"]
    print(f"ckpt env_steps={ckpt.get('env_steps')} best_mppi={ckpt.get('best_mppi')}", flush=True)

    if args.mode == "mppi":
        plan = make_mppi_fn(
            enc_net, dyn_net, rew_net, q_net, pi_net,
            horizon=H, n_samples=NS, num_elites=elites,
            num_pi_trajs=pi_trajs, n_iter=NI,
            min_std=MIN_STD, max_std=MAX_STD,
            act_low=-1.0, act_high=1.0, act_dim=act_dim,
            gamma=gamma, rew_scale=rew_scale,
        )
        mu0 = lambda: jnp.zeros((H, act_dim))
        std0 = lambda: jnp.full((H, act_dim), MAX_STD)
    else:
        jdyn_net = JumpyDynamics(latent_dim=latent_dim, hidden=hidden, V=V)
        jrew_net = JumpyReward(hidden=hidden, num_bins=num_bins)
        plan = make_jumpy_mppi_fn(
            enc_net, jdyn_net, jrew_net, q_net, pi_net,
            k=args.jumpy_k, n_macro=args.jumpy_n_macro, n_samples=NS,
            num_elites=elites, n_iter=NI, min_std=MIN_STD, max_std=MAX_STD,
            act_low=-1.0, act_high=1.0, act_dim=act_dim, gamma=gamma,
        )
        mu0 = lambda: jnp.zeros((args.jumpy_n_macro, args.jumpy_k, act_dim))
        std0 = lambda: jnp.full((args.jumpy_n_macro, args.jumpy_k, act_dim), MAX_STD)

    reset_j = jax.jit(env.reset)
    step_j = jax.jit(env.step)

    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    try:
        import mediapy as media
        write_video = lambda p, fr, fps: media.write_video(str(p), fr, fps=fps)
    except ImportError:
        import imageio
        write_video = lambda p, fr, fps: imageio.mimsave(str(p), fr, fps=fps)

    key = jax.random.PRNGKey(args.seed)
    results = []
    written = []
    init_box_z = None
    for ep in range(args.n_episodes):
        key, rk = jax.random.split(key)
        state = reset_j(rk)
        traj = [jax.device_get(state)]
        obs = jnp.asarray(state.obs)
        mu, std = mu0(), std0()
        t0 = jnp.bool_(True)
        key, pk = jax.random.split(key)
        cum = 0.0
        max_box_target = 0.0
        max_reached = 0.0
        max_box_z = -1e9
        z0 = float(state.data.xpos[obj_body][2])
        target_z = float(state.info["target_pos"][2])
        succeeded = False
        steps = 0
        for t in range(args.episode_length):
            act, mu, std = plan(params, obs, mu, std, pk, t0)
            t0 = jnp.bool_(False)
            key, pk = jax.random.split(key)
            state = step_j(state, act)
            traj.append(jax.device_get(state))
            cum += float(state.reward)
            bt = float(state.metrics["box_target"])
            rb = float(state.info["reached_box"])
            bz = float(state.data.xpos[obj_body][2])
            max_box_target = max(max_box_target, bt)
            max_reached = max(max_reached, rb)
            max_box_z = max(max_box_z, bz)
            if bt >= args.success_thresh:
                succeeded = True
            steps = t + 1
            if bool(state.done > 0.5):
                break
            obs = jnp.asarray(state.obs)
        lift = max_box_z - z0
        results.append({
            "episode": ep, "return": round(cum, 2), "steps": steps,
            "success": bool(succeeded), "max_box_target": round(max_box_target, 4),
            "reached_box": bool(max_reached > 0.5),
            "box_init_z": round(z0, 4), "box_max_z": round(max_box_z, 4),
            "box_lift_cm": round(lift * 100, 2), "target_z": round(target_z, 4),
        })
        print(f"  ep {ep}: ret={cum:7.1f} steps={steps} SUCCESS={succeeded} "
              f"max_box_target={max_box_target:.3f} reached_box={max_reached>0.5} "
              f"box_lift={lift*100:5.1f}cm (init_z={z0:.3f} max_z={max_box_z:.3f} target_z={target_z:.3f})",
              flush=True)

        if ep < args.n_render:
            try:
                frames = env.render(traj, height=args.height, width=args.width)
            except Exception as e:
                print(f"  render(h,w) failed: {e!r}; retry", flush=True)
                frames = env.render(traj)
            frames = [np.asarray(f) for f in frames]
            fps = int(round(1.0 / env.dt))
            sfx = "SUCCESS" if succeeded else ("REACHED" if max_reached > 0.5 else "fail")
            outp = out_dir / f"{args.task}_PLANNED_{args.tag}_ep{ep}_{sfx}.mp4"
            write_video(outp, frames, fps)
            written.append(str(outp))
            print(f"  wrote {outp} ({len(frames)} frames @ {fps}fps)", flush=True)

    n_succ = sum(r["success"] for r in results)
    n_reach = sum(r["reached_box"] for r in results)
    rets = [r["return"] for r in results]
    lifts = [r["box_lift_cm"] for r in results]
    summary = {
        "ckpt": args.ckpt, "mode": args.mode, "tag": args.tag,
        "planner": ({"mppi_H": H} if args.mode == "mppi"
                    else {"jumpy_k": args.jumpy_k, "jumpy_n_macro": args.jumpy_n_macro, "mppi_H": H}),
        "n_episodes": len(results),
        "success_rate": n_succ / len(results),
        "n_success": n_succ, "n_reached_box": n_reach,
        "return_mean": float(np.mean(rets)), "return_max": float(np.max(rets)),
        "box_lift_cm_mean": float(np.mean(lifts)), "box_lift_cm_max": float(np.max(lifts)),
        "episodes": results,
    }
    print("\n==== PLANNED SUMMARY ====", flush=True)
    print(f"mode={args.mode} tag={args.tag}", flush=True)
    print(f"REAL pick success_rate: {n_succ}/{len(results)} = {n_succ/len(results):.0%}", flush=True)
    print(f"reached_box (grasped) : {n_reach}/{len(results)}", flush=True)
    print(f"box_lift mean={np.mean(lifts):.1f}cm max={np.max(lifts):.1f}cm "
          f"(target is ~20-40cm above init)", flush=True)
    print(f"return mean={np.mean(rets):.1f} max={np.max(rets):.1f}", flush=True)
    print(f"videos: {written}", flush=True)
    jpath = out_dir / f"PLANNED_{args.tag}_{args.mode}_results.json"
    with open(jpath, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"JSON: {jpath}", flush=True)


if __name__ == "__main__":
    main()
