#!/usr/bin/env python3
"""Roll out a trained jumpy-k2 TD-MPC2 deterministic policy on PandaPickCube,
record per-episode SUCCESS + return, and render each episode to an mp4.

Deterministic policy: a = tanh(mu), mu,_ = pi(enc(obs)).

Success signal for PandaPickCube: the env has no boolean success flag. The
canonical "picked & placed" criterion is the box reaching the target with the
gripper having grasped it. We use the raw reward component
  box_target = (1 - tanh(5*(0.9*pos_err + 0.1*rot_err))) * reached_box
which is ~1 only when the box is AT the target AND was grasped. We mark an
episode SUCCESS if box_target >= 0.9 on any step (box within ~a few cm of
target, gripper grasped). We also report the per-step max box_target and the
plain summed return.

Usage:
  PYTHONPATH=src MUJOCO_GL=egl XLA_PYTHON_CLIENT_MEM_FRACTION=0.3 \
    python scripts/render_demo.py --ckpt demo_ckpts/seed0_best_mppi.pkl \
      --n_episodes 6 --out_dir demo_videos --tag seed0
"""
import argparse, os, pickle
from pathlib import Path

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.3")

import numpy as np
import jax
import jax.numpy as jnp

from mujoco_playground import registry
from helios.algorithms.tdmpc2 import Encoder, Pi, QEnsemble


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--task", default="PandaPickCube")
    ap.add_argument("--n_episodes", type=int, default=6)
    ap.add_argument("--episode_length", type=int, default=150)
    ap.add_argument("--out_dir", default="demo_videos")
    ap.add_argument("--tag", default="seed0")
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--width", type=int, default=480)
    ap.add_argument("--latent_dim", type=int, default=512)
    ap.add_argument("--num_bins", type=int, default=101)
    ap.add_argument("--V", type=int, default=8)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--success_thresh", type=float, default=0.9)
    args = ap.parse_args()
    hidden = (512, 512)

    # Unwrapped single-env (cleanest for env.render(traj)). impl=jax per env req.
    env = registry.load(args.task, config_overrides={"impl": "jax"})
    obs_dim, act_dim = env.observation_size, env.action_size
    print(f"env {args.task}  obs={obs_dim} act={act_dim} dt={env.dt}", flush=True)

    enc_net = Encoder(latent_dim=args.latent_dim, hidden=hidden, V=args.V)
    pi_net = Pi(action_dim=act_dim, hidden=hidden)
    q_net = QEnsemble(hidden=hidden, num_bins=args.num_bins)  # noqa (built for parity)
    with open(args.ckpt, "rb") as f:
        params = pickle.load(f)["params"]

    @jax.jit
    def act_of(obs):  # (obs,) -> (act,) deterministic action tanh(mu)
        z = enc_net.apply(params["enc"], obs[None])
        mu, _ = pi_net.apply(params["pi"], z)
        return jnp.tanh(mu)[0]

    reset_j = jax.jit(env.reset)
    step_j = jax.jit(env.step)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    key = jax.random.PRNGKey(args.seed)
    results = []
    written = []
    try:
        import mediapy as media
        def write_video(path, frames, fps):
            media.write_video(str(path), frames, fps=fps)
    except ImportError:
        import imageio
        def write_video(path, frames, fps):
            imageio.mimsave(str(path), frames, fps=fps)

    for ep in range(args.n_episodes):
        key, rk = jax.random.split(key)
        state = reset_j(rk)
        traj = [jax.device_get(state)]
        cum = 0.0
        max_box_target = 0.0
        succeeded = False
        steps = 0
        for t in range(args.episode_length - 1):
            act = act_of(jnp.asarray(state.obs))
            state = step_j(state, act)
            traj.append(jax.device_get(state))
            cum += float(state.reward)
            bt = float(state.metrics["box_target"])  # raw reward component (reached_box gated)
            max_box_target = max(max_box_target, bt)
            if bt >= args.success_thresh:
                succeeded = True
            steps = t + 1
            if bool(state.done > 0.5):  # out-of-bounds / nan
                break
        results.append({
            "episode": ep, "return": round(cum, 2), "steps": steps,
            "success": bool(succeeded), "max_box_target": round(max_box_target, 4),
        })
        print(f"  ep {ep}: return={cum:.2f} steps={steps} "
              f"success={succeeded} max_box_target={max_box_target:.3f}", flush=True)

        # Render this episode's trajectory.
        try:
            frames = env.render(traj, height=args.height, width=args.width)
        except Exception as e:  # fall back: default camera / no kwargs
            print(f"  render(traj,h,w) failed: {e!r}; retry no-size", flush=True)
            frames = env.render(traj)
        frames = [np.asarray(f) for f in frames]
        fps = int(round(1.0 / env.dt))
        outp = out_dir / f"{args.task}_{args.tag}_ep{ep}_{'SUCCESS' if succeeded else 'fail'}.mp4"
        write_video(outp, frames, fps)
        written.append(str(outp))
        print(f"  wrote {outp} ({len(frames)} frames @ {fps}fps)", flush=True)

    n_succ = sum(r["success"] for r in results)
    rets = [r["return"] for r in results]
    print("\n==== SUMMARY ====", flush=True)
    print(f"ckpt: {args.ckpt}", flush=True)
    print(f"success_rate: {n_succ}/{len(results)} = {n_succ/len(results):.2%}", flush=True)
    print(f"returns: {rets}", flush=True)
    print(f"return mean={np.mean(rets):.2f} min={np.min(rets):.2f} max={np.max(rets):.2f}", flush=True)
    print(f"videos: {written}", flush=True)


if __name__ == "__main__":
    main()
