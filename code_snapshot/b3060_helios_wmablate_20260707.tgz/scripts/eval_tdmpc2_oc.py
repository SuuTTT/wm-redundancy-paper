"""Batched TD-MPC2 OpenCabinet evaluator. Loads a saved policy/world-model pkl,
rebuilds nets + MPPI exactly as run_benchmark.py, rolls out n=256 envs at both
protocols with both pi (reactive) and mppi (planning) action modes.

Protocol A = mean native return over a 1000-step rollout, n=256.
Protocol B = success in one episode = (max box_target >= 0.9) within the rollout; n=256.
We report B at both 150-step and 1000-step horizons.

Reads box_target straight from env metrics on every step (the in-training harness
never logged success for OpenCabinet, so success is computed here from scratch).
Every number written to JSON is from a real rollout.
"""
import os, sys, json, pickle, time, argparse
os.environ.setdefault("MJPG_IMPL", "jax")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.85")
sys.path.insert(0, "/root/helios-rl/src")
sys.path.insert(0, "/root/helios-rl/scripts")
import numpy as np
import jax, jax.numpy as jnp
from mujoco_playground import registry, wrapper
from helios.algorithms.tdmpc2 import (
    Encoder, Dynamics, RewardHead, QEnsemble, Pi, make_mppi_fn, DEFAULTS,
)

SUCC_THRESH = 0.9

def build(act_dim):
    d = DEFAULTS
    enc = Encoder(latent_dim=d["latent_dim"], hidden=d["hidden"], V=d["V"])
    dyn = Dynamics(latent_dim=d["latent_dim"], hidden=d["hidden"], V=d["V"])
    rew = RewardHead(hidden=d["hidden"], num_bins=d["num_bins"])
    q   = QEnsemble(hidden=d["hidden"], num_bins=d["num_bins"])
    pi  = Pi(action_dim=act_dim, hidden=d["hidden"])
    return enc, dyn, rew, q, pi

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n_eps", type=int, default=256)
    ap.add_argument("--modes", nargs="+", default=["pi", "mppi"])
    ap.add_argument("--horizons", nargs="+", type=int, default=[150, 1000])
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    payload = pickle.load(open(args.ckpt, "rb"))
    params = payload["params"]
    env_id = payload.get("env_id", "PandaOpenCabinet")
    ckpt_step = int(payload.get("env_steps", -1))
    assert "PandaOpenCabinet" in env_id, f"unexpected env_id {env_id}"

    env = registry.load(env_id, config_overrides={"impl": "jax"})
    act_dim = int(env.action_size)
    enc, dyn, rew, q, pi = build(act_dim)
    d = DEFAULTS

    plan = make_mppi_fn(
        enc, dyn, rew, q, pi,
        horizon=d["H"], n_samples=d["NS"], num_elites=d["NUM_ELITES"],
        num_pi_trajs=d["NUM_PI_TRAJS"], n_iter=d["NI"],
        min_std=d["MIN_STD"], max_std=d["MAX_STD"],
        act_low=-1.0, act_high=1.0, act_dim=act_dim,
        gamma=d["gamma"], rew_scale=d["rew_scale"],
    )
    # vmap MPPI over the env batch: obs/mu/std/key/t0 per env, params shared.
    plan_b = jax.jit(jax.vmap(plan, in_axes=(None, 0, 0, 0, 0, 0)))

    @jax.jit
    def enc_b(p, obs):           # (N,obs)->(N,latent)
        return enc.apply(p["enc"], obs)

    @jax.jit
    def pi_b(p, z):              # deterministic tanh(mean), (N,latent)->(N,act)
        mu, _ = pi.apply(p["pi"], z)
        return jnp.tanh(mu)

    N = args.n_eps
    results = {
        "ckpt": args.ckpt, "env_id": env_id, "ckpt_step": ckpt_step,
        "n_eps": N, "succ_thresh": SUCC_THRESH,
        "protocolA_note": "mean native return over a 1000-step rollout, n=256",
        "protocolB_note": "success = (max box_target >= 0.9) within the rollout; n=256",
        "modes": {},
    }

    for horizon in args.horizons:
        env_w = wrapper.wrap_for_brax_training(
            env, episode_length=horizon, action_repeat=1, randomization_fn=None)
        reset_fn = jax.jit(env_w.reset)
        step_fn = jax.jit(env_w.step)

        for mode in args.modes:
            key = jax.random.PRNGKey(args.seed)
            key, rk = jax.random.split(key)
            state = reset_fn(jax.random.split(rk, N))
            obs = state.obs
            ep_ret = jnp.zeros(N)
            max_bt = jnp.zeros(N)
            reached = jnp.zeros(N)
            if mode == "mppi":
                mu = jnp.zeros((N, d["H"], act_dim))
                std = jnp.full((N, d["H"], act_dim), d["MAX_STD"])
                t0 = jnp.ones((N,), dtype=jnp.bool_)
            t_start = time.time()
            for t in range(horizon):
                z = enc_b(params, obs)
                if mode == "pi":
                    act = pi_b(params, z)
                else:
                    key, pk = jax.random.split(key)
                    pks = jax.random.split(pk, N)
                    act, mu, std = plan_b(params, obs, mu, std, pks, t0)
                    t0 = jnp.zeros((N,), dtype=jnp.bool_)
                state = step_fn(state, act)
                ep_ret = ep_ret + state.reward
                bt = state.metrics["box_target"]
                max_bt = jnp.maximum(max_bt, bt)
                if "reached_box" in state.info:
                    reached = jnp.maximum(reached, state.info["reached_box"].astype(jnp.float32))
                obs = state.obs
            max_bt_np = np.asarray(max_bt)
            ep_ret_np = np.asarray(ep_ret)
            succ = (max_bt_np >= SUCC_THRESH).astype(np.float32)
            entry = {
                "horizon": horizon,
                "success_rate": float(succ.mean()),
                "mean_return": float(ep_ret_np.mean()),
                "mean_max_box_target": float(max_bt_np.mean()),
                "p90_max_box_target": float(np.percentile(max_bt_np, 90)),
                "max_max_box_target": float(max_bt_np.max()),
                "reached_rate": float(np.asarray(reached).mean()),
                "n_eps": N,
                "eval_sec": round(time.time() - t_start, 1),
            }
            key_name = f"{mode}_H{horizon}"
            results["modes"][key_name] = entry
            print(f"  {key_name}: succ={entry['success_rate']:.4f} "
                  f"ret={entry['mean_return']:.1f} bt_mean={entry['mean_max_box_target']:.3f} "
                  f"reached={entry['reached_rate']:.3f} ({entry['eval_sec']}s)", flush=True)

    with open(args.out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"WROTE {args.out}", flush=True)

if __name__ == "__main__":
    main()
