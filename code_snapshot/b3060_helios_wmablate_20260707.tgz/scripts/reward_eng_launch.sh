#!/usr/bin/env bash
# Reward-engineering sweep: vanilla TD-MPC2 on PandaPickCube with engineered
# training rewards. SUCCESS still measured on original box_target>=0.9 metric.
set -u
REPO=/root/helios-rl
EXP=$REPO/exp/tdmpc_glass/reward_eng
mkdir -p $EXP
export PYTHONPATH=$REPO/src:/root/mujoco_playground_repo

launch(){  # $1=gpu $2=tag $3=env-overrides(string of VAR=VAL ...) $4=extra-args
  local gpu="$1" tag="$2" envov="$3" extra="$4"
  local rl="$EXP/${tag}.log"
  echo "[$(date -u +%FT%TZ)] LAUNCH $tag GPU$gpu env=[$envov] extra=[$extra]" | tee -a $EXP/launch.log
  setsid bash -c "
    cd $REPO
    source .venv/bin/activate 2>/dev/null
    export PYTHONPATH=$REPO/src:/root/mujoco_playground_repo
    export MJPG_IMPL=jax XLA_PYTHON_CLIENT_PREALLOCATE=false
    export CUDA_VISIBLE_DEVICES=$gpu
    export TDMPC_EVAL_INTERVAL=50000
    export TDMPC_GLASS_OUTPUT_TAG=$tag
    export $envov
    python3 scripts/run_benchmark.py --algos tdmpc2 --tasks PandaPickCube \
      $extra --seed 1 --total_steps 1000000 >> $rl 2>&1
    echo \"[$(date -u +%FT%TZ)] DONE $tag rc=\$?\" >> $EXP/launch.log
  " < /dev/null > /dev/null 2>&1 &
}

# V1: down-weight gripper_box (4->1), up-weight box_target (8->12). config-only lever.
launch 0 reweng_v1_s1 "PICKCUBE_W_GRIPPER_BOX=1.0 PICKCUBE_W_BOX_TARGET=12.0" "--jumpy_k 0"
sleep 45
# V2: V1 + ungated lift bonus (4.0). gives gradient to pick up the cube.
launch 1 reweng_v2_s1 "PICKCUBE_W_GRIPPER_BOX=1.0 PICKCUBE_W_BOX_TARGET=12.0 PICKCUBE_W_LIFT=4.0" "--jumpy_k 0"
sleep 45
# V3: V2 + grasp latch bonus (2.0). bridges the gated cliff.
launch 2 reweng_v3_s1 "PICKCUBE_W_GRIPPER_BOX=1.0 PICKCUBE_W_BOX_TARGET=12.0 PICKCUBE_W_LIFT=4.0 PICKCUBE_W_GRASP=2.0" "--jumpy_k 0"
echo "all launched"
