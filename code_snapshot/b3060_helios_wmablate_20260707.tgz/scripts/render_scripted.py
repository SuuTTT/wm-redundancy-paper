#!/usr/bin/env python3
"""Roll out the SCRIPTED pick controller, pick the episodes that achieve a REAL
grasp+lift, and render them to mp4 (SCRIPTED_*). Reuses the env-load + render +
success-signal conventions from render_demo.py.

Success signal = reward component box_target>=0.9 (box at target AND grasped).
We also track reached_box and box lift, and prefer episodes with the highest
max_box_target / largest lift for the videos.
"""
import os, argparse
os.environ.setdefault("MUJOCO_GL","egl")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE","false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION","0.3")
from pathlib import Path
import numpy as np, jax, jax.numpy as jnp
from mujoco_playground import registry
from scripted_pick import ScriptedPickController

ap=argparse.ArgumentParser()
ap.add_argument("--task",default="PandaPickCube")
ap.add_argument("--scan",type=int,default=24,help="episodes to scan")
ap.add_argument("--render",type=int,default=5,help="best episodes to render")
ap.add_argument("--episode_length",type=int,default=150)
ap.add_argument("--out_dir",default="demo_videos")
ap.add_argument("--height",type=int,default=480)
ap.add_argument("--width",type=int,default=480)
ap.add_argument("--seed",type=int,default=0)
ap.add_argument("--success_thresh",type=float,default=0.9)
args=ap.parse_args()

env=registry.load(args.task,config_overrides={"impl":"jax"})
print(f"env {args.task} obs={env.observation_size} act={env.action_size} dt={env.dt}",flush=True)
reset=jax.jit(env.reset); step=jax.jit(env.step)
ctrl=ScriptedPickController(env)
out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
try:
    import mediapy as media
    def write_video(p,f,fps): media.write_video(str(p),f,fps=fps)
except ImportError:
    import imageio
    def write_video(p,f,fps): imageio.mimsave(str(p),f,fps=fps)

key=jax.random.PRNGKey(args.seed)
eps=[]
for ep in range(args.scan):
    key,rk=jax.random.split(key)
    state=reset(rk); state=step(state,jnp.zeros(8)); ctrl.reset()
    b0=float(np.array(state.data.xpos[env._obj_body])[2])
    traj=[jax.device_get(state)]; maxbt=0.0; reached=0.0; maxlift=0.0; succ=False
    for t in range(args.episode_length-1):
        a=ctrl(state); state=step(state,jnp.asarray(a)); traj.append(jax.device_get(state))
        bt=float(state.metrics["box_target"]); maxbt=max(maxbt,bt)
        reached=max(reached,float(state.info["reached_box"]))
        maxlift=max(maxlift,float(np.array(state.data.xpos[env._obj_body])[2])-b0)
        if bt>=args.success_thresh: succ=True
        if bool(state.done>0.5): break
    eps.append(dict(ep=ep,traj=traj,maxbt=maxbt,reached=reached,maxlift=maxlift,succ=succ))
    print(f"  scan ep{ep}: succ={succ} maxbt={maxbt:.3f} reached={reached:.0f} maxlift={maxlift:.3f}",flush=True)

# rank: successes first, then by (lift then maxbt) to show clearest real grasps
eps.sort(key=lambda e:(e["succ"], e["maxlift"], e["maxbt"]), reverse=True)
written=[]
for e in eps[:args.render]:
    frames=[np.asarray(f) for f in env.render(e["traj"],height=args.height,width=args.width)]
    fps=int(round(1.0/env.dt))
    tag = "SUCCESS" if e["succ"] else ("GRASP_lift%.2f_bt%.2f" % (e["maxlift"], e["maxbt"]))
    p = out / ("SCRIPTED_%s_ep%d_%s.mp4" % (args.task, e["ep"], tag))
    write_video(p,frames,fps); written.append(str(p))
    print(f"  wrote {p} ({len(frames)} frames)",flush=True)

ns=sum(e["succ"] for e in eps); nr=sum(e["reached"]>0.5 for e in eps)
print("\n==== SUMMARY ====")
print(f"scanned {len(eps)} eps  success(box_target>=0.9): {ns}/{len(eps)}")
print("reached_box: %d/%d  max lift: %.3f" % (nr, len(eps), max(e["maxlift"] for e in eps)))
print("videos:",written)
