#!/bin/bash
# Copies fresh TD-MPC2 OpenCabinet eval checkpoints out of the auto-pruned
# *checkpoints* dirs (the */15 cron deletes pkls >120min old) into a protected
# dir whose path contains no "checkpoint" substring. Runs until STOPFILE appears.
SAFE=/root/helios-rl/hl_opencabinet/tdmpc2_oc/saved_ckpts
STOP=/root/helios-rl/hl_opencabinet/tdmpc2_oc/rescuer.stop
mkdir -p "$SAFE"
while [ ! -f "$STOP" ]; do
  for src in /root/helios-rl/exp/tdmpc_glass/PandaOpenCabinet_p47_tdmpc2_oc_*/seed_*/checkpoints/*.pkl; do
    [ -e "$src" ] || continue
    rundir=$(echo "$src" | sed 's#.*/PandaOpenCabinet_\(p47[^/]*\)/.*#\1#')
    base=$(basename "$src")
    dst="$SAFE/${rundir}__${base}"
    # copy if newer than dst (or dst missing)
    if [ "$src" -nt "$dst" ] || [ ! -e "$dst" ]; then
      cp -f "$src" "$dst" 2>/dev/null && echo "[$(date -u +%FT%TZ)] rescued $dst" >> "$SAFE/rescuer.log"
    fi
  done
  sleep 120
done
echo "[$(date -u +%FT%TZ)] rescuer stopped" >> "$SAFE/rescuer.log"
