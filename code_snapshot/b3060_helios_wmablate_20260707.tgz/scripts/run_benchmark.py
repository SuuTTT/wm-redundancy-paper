#!/usr/bin/env python3
"""Benchmark PPO, SAC, and TD-MPC2 on 3 diverse MuJoCo Playground tasks.

Uses helios.algorithms library modules throughout.

Outputs:
    helios-rl/exp/benchmark/ppo_<task>.csv
    helios-rl/exp/benchmark/sac_<task>.csv
    helios-rl/exp/benchmark/tdmpc2_<task>.csv
    (CSV format: task,seed,step,reward)

Usage:
    PYTHONPATH=/workspace/helios-rl/src:/workspace/wiki/learn_mujoco_playground/repo \\
        python3 helios-rl/scripts/run_benchmark.py [--total_steps 3000000] [--seed 1]
"""

import argparse
import os
import pickle
import sys
import time
from pathlib import Path

os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.55")

import jax
import jax.numpy as jnp
import numpy as np
import optax

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "wiki/learn_mujoco_playground/repo"))
from mujoco_playground import registry, wrapper

EXP_DIR = Path(__file__).resolve().parents[1] / "exp" / "benchmark"

TASKS = ["CartpoleBalance", "HopperStand", "CheetahRun"]


# ─────────────────────────────────────────────────────────────────────────────
# CSV helpers
# ─────────────────────────────────────────────────────────────────────────────

def open_csv(path: Path, env_id: str, seed: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    is_new = not path.exists()
    fh = open(path, "a", buffering=1)
    if is_new:
        fh.write("task,seed,step,reward\n")
    return fh


def write_csv(fh, env_id: str, seed: int, step: int, reward: float):
    fh.write(f"{env_id},{seed},{step},{reward:.4f}\n")
    fh.flush()


def save_pickle_atomic(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "wb") as fh:
        pickle.dump(payload, fh, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(tmp, path)


def maybe_add_distractors(env, n_dims: int, scale: float = 1.0, rho: float = 0.95):
    """iter-14 Stage-2a: append `n_dims` temporally-correlated (OU-process) nuisance
    dimensions to the observation. Tests whether an encoder learns to IGNORE
    behaviorally-irrelevant but predictable input (the distractor-robustness
    hypothesis behind behavioral abstraction) without any pixel infra.

    JIT/vmap-safe: the noise state + its PRNG key live in `state.info` with identical
    pytree structure in reset and step. Applied BEFORE wrap_for_brax_training so the
    episode/autoreset/vmap wrappers see a consistent env. n_dims<=0 -> returns env
    unchanged (graph identical; fleet-safe default)."""
    if not n_dims or n_dims <= 0:
        return env

    class _Distracted:
        def __init__(self, inner):
            self.__dict__["_inner"] = inner

        def __getattr__(self, k):
            return getattr(self.__dict__["_inner"], k)

        @property
        def observation_size(self):
            return self.__dict__["_inner"].observation_size + n_dims

        def reset(self, rng):
            k_env, k_noise = jax.random.split(rng)
            s = self.__dict__["_inner"].reset(k_env)
            z = scale * jax.random.normal(k_noise, (n_dims,))
            s.info["_distract_z"] = z
            s.info["_distract_k"] = k_noise
            return s.replace(obs=jnp.concatenate([s.obs, z], axis=-1))

        def step(self, s, a):
            z = s.info["_distract_z"]
            k = s.info["_distract_k"]
            k, sub = jax.random.split(k)
            # OU update: stationary std == scale, strong temporal correlation (rho).
            z = rho * z + scale * jnp.sqrt(1.0 - rho * rho) * jax.random.normal(sub, z.shape)
            s2 = self.__dict__["_inner"].step(s, a)
            s2.info["_distract_z"] = z
            s2.info["_distract_k"] = k
            return s2.replace(obs=jnp.concatenate([s2.obs, z], axis=-1))

    print(f"  DISTRACTORS: +{n_dims} OU nuisance obs dims (scale={scale}, rho={rho})", flush=True)
    return _Distracted(env)


def buffer_state(buf) -> dict:
    """Return a replay-buffer snapshot suitable for exact off-policy resume."""
    return {
        "cap": buf.cap,
        "N": buf.N,
        "T": buf.T,
        "obs": buf.obs,
        "acts": buf.acts,
        "rews": buf.rews,
        "done": buf.done,
        "ptr": buf.ptr,
        "size": buf.size,
    }


def restore_buffer_state(buf, state: dict) -> None:
    """Restore a replay-buffer snapshot into an existing buffer object."""
    buf.cap = int(state["cap"])
    buf.N = int(state["N"])
    buf.T = int(state["T"])
    buf.obs = state["obs"]
    buf.acts = state["acts"]
    buf.rews = state["rews"]
    buf.done = state["done"]
    buf.ptr = state["ptr"]
    buf.size = state["size"]


# ─────────────────────────────────────────────────────────────────────────────
# PPO (v34s3 architecture from helios.algorithms.ppo)
# ─────────────────────────────────────────────────────────────────────────────

def train_ppo(env_id: str, total_steps: int, seed: int, csv_path: Path) -> None:
    """Train PPO (v34s3 Brax-exact) using helios.algorithms.ppo."""
    print(f"\n{'='*60}", flush=True)
    print(f"  PPO | {env_id} | seed={seed} | steps={total_steps:,}", flush=True)
    print(f"{'='*60}", flush=True)

    from flax.training.train_state import TrainState
    from helios.algorithms.ppo import (
        PolicyNet, ValueNet,
        obs_norm_init, obs_norm_apply, obs_norm_update,
        make_update_fn,
    )

    # ── Hyperparams (Brax-exact milestone, num_envs reduced for benchmark speed)
    num_envs        = 512
    num_steps       = 30
    update_epochs   = 16
    num_minibatches = 32
    lr              = 1e-3
    gamma           = 0.995
    gae_lambda      = 0.95
    clip_coef       = 0.3
    vf_coef         = 0.5
    ent_coef        = 0.01
    max_grad_norm   = 1.0
    reward_scaling  = 10.0
    normalize_obs   = True
    episode_length  = 1000
    eval_interval   = max(total_steps // 12, 1)

    steps_per_iter = update_epochs * num_steps * num_envs  # ≈ 246K

    # ── Environment (ppofix: honor MJPG_IMPL like the tdmpc2 path; default
    # mujoco_playground picks the warp backend which mismatches mujoco-mjx 3.9’s
    # GraphMode → AttributeError. MJPG_IMPL=jax forces the pure-JAX MJX backend.)
    _mjpg_impl = os.environ.get("MJPG_IMPL", "").strip()
    if _mjpg_impl:
        print(f"  using env impl override: {_mjpg_impl}", flush=True)
    env      = (registry.load(env_id, config_overrides={"impl": _mjpg_impl})
               if _mjpg_impl else registry.load(env_id))
    env      = wrapper.wrap_for_brax_training(env, episode_length=episode_length,
                                              action_repeat=1)
    obs_dim  = env.observation_size
    act_dim  = env.action_size

    # ── Networks
    policy_net = PolicyNet(action_dim=act_dim)
    value_net  = ValueNet()
    key = jax.random.PRNGKey(seed)
    key, pk, vk = jax.random.split(key, 3)
    dummy = jnp.zeros(obs_dim)
    policy_params = policy_net.init(pk, dummy)
    value_params  = value_net.init(vk, dummy)

    agent_state = TrainState.create(
        apply_fn=None,
        params={"policy_params": policy_params, "value_params": value_params},
        tx=optax.chain(
            optax.clip_by_global_norm(max_grad_norm),
            optax.adam(lr, eps=1e-5),
        ),
    )

    # ── Compiled update fn from library
    rollout_and_update = make_update_fn(
        policy_net, value_net,
        jax.jit(env.step),
        num_envs=num_envs, num_steps=num_steps,
        update_epochs=update_epochs, num_minibatches=num_minibatches,
        gamma=gamma, gae_lambda=gae_lambda,
        clip_coef=clip_coef, vf_coef=vf_coef, ent_coef=ent_coef,
        normalize_obs=normalize_obs, reward_scaling=reward_scaling,
    )

    # ── Eval (deterministic mean action)
    _env_step = jax.jit(env.step)

    @jax.jit
    def eval_policy(params, obs_ns, key):
        eval_state = env.reset(jax.random.split(key, num_envs))
        ep_ret = jnp.zeros(num_envs)

        def step_fn(carry, _):
            es, obs, ep_ret = carry
            norm_obs = obs_norm_apply(obs_ns, obs)
            logits = policy_net.apply(params["policy_params"], norm_obs)
            mean, _ = jnp.split(logits, 2, axis=-1)
            action = jnp.tanh(mean)
            nes = _env_step(es, action)
            return (nes, nes.obs, ep_ret + nes.reward), None

        (_, _, ep_ret), _ = jax.lax.scan(
            step_fn, (eval_state, eval_state.obs, ep_ret), None, length=episode_length
        )
        return ep_ret.mean()

    # ── Init env state
    key, rk = jax.random.split(key)
    env_state = env.reset(jax.random.split(rk, num_envs))
    next_obs  = env_state.obs
    next_done = jnp.zeros(num_envs, dtype=jnp.bool_)
    obs_ns    = obs_norm_init(obs_dim)
    ep_ret    = jnp.zeros(num_envs)
    ep_len    = jnp.zeros(num_envs, dtype=jnp.int32)

    # ── Warmup JIT
    print("  Warming up JIT...", flush=True)
    t_jit = time.time()
    agent_state, env_state, next_obs, next_done, key, ep_ret, ep_len, obs_ns, _ = (
        rollout_and_update(agent_state, env_state, next_obs, next_done, key,
                           ep_ret, ep_len, obs_ns)
    )
    jax.block_until_ready(agent_state.params)
    print(f"  JIT compiled in {time.time()-t_jit:.1f}s", flush=True)

    # ── Training loop
    global_step = steps_per_iter
    next_eval   = eval_interval
    t0 = time.time()

    with open_csv(csv_path, env_id, seed) as fh:
        while global_step < total_steps:
            agent_state, env_state, next_obs, next_done, key, ep_ret, ep_len, obs_ns, _ = (
                rollout_and_update(agent_state, env_state, next_obs, next_done, key,
                                   ep_ret, ep_len, obs_ns)
            )
            global_step += steps_per_iter

            if global_step >= next_eval:
                key, ek = jax.random.split(key)
                ret = float(eval_policy(agent_state.params, obs_ns, ek))
                sps = int(global_step / max(time.time() - t0, 1))
                print(f"  step={global_step:>9,}  reward={ret:7.2f}  sps={sps:,}", flush=True)
                write_csv(fh, env_id, seed, global_step, ret)
                next_eval += eval_interval

    print(f"  PPO {env_id} done in {time.time()-t0:.0f}s", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# SAC (custom v1 from helios.algorithms.sac)
# ─────────────────────────────────────────────────────────────────────────────

def train_sac(env_id: str, total_steps: int, seed: int, csv_path: Path) -> None:
    """Train SAC (custom v1) using helios.algorithms.sac."""
    print(f"\n{'='*60}", flush=True)
    print(f"  SAC | {env_id} | seed={seed} | steps={total_steps:,}", flush=True)
    print(f"{'='*60}", flush=True)

    from brax.training import replay_buffers as brax_buffers
    from helios.algorithms.sac import (
        Actor, TwinCritic,
        make_sac_fns, make_scan_update, make_collect_fn,
        tanh_normal_sample,
    )

    # ── Hyperparams (official brax SAC reference where applicable)
    hidden              = (512, 512)
    lr                  = 3e-4
    alpha_lr            = 3e-4
    gamma               = 0.99
    tau                 = 0.005
    reward_scaling      = 1.0
    normalize_obs       = True
    num_envs            = 32
    collect_steps       = 64
    grad_updates_ratio  = 2          # gradient updates per env step
    k_updates           = collect_steps * grad_updates_ratio
    batch_size          = 256
    min_replay_size     = 10_000
    max_replay_size     = 300_000
    episode_length      = 1000
    eval_interval       = max(total_steps // 12, 1)

    # ── Environment
    _mjpg_impl = os.environ.get("MJPG_IMPL", "").strip()
    env     = registry.load(env_id, config_overrides={"impl": _mjpg_impl}) if _mjpg_impl else registry.load(env_id)
    env     = wrapper.wrap_for_brax_training(env, episode_length=episode_length,
                                             action_repeat=1)
    obs_dim = env.observation_size
    act_dim = env.action_size
    target_entropy = -0.5 * act_dim
    print(f"  obs={obs_dim}  act={act_dim}  target_entropy={target_entropy:.2f}", flush=True)

    rng = jax.random.PRNGKey(seed)

    # ── Networks
    actor_net  = Actor(action_size=act_dim, hidden=hidden)
    critic_net = TwinCritic(hidden=hidden, layer_norm=True)

    rng, ak, ck = jax.random.split(rng, 3)
    dummy_obs = jnp.zeros((1, obs_dim))
    dummy_act = jnp.zeros((1, act_dim))
    actor_p   = actor_net.init(ak, dummy_obs)
    critic_p  = critic_net.init(ck, dummy_obs, dummy_act)
    target_p  = critic_p

    # ── Optimizers
    actor_opt  = optax.adam(lr)
    critic_opt = optax.adam(lr)
    alpha_opt  = optax.adam(alpha_lr)
    actor_opt_s  = actor_opt.init(actor_p)
    critic_opt_s = critic_opt.init(critic_p)
    log_alpha    = jnp.array(0.0)
    alpha_opt_s  = alpha_opt.init(log_alpha)

    # ── Running obs stats
    obs_mean  = jnp.zeros(obs_dim)
    obs_var   = jnp.ones(obs_dim)
    obs_count = 0.0

    # ── Replay buffer (GPU)
    dummy_transition = {
        "obs":      jnp.zeros(obs_dim),
        "action":   jnp.zeros(act_dim),
        "reward":   jnp.zeros(()),
        "next_obs": jnp.zeros(obs_dim),
        "done":     jnp.zeros(()),
    }
    buf = brax_buffers.UniformSamplingQueue(
        max_replay_size=max_replay_size,
        dummy_data_sample=dummy_transition,
        sample_batch_size=batch_size,
    )
    rng, bk = jax.random.split(rng)
    buf_state = buf.init(bk)

    # ── SAC functions from library
    one_step    = make_sac_fns(
        actor_net.apply, critic_net.apply,
        actor_opt, critic_opt, alpha_opt,
        gamma, reward_scaling, target_entropy, tau,
    )
    scan_update = make_scan_update(one_step, buf, k_updates)
    collect_fn  = make_collect_fn(jax.jit(env.step), actor_net.apply, collect_steps)

    # ── Env reset
    _env_reset = jax.jit(env.reset)
    _env_step  = jax.jit(env.step)
    rng, ek = jax.random.split(rng)
    env_keys = jax.random.split(ek, num_envs)

    # ── Warmup: fill buffer with random actions
    print("  Filling replay buffer...", flush=True)
    t_pre = time.time()
    env_state = _env_reset(env_keys)
    total_env_steps = 0

    while buf_state.insert_position < min_replay_size:
        rng, ak2 = jax.random.split(rng)
        raw_act  = jax.random.uniform(ak2, (num_envs, act_dim), minval=-1.0, maxval=1.0)
        ns = _env_step(env_state, raw_act)
        transitions = {
            "obs":      env_state.obs,
            "action":   raw_act,
            "reward":   ns.reward,
            "next_obs": ns.obs,
            "done":     ns.done,
        }
        buf_state = buf.insert(buf_state, transitions)
        if normalize_obs:
            o_np = np.array(env_state.obs)
            n = o_np.shape[0]
            obs_count += n
            delta   = np.mean(o_np, axis=0) - np.array(obs_mean)
            obs_mean = jnp.array(np.array(obs_mean) + delta * n / obs_count)
            obs_var  = jnp.array(np.maximum(
                (np.array(obs_var) * max(obs_count - n, 1) + np.var(o_np, axis=0) * n) / obs_count,
                1e-6,
            ))
        env_state = ns
        total_env_steps += num_envs
    print(f"  Replay filled: {int(buf_state.insert_position):,} transitions in {time.time()-t_pre:.1f}s", flush=True)

    # ── Warmup JIT for scan_update
    print("  Warming up scan_update JIT (may take 1-2 min)...", flush=True)
    t_jit = time.time()
    rng, uk = jax.random.split(rng)
    ap2, ao2, cp2, co2, tp2, la2, alo2, bs2 = scan_update(
        actor_p, actor_opt_s, critic_p, critic_opt_s, target_p,
        log_alpha, alpha_opt_s, obs_mean, obs_var, buf_state, uk,
    )
    jax.block_until_ready(ap2)
    actor_p, actor_opt_s, critic_p, critic_opt_s, target_p, log_alpha, alpha_opt_s, buf_state = (
        ap2, ao2, cp2, co2, tp2, la2, alo2, bs2
    )
    print(f"  scan_update JIT in {time.time()-t_jit:.1f}s", flush=True)

    # ── Warmup collect JIT
    rng, ck2 = jax.random.split(rng)
    env_state, rng, _ = collect_fn(env_state, actor_p, obs_mean, obs_var, ck2)
    total_env_steps += num_envs * collect_steps

    # ── Eval
    def evaluate():
        import numpy as _np
        key_e = jax.random.PRNGKey(seed + 99999)
        keys_e = jax.random.split(key_e, num_envs)
        es_e = _env_reset(keys_e)
        total = _np.zeros(num_envs)
        done  = _np.zeros(num_envs, bool)
        for _ in range(episode_length):
            obs_n = (_np.array(es_e.obs) - _np.array(obs_mean)) / _np.sqrt(_np.array(obs_var) + 1e-8)
            mu, _ = actor_net.apply(actor_p, jnp.array(obs_n))
            action = jnp.tanh(mu)
            es_e = _env_step(es_e, action)
            r = _np.array(es_e.reward)
            d = _np.array(es_e.done).astype(bool)
            total += r * (~done)
            done  |= d
            if done.all():
                break
        return float(_np.mean(total))

    # ── Training loop
    next_eval = eval_interval
    t0 = time.time()

    with open_csv(csv_path, env_id, seed) as fh:
        while total_env_steps < total_steps:
            # Collect
            rng, ck3 = jax.random.split(rng)
            env_state, rng, (flat_obs, flat_act, flat_rew, flat_nobs, flat_done) = collect_fn(
                env_state, actor_p, obs_mean, obs_var, ck3
            )
            transitions = {
                "obs":      flat_obs, "action":   flat_act,
                "reward":   flat_rew, "next_obs": flat_nobs,
                "done":     flat_done,
            }
            buf_state = buf.insert(buf_state, transitions)

            # Update obs stats
            if normalize_obs:
                o_np = np.array(flat_obs)
                n = o_np.shape[0]
                obs_count += n
                delta   = np.mean(o_np, axis=0) - np.array(obs_mean)
                obs_mean = jnp.array(np.array(obs_mean) + delta * n / obs_count)
                obs_var  = jnp.array(np.maximum(
                    (np.array(obs_var) * max(obs_count - n, 1) + np.var(o_np, axis=0) * n) / obs_count,
                    1e-6,
                ))

            # Gradient updates (lax.scan on GPU)
            rng, uk2 = jax.random.split(rng)
            (actor_p, actor_opt_s,
             critic_p, critic_opt_s,
             target_p, log_alpha, alpha_opt_s,
             buf_state) = scan_update(
                actor_p, actor_opt_s, critic_p, critic_opt_s, target_p,
                log_alpha, alpha_opt_s, obs_mean, obs_var, buf_state, uk2,
            )

            total_env_steps += num_envs * collect_steps

            if total_env_steps >= next_eval:
                ret = evaluate()
                sps = int(total_env_steps / max(time.time() - t0, 1))
                print(f"  step={total_env_steps:>9,}  reward={ret:7.2f}  "
                      f"α={float(jnp.exp(log_alpha)):.4f}  sps={sps:,}", flush=True)
                write_csv(fh, env_id, seed, total_env_steps, ret)
                next_eval += eval_interval

    print(f"  SAC {env_id} done in {time.time()-t0:.0f}s", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# TD-MPC2 (v24 from helios.algorithms.tdmpc2)
# ─────────────────────────────────────────────────────────────────────────────

def train_tdmpc2(
    env_id: str,
    total_steps: int,
    seed: int,
    csv_path: Path,
    use_glass: bool = False,
    resume_checkpoint: str | None = None,
    save_full_state: bool = False,
    glass_overrides: dict | None = None,
    act_noise_start: float | None = None,
    act_noise_end: float | None = None,
    act_noise_anneal_steps: int = 1_000_000,
    mppi_horizon: int | None = None,
    mppi_n_samples: int | None = None,
    k_update: int | None = None,
    q_reset_steps: list[int] | None = None,
    latent_action_smooth_coef: float = 0.0,
    consistency_coef: float | None = None,
    bisim_coef: float = 0.0,
    distractor_dims: int = 0,
    early_stop_patience: int = 0,
    latent_smooth_warmup_env_steps: int = 0,
    glass_decay_steps: int = 0,
    expl_until: int | None = None,
    expl_mix_decay_steps: int = 0,
    knee_penalty_coef: float = 0.0,
    knee_penalty_threshold: float = 0.15,
    cluster_intrinsic_coef: float = 0.0,
    cluster_intrinsic_window: int = 20,
    cluster_intrinsic_decay_steps: int = 0,
    proto_novelty_coef: float = 0.0,
    proto_novelty_decay_steps: int = 0,
    # iter-6 §7.C — Phase-r2 gait penalty bundle
    gait_fall_penalty: float = 0.0,
    gait_fall_height: float = 0.45,
    gait_action_smooth: float = 0.0,
    # iter-6 §7.B — Phase-r1 soft-reward bundle
    soft_stand_bonus: float = 0.0,
    soft_stand_floor: float = 0.4,
    soft_anneal_steps: int = 0,
    # iter-7 §2.1 — Phase-ar auto-restart on plateau (basin-lottery escape)
    restart_on_plateau: bool = False,
    restart_check_at: int = 1_000_000,
    restart_threshold: float = 100.0,
    restart_max_attempts: int = 3,
    mpc_distill_coef: float = 0.0,
    mpc_distill_anneal_steps: int = 3_000_000,
    mpc_distill_disable_gap: float = 100.0,
    mpc_distill_batch_size: int = 16,
    controller_arbitration: str = "none",
    arbitration_margin: float = 0.0,
    latent_norm: str = "simnorm",
    fsq_levels: int = 5,
    dyn_arch: str = "mlp",
    rho_override: float | None = None,
    intrinsic: str = "none",
    intrinsic_coef: float = 0.0,
    jumpy_k: int = 0,
    jumpy_coef: float = 1.0,
    jumpy_ve_coef: float = 0.0,
    jumpy_plan: bool = False,
    jumpy_n_macro: int = 3,
    calib_coef: float = 0.0,
    calib_q: float = 0.9,
) -> None:
    """Train TD-MPC2 or TD-MPC-Glass."""
    algo_name = "TD-MPC-Glass" if use_glass else "TD-MPC2"
    print(f"\n{'='*60}", flush=True)
    print(f"  {algo_name} | {env_id} | seed={seed} | steps={total_steps:,}", flush=True)
    print(f"{'='*60}", flush=True)

    if use_glass:
        from helios.algorithms.tdmpc_glass import (
            Encoder, Dynamics, RewardHead, QEnsemble, Pi,
            MultiEnvBuffer, make_update_fn, make_mppi_fn, make_glass_diag_fn,
            make_proto_mppi_fn, init_glass_params, DEFAULTS,
        )
    else:
        from helios.algorithms.tdmpc2 import (
            Encoder, Dynamics, RewardHead, QEnsemble, Pi, JumpyDynamics, JumpyReward,
            MultiEnvBuffer, make_update_fn, make_mppi_fn, make_jumpy_mppi_fn, DEFAULTS,
        )

    # ── Hyperparams (v24 milestone)
    d          = dict(DEFAULTS)
    import os as _os
    _ints={"TDMPC_LATENT_DIM":"latent_dim","TDMPC_KUPDATE":"K_UPDATE","TDMPC_NS":"NS","TDMPC_NI":"NI","TDMPC_NENVS":"N_ENVS","TDMPC_BS":"BS"}
    for _e,_dk in _ints.items():
        if _os.environ.get(_e): d[_dk]=int(_os.environ[_e])
    if _os.environ.get("TDMPC_HIDDEN"): d["hidden"]=tuple(int(x) for x in _os.environ["TDMPC_HIDDEN"].split(","))
    if any(_os.environ.get(_e) for _e in list(_ints)+["TDMPC_HIDDEN"]):
        print(f"  [size-override] latent_dim={d['latent_dim']} hidden={d['hidden']} K_UPDATE={d['K_UPDATE']} NS={d['NS']} NI={d['NI']} N_ENVS={d['N_ENVS']} BS={d['BS']}", flush=True)
    latent_dim = d["latent_dim"]   # 512
    hidden     = d["hidden"]       # (512, 512)
    num_bins   = d["num_bins"]     # 101
    V          = d["V"]            # 8
    lr         = d["lr"]           # 3e-4
    gamma      = d["gamma"]        # 0.99
    tau        = d["tau"]          # 0.01
    rho        = float(rho_override) if rho_override is not None else d["rho"]   # 0.5 default
    if rho_override is not None:
        print(f"  iter-20 rho override: consistency-horizon decay rho={rho} (default {d['rho']}) "
              f"— trains dynamics to be accurate at LONG horizons for deep planning", flush=True)
    rew_scale  = d["rew_scale"]    # 10.0
    K_UPDATE   = int(k_update) if k_update is not None else d["K_UPDATE"]     # 64
    if k_update is not None and K_UPDATE != d["K_UPDATE"]:
        print(f"  K_UPDATE override: {K_UPDATE} gradient updates per batch (default {d['K_UPDATE']})", flush=True)
    BS         = d["BS"]           # 256
    N_ENVS     = d["N_ENVS"]       # 256
    # ── Cross-benchmark bridge: OGBench source runs CPU gym envs (no MJX). We run
    # a small vector of CPU envs in a python loop, so N_ENVS must be modest.
    _ogbench_src = os.environ.get("TDMPC_ENV_SRC", "").strip()
    _is_ogbench = _ogbench_src.startswith("ogbench:")
    # REAL-SUCCESS (additive, 2026-06-20): PandaPickCube exposes the true task
    # signal via reward components. box_target metric = (1-tanh(5*(0.9*pos_err+
    # 0.1*rot_err)))*reached_box (raw, unscaled); SUCCESS when box_target>=0.9 at
    # ANY step. reached_box (state.info) = gripper touched cube. Dense shaping
    # return is reward-hacked, so we log REAL success to a *_realsuccess.csv sidecar.
    _is_pickcube = ("PandaPickCube" in env_id)
    _SUCC_THRESH = 0.9
    if _is_ogbench:
        N_ENVS = int(os.environ.get("TDMPC_OGBENCH_NENVS", "8"))
        print(f"  [ogbench-bridge] CPU env source; N_ENVS={N_ENVS}", flush=True)
    WARMUP     = d["WARMUP_ENV"]   # 25_000
    EXPL_NOISE = d["EXPL_NOISE"]   # 0.3
    EXPL_UNTIL = int(expl_until) if expl_until is not None else d["EXPL_UNTIL"]   # 25_000 default
    if expl_until is not None and EXPL_UNTIL != d["EXPL_UNTIL"]:
        print(f"  EXPL_UNTIL override: random actions for first {EXPL_UNTIL:,} env-steps (default {d['EXPL_UNTIL']:,})", flush=True)
    EXPL_MIX_DECAY_STEPS = max(int(expl_mix_decay_steps), 0)
    if EXPL_MIX_DECAY_STEPS > 0:
        print(
            f"  EXPL_MIX override: random-policy action mixture decays random prob 1.0 -> 0.0 "
            f"over {EXPL_MIX_DECAY_STEPS:,} env-steps",
            flush=True,
        )
    # Optional act-noise anneal: linearly decay from start -> end over
    # `act_noise_anneal_steps` env steps. Defaults reproduce baseline behaviour
    # (constant EXPL_NOISE).
    _noise_start = float(act_noise_start) if act_noise_start is not None else float(EXPL_NOISE)
    _noise_end   = float(act_noise_end)   if act_noise_end   is not None else _noise_start
    _noise_anneal_steps = max(int(act_noise_anneal_steps), 1)
    def _current_noise(es: int) -> float:
        frac = min(max(es / _noise_anneal_steps, 0.0), 1.0)
        return _noise_start + (_noise_end - _noise_start) * frac
    if _noise_start != _noise_end:
        print(f"  act-noise anneal: {_noise_start:.3f} -> {_noise_end:.3f} over {_noise_anneal_steps:,} env-steps", flush=True)
    H          = int(mppi_horizon) if mppi_horizon is not None else d["H"]   # 3 by default
    if mppi_horizon is not None and H != d["H"]:
        print(f"  MPPI horizon override: H={H} (DEFAULTS['H']={d['H']})", flush=True)
    NS         = int(mppi_n_samples) if mppi_n_samples is not None else d["NS"]   # 512 default
    if mppi_n_samples is not None and NS != d["NS"]:
        print(f"  MPPI n_samples override: NS={NS} (DEFAULTS['NS']={d['NS']})", flush=True)
    elites     = d["NUM_ELITES"]   # 64
    pi_trajs   = d["NUM_PI_TRAJS"] # 24
    NI         = d["NI"]           # 6
    MIN_STD    = d["MIN_STD"]      # 0.05
    MAX_STD    = d["MAX_STD"]      # 2.0
    glass_cfg  = dict(d.get("glass", {}))
    if glass_overrides:
        glass_cfg.update({k: v for k, v in glass_overrides.items() if v is not None})
    seq_len    = H + 1             # 4 — trajectory length in buffer
    buf_cap    = max(total_steps // N_ENVS + 1000, 50_000)
    # iter-14: frequent evals on DMC. 2026-06-20: honor TDMPC_EVAL_INTERVAL on the MJX
    # path too (was ogbench-only) so smoke runs can eval early; default unchanged (50k).
    _default_ei = 250_000 if env_id == "HopperHop" else 50_000
    eval_interval = int(os.environ.get("TDMPC_EVAL_INTERVAL", str(_default_ei)))
    episode_length = 1000

    # ── Environment
    # MJPG_IMPL=jax forces the pure-JAX MJX backend (newer mujoco_playground defaults to the
    # 'warp' backend, which mismatches mujoco-mjx 3.9's GraphMode → AttributeError). Opt-in.
    _mjpg_impl = os.environ.get("MJPG_IMPL", "").strip()
    if _is_ogbench:
        # ── Cross-benchmark bridge: build the OGBench CPU adapter instead of the
        # mujoco_playground registry. It already exposes a brax-style batched env
        # (.reset/.step/.observation_size/.action_size with auto-reset), so we
        # skip distractors + brax wrappers entirely.
        from ogbench_adapter import make_ogbench_env
        _og_name = _ogbench_src.split("ogbench:", 1)[1]
        env = make_ogbench_env(_og_name, N_ENVS, seed=seed)
        episode_length = env.max_episode_steps
        eval_interval = int(os.environ.get("TDMPC_EVAL_INTERVAL", "50000"))
        print(f"  [ogbench-bridge] env={_og_name} obs={env.observation_size} "
              f"act={env.action_size} ep_len={episode_length}", flush=True)
    else:
        env      = registry.load(env_id, config_overrides={"impl": _mjpg_impl}) if _mjpg_impl else registry.load(env_id)
        env      = maybe_add_distractors(env, distractor_dims)  # iter-14 Stage-2a (no-op when 0)
        env      = wrapper.wrap_for_brax_training(env, episode_length=episode_length,
                                                  action_repeat=1)
    obs_dim  = env.observation_size
    act_dim  = env.action_size
    al, ah   = -1.0, 1.0
    print(f"  obs={obs_dim}  act={act_dim}", flush=True)

    # ── Networks
    # iter-16: latent_norm swaps SimNorm for FSQ discrete codes (vanilla tdmpc2
    # path only — the Glass module keeps its own SimNorm Encoder/Dynamics).
    _latent_norm = str(latent_norm or "simnorm")
    _dyn_arch = str(dyn_arch or "mlp")
    if _dyn_arch not in ("mlp", "attn", "resmlp"):
        raise ValueError(f"--dyn_arch must be mlp|attn|resmlp, got {_dyn_arch}")
    if _dyn_arch != "mlp":
        if use_glass:
            raise ValueError("--dyn_arch attn/resmlp is only supported on the vanilla tdmpc2 path")
        print(f"  iter-27 dyn_arch={_dyn_arch} (backbone swap for enc/dyn/jumpy; SimNorm geometry kept)", flush=True)
    if _latent_norm != "simnorm":
        if use_glass:
            raise ValueError("--latent_norm fsq is only supported on the vanilla tdmpc2 path")
        _fsq_levels = int(fsq_levels)
        print(f"  iter-16 latent_norm={_latent_norm} (FSQ levels={_fsq_levels}, SimNorm replaced)", flush=True)
        enc_net = Encoder(latent_dim=latent_dim, hidden=hidden, V=V, latent_norm=_latent_norm, fsq_levels=_fsq_levels, arch=_dyn_arch)
        dyn_net = Dynamics(latent_dim=latent_dim, hidden=hidden, V=V, latent_norm=_latent_norm, fsq_levels=_fsq_levels, arch=_dyn_arch)
    elif use_glass:
        # Glass path uses tdmpc_glass.Encoder/Dynamics which have no `arch` kwarg
        # (the iter-27 dyn_arch A/B is tdmpc2-only). Do NOT pass arch here.
        enc_net = Encoder(latent_dim=latent_dim, hidden=hidden, V=V)
        dyn_net = Dynamics(latent_dim=latent_dim, hidden=hidden, V=V)
    else:
        enc_net = Encoder(latent_dim=latent_dim, hidden=hidden, V=V, arch=_dyn_arch)
        dyn_net = Dynamics(latent_dim=latent_dim, hidden=hidden, V=V, arch=_dyn_arch)
    rew_net = RewardHead(hidden=hidden, num_bins=num_bins)
    q_net   = QEnsemble(hidden=hidden, num_bins=num_bins)
    pi_net  = Pi(action_dim=act_dim, hidden=hidden)

    key = jax.random.PRNGKey(seed)
    key, ek, dk, rk, qk, pk, gk = jax.random.split(key, 7)
    dummy_obs  = jnp.zeros((1, obs_dim))
    dummy_z    = jnp.zeros((1, latent_dim))
    dummy_act  = jnp.zeros((1, act_dim))
    # Path 7 / Phase-v: when use_cluster_obs is on, pi/q first layer is sized
    # for (latent_dim + num_clusters). Init with augmented dummy.
    _use_cluster_obs = bool(use_glass and glass_cfg.get("use_cluster_obs", False))
    if _use_cluster_obs:
        _K = int(glass_cfg.get("num_clusters", 8))
        dummy_z_aug = jnp.zeros((1, latent_dim + _K))
        print(f"  Cluster-id policy observation active: pi/q first layer in_dim={latent_dim}+{_K}={latent_dim + _K}", flush=True)
    else:
        dummy_z_aug = dummy_z
    params = {
        "enc": enc_net.init(ek, dummy_obs),
        "dyn": dyn_net.init(dk, dummy_z, dummy_act),
        "rew": rew_net.init(rk, dummy_z, dummy_act),
        "q":   q_net.init(qk, dummy_z_aug, dummy_act),
        "pi":  pi_net.init(pk, dummy_z_aug),
    }
    # ── A2 novelty-MPPI (Plan2Explore-in-TD-MPC2): novelty term in the MPPI objective.
    # RND = trained predictor error over the SimNorm latent; disagreement = 2-Q-head spread.
    _nov_beta = float(os.environ.get("NOVELTY_BETA", "0.0"))
    _nov_type = os.environ.get("NOVELTY_TYPE", "rnd").strip()
    _rnd_net = None; _rnd_tgt_params = None; _rnd_coef = 0.0
    _novelty_active = (not use_glass) and _nov_beta > 0.0
    if _novelty_active and _nov_type == "rnd":
        from helios.algorithms.tdmpc2 import RNDNet
        _rnd_dim = int(os.environ.get("RND_DIM", "64"))
        _rnd_hidden = tuple(int(x) for x in os.environ.get("RND_HIDDEN", "256").split(","))
        _rnd_coef = float(os.environ.get("RND_COEF", "1.0"))
        _rnd_net = RNDNet(hidden=_rnd_hidden, out=_rnd_dim)
        key, _rtk, _rpk = jax.random.split(key, 3)
        _rnd_tgt_params = _rnd_net.init(_rtk, dummy_z)
        params["rnd_prd"] = _rnd_net.init(_rpk, dummy_z)
        print(f"  [A2-NOVELTY] rnd novelty-MPPI beta={_nov_beta} rnd_dim={_rnd_dim} hidden={_rnd_hidden} coef={_rnd_coef}", flush=True)
    elif _novelty_active:
        print(f"  [A2-NOVELTY] {_nov_type} novelty-MPPI beta={_nov_beta} (no extra params)", flush=True)
    # iter-15 proto-plan: distilled prototype-space planner (eval-only probe).
    _proto_plan = bool(use_glass and glass_cfg.get("proto_plan", False))
    if _proto_plan:
        if not float(glass_cfg.get("lambda_behav") or 0.0) > 0.0:
            raise ValueError("--proto_plan requires --glass_lambda_behav > 0 (needs proto_reward)")
        if _use_cluster_obs:
            raise ValueError("--proto_plan is incompatible with use_cluster_obs")
        print("  iter-15 proto-plan active: distilled pdyn/proto_value heads + protomppi eval", flush=True)
    if use_glass:
        params["glass"] = init_glass_params(
            gk,
            latent_dim=latent_dim,
            num_prototypes=glass_cfg.get("num_prototypes", 32),
            num_clusters=glass_cfg.get("num_clusters", 8),
            assign_logits_init_scale=glass_cfg.get("assign_logits_init_scale", 1.0),
            num_super_clusters=glass_cfg.get("num_super_clusters", 0),
            behavioral=bool(glass_cfg.get("lambda_behav") or 0.0),
            proto_plan=_proto_plan,
            act_dim=act_dim if _proto_plan else 0,
        )
    # iter-22 jumpy: k-step latent head (vanilla tdmpc2 path only). Added to params so the
    # shared optimizer trains it; no-op when jumpy_k==0.
    _jumpy_k = int(jumpy_k) if (not use_glass) else 0
    _jumpy_plan = bool(jumpy_plan and _jumpy_k > 0)
    _jumpy_n_macro = int(jumpy_n_macro)
    jumpy_net = None; jumpy_rew_net = None
    if _jumpy_k > 0:
        jumpy_net = JumpyDynamics(latent_dim=latent_dim, hidden=hidden, V=V, arch=_dyn_arch)
        jumpy_rew_net = JumpyReward(hidden=hidden, num_bins=num_bins)
        key, jk, jk2 = jax.random.split(key, 3)
        _adummy = jnp.zeros((1, _jumpy_k * act_dim))
        params["jdyn"] = jumpy_net.init(jk, dummy_z, _adummy)
        params["jrew"] = jumpy_rew_net.init(jk2, dummy_z, _adummy)
        print(f"  iter-22 JUMPY k={_jumpy_k} coef={jumpy_coef} plan={_jumpy_plan} n_macro={_jumpy_n_macro}: "
              f"k-step dyn+reward heads + horizon-consistency (mechanism: jumpy_err vs iter1_err at eval)", flush=True)
        if float(calib_coef) > 0.0:
            print(f"  iter-30 CALIB coef={float(calib_coef)} q={float(calib_q)}: pinball-shape jumpy "
                  f"disagreement d=||jdyn-iter1step|| to the q-quantile upper bound of true k-step err", flush=True)
    elif float(calib_coef) > 0.0:
        print(f"  WARNING: --calib_coef={float(calib_coef)} ignored — requires --jumpy_k>0 (vanilla tdmpc2 path)",
              flush=True)
    tp    = params.copy()
    # [shrink-study] param count: sum of leaf sizes across the trainable model
    import jax as _jax_pc, numpy as _np_pc
    _pc = int(sum(_np_pc.prod(l.shape) for l in _jax_pc.tree_util.tree_leaves(params)))
    print(f"  [PARAM-COUNT] total_trainable_params={_pc:,} ({_pc/1e6:.3f}M) latent_dim={latent_dim} hidden={hidden} num_bins={num_bins} V={V}", flush=True)
    scale = jnp.array(1.0)
    glass_step = jnp.array(0, dtype=jnp.int32)

    # ── Optimizer (single shared chain so clip_by_global_norm sees the same
    #  parameter set as baseline TD-MPC2; with stopgrad on the Glass graph the
    #  glass subtree contributes negligible gradient norm).
    tx = optax.chain(
        optax.clip_by_global_norm(20.0),
        optax.adam(lr),
    )
    opt = tx.init(params)
    resume_env_steps = 0
    resume_best_mppi = -float("inf")
    resume_best_mppi_step = 0
    resume_payload = None
    if resume_checkpoint:
        with open(resume_checkpoint, "rb") as rf:
            resume_payload = pickle.load(rf)
        params = resume_payload["params"]
        tp = resume_payload.get("target_params", params)
        opt = resume_payload.get("opt_state", opt)
        scale = jnp.asarray(resume_payload.get("scale", scale))
        glass_step = jnp.asarray(resume_payload.get("glass_step", glass_step))
        resume_env_steps = int(resume_payload.get("env_steps", 0))
        resume_best_mppi = float(
            resume_payload.get("best_mppi", resume_payload.get("mppi_reward", -float("inf")))
        )
        resume_best_mppi_step = int(resume_payload.get("best_mppi_step", resume_env_steps))
        print(
            f"  Resumed model checkpoint {resume_checkpoint} "
            f"at env_steps={resume_env_steps:,}",
            flush=True,
        )

    # ── Library update functions
    _consistency_coef = float(consistency_coef) if consistency_coef is not None else float(d.get("consistency_coef", 2.0))
    _smooth_target = float(latent_action_smooth_coef)
    _smooth_warmup = int(latent_smooth_warmup_env_steps)
    _curriculum_active = _smooth_warmup > 0 and _smooth_target > 0
    _smooth_curr = 0.0 if _curriculum_active else _smooth_target
    _mpc_distill_target_coef = max(float(mpc_distill_coef), 0.0)
    _mpc_distill_anneal_steps = max(int(mpc_distill_anneal_steps), 1)
    _mpc_distill_disable_gap = float(mpc_distill_disable_gap)
    _mpc_distill_batch_size = max(int(mpc_distill_batch_size), 1)
    _mpc_distill_enabled = (not use_glass) and _mpc_distill_target_coef > 0
    if _smooth_target > 0 or _consistency_coef != 2.0:
        if _curriculum_active:
            print(f"  loss-coef: consistency={_consistency_coef} latent_action_smooth={_smooth_target} CURRICULUM "
                  f"(0 until {_smooth_warmup:,} env-steps, then ramp to target)", flush=True)
        else:
            print(f"  loss-coef overrides: consistency={_consistency_coef} latent_action_smooth={_smooth_target}", flush=True)
    if _mpc_distill_enabled:
        print(
            f"  Phase-mpc-lite active: coef={_mpc_distill_target_coef:.3f} "
            f"anneal_steps={_mpc_distill_anneal_steps:,} disable_gap={_mpc_distill_disable_gap:.1f} "
            f"anchor_batch={_mpc_distill_batch_size}",
            flush=True,
        )

    def _build_multi_step(smooth_coef: float):
        # smoothing_enabled controls whether the vmap-over-pi smoothing forward
        # pass is in the JIT graph at all. When False, the compiled graph
        # matches the pre-smoothing (Phase 1b) version exactly — basin choice
        # is then unperturbed (Phase-m fix for K=3-flip on seeds 4, 5).
        smoothing_enabled = smooth_coef > 0
        if use_glass:
            _, ms = make_update_fn(
                enc_net, dyn_net, rew_net, q_net, pi_net, tx,
                gamma=gamma, rho=rho, tau=tau, rew_scale=rew_scale,
                glass_enabled=glass_cfg.get("enabled", True),
                glass_every_k_updates=glass_cfg.get("every_k_updates", 4),
                glass_proto_temperature=glass_cfg.get("proto_temperature", 1.0),
                glass_assignment_temperature=glass_cfg.get("assignment_temperature", 1.0),
                glass_lambda_se=glass_cfg.get("lambda_se", 5.0e-3),
                glass_lambda_balance=glass_cfg.get("lambda_balance", 1.0e-2),
                glass_lambda_temporal=glass_cfg.get("lambda_temporal", 1.0e-3),
                glass_lambda_temp_stability=float(glass_cfg.get("lambda_temp_stability") or 0.0),
                glass_stopgrad_graph=glass_cfg.get("stopgrad_graph", True),
                glass_use_cosine_assign=glass_cfg.get("use_cosine_assign", True),
                latent_action_smooth_coef=smooth_coef,
                consistency_coef=_consistency_coef,
                smoothing_enabled=smoothing_enabled,
                glass_lambda_super_se=float(glass_cfg.get("lambda_super_se") or 0.0),
                glass_lambda_super_balance=float(glass_cfg.get("lambda_super_balance") or 0.0),
                glass_lambda_behav=float(glass_cfg.get("lambda_behav") or 0.0),
                use_cluster_obs=bool(glass_cfg.get("use_cluster_obs", False)),
                cluster_obs_proto_temperature=float(glass_cfg.get("proto_temperature", 1.0)),
                glass_proto_plan=_proto_plan,
            )
        else:
            _, ms = make_update_fn(
                enc_net, dyn_net, rew_net, q_net, pi_net, tx,
                gamma=gamma, rho=rho, tau=tau, rew_scale=rew_scale,
                latent_action_smooth_coef=smooth_coef,
                consistency_coef=_consistency_coef,
                smoothing_enabled=smoothing_enabled,
                mpc_distill_enabled=_mpc_distill_enabled,
                bisim_coef=bisim_coef,
                jumpy_net=jumpy_net,
                jumpy_rew_net=jumpy_rew_net,
                jumpy_k=_jumpy_k,
                jumpy_coef=float(jumpy_coef),
                jumpy_ve_coef=float(jumpy_ve_coef),
                calib_coef=float(calib_coef),
                calib_q=float(calib_q),
                rnd_net=_rnd_net,
                rnd_tgt_params=_rnd_tgt_params,
                rnd_coef=_rnd_coef,
            )
        return ms

    multi_step = _build_multi_step(_smooth_curr)

    # ── MPPI planner (for eval)
    # Build MPPI planner. Path-7 cluster_obs kwargs only valid for Glass make_mppi_fn,
    # so only pass them when use_glass=True (vanilla tdmpc2 make_mppi_fn doesn't accept them).
    _mppi_kw = {}
    if use_glass:
        _mppi_kw["use_cluster_obs"] = bool(glass_cfg.get("use_cluster_obs", False))
        _mppi_kw["cluster_obs_proto_temperature"] = float(glass_cfg.get("proto_temperature", 1.0))
    elif _novelty_active:
        _mppi_kw["rnd_net"] = _rnd_net
        _mppi_kw["rnd_tgt_params"] = _rnd_tgt_params
        _mppi_kw["novelty_beta"] = _nov_beta
        _mppi_kw["novelty_type"] = _nov_type
    plan = make_mppi_fn(
        enc_net, dyn_net, rew_net, q_net, pi_net,
        horizon=H, n_samples=NS, num_elites=elites,
        num_pi_trajs=pi_trajs, n_iter=NI,
        min_std=MIN_STD, max_std=MAX_STD,
        act_low=al, act_high=ah, act_dim=act_dim,
        gamma=gamma, rew_scale=rew_scale,
        **_mppi_kw,
    )
    plan_jumpy = None
    if _jumpy_plan:
        plan_jumpy = make_jumpy_mppi_fn(
            enc_net, jumpy_net, jumpy_rew_net, q_net, pi_net,
            k=_jumpy_k, n_macro=_jumpy_n_macro, n_samples=NS, num_elites=elites,
            n_iter=NI, min_std=MIN_STD, max_std=MAX_STD,
            act_low=al, act_high=ah, act_dim=act_dim, gamma=gamma,
        )
    plan_proto = None
    if _proto_plan:
        plan_proto = make_proto_mppi_fn(
            enc_net, dyn_net, pi_net,
            horizon=H, n_samples=NS, num_elites=elites,
            num_pi_trajs=pi_trajs, n_iter=NI,
            min_std=MIN_STD, max_std=MAX_STD,
            act_low=al, act_high=ah, act_dim=act_dim,
            gamma=gamma,
            proto_temperature=float(glass_cfg.get("proto_temperature", 1.0)),
        )
    if use_glass:
        glass_diag = make_glass_diag_fn(
            enc_net,
            dyn_net,
            proto_temperature=glass_cfg.get("proto_temperature", 1.0),
            assignment_temperature=glass_cfg.get("assignment_temperature", 1.0),
            stopgrad_graph=glass_cfg.get("stopgrad_graph", True),
            use_cosine_assign=glass_cfg.get("use_cosine_assign", True),
        )
        diag_dir = EXP_DIR / "glass_diag" / f"{env_id}{('_' + os.environ.get('TDMPC_GLASS_OUTPUT_TAG','').strip()) if os.environ.get('TDMPC_GLASS_OUTPUT_TAG','').strip() else ''}" / f"seed_{seed}"
        diag_dir.mkdir(parents=True, exist_ok=True)

    # ── Vectorised action function (pi + noise, used during data collection)
    _proto_T = float(glass_cfg.get("proto_temperature", 1.0))
    @jax.jit
    def act_fn_batch(p, obs):
        from helios.algorithms.tdmpc_glass import augment_z_with_cluster as _aug
        z = enc_net.apply(p["enc"], obs)
        z_in = _aug(z, p["glass"], _proto_T) if _use_cluster_obs else z
        mu, _ = pi_net.apply(p["pi"], z_in)
        return jnp.tanh(mu)
    _mpc_mu0 = jnp.zeros((H, act_dim))
    _mpc_std0 = jnp.full((H, act_dim), MAX_STD)
    @jax.jit
    def batch_mppi_targets(p, obs_batch, plan_key):
        keys = jax.random.split(plan_key, obs_batch.shape[0])
        mu_b = jnp.broadcast_to(_mpc_mu0, (obs_batch.shape[0], H, act_dim))
        std_b = jnp.broadcast_to(_mpc_std0, (obs_batch.shape[0], H, act_dim))
        def _one(obs_i, mu_i, std_i, key_i):
            act_i, _, _ = plan(p, obs_i, mu_i, std_i, key_i, jnp.bool_(True))
            return act_i
        return jax.vmap(_one)(obs_batch, mu_b, std_b, keys)

    # ── Buffer (numpy, per-env ring buffer)
    buf  = MultiEnvBuffer(buf_cap, N_ENVS, obs_dim, act_dim, seq_len)

    # ── DEMO-SEEDED replay (exp #3, additive; no-op unless TDMPC_DEMO_NPZ set).
    # Loads SUCCESSFUL demonstration episodes (box_target>=0.9) into a second
    # MultiEnvBuffer — one episode per "env" slot — so sample_k draws contiguous
    # demo subsequences of length seq_len. A fixed fraction TDMPC_DEMO_FRAC of each
    # K-block batch is then sampled from demos (see the sample_k site), letting
    # planning + value learning see real pick trajectories from step 0. This guards
    # planning against the dense-shaping hover local-optimum (Part-22 Rule D).
    demo_buf = None
    _demo_frac = 0.0
    _demo_npz = os.environ.get("TDMPC_DEMO_NPZ", "").strip()
    if _demo_npz:
        _dz = np.load(_demo_npz)
        d_obs, d_act, d_rew, d_done = _dz["obs"], _dz["acts"], _dz["rews"], _dz["done"]
        E, L = d_obs.shape[0], d_obs.shape[1]
        assert d_obs.shape[2] == obs_dim, f"demo obs_dim {d_obs.shape[2]} != env {obs_dim}"
        assert d_act.shape[2] == act_dim, f"demo act_dim {d_act.shape[2]} != env {act_dim}"
        # one episode per env-slot; cap=L so each slot holds the full episode.
        demo_buf = MultiEnvBuffer(L, E, obs_dim, act_dim, seq_len)
        demo_buf.obs[:]  = d_obs.astype(np.float32)
        demo_buf.acts[:] = d_act.astype(np.float32)
        demo_buf.rews[:] = d_rew.astype(np.float32)
        demo_buf.done[:] = d_done.astype(np.float32)
        demo_buf.ptr[:]  = 0
        demo_buf.size[:] = L
        _demo_frac = float(os.environ.get("TDMPC_DEMO_FRAC", "0.25"))
        print(f"  [DEMO-SEED] loaded {E} successful demo episodes (L={L}, "
              f"{E*(L-1):,} transitions) from {_demo_npz}; mix frac={_demo_frac} "
              f"of each K-block batch", flush=True)
    rng_np = np.random.default_rng(seed)
    np.random.seed(seed)
    if resume_payload and "replay_buffer" in resume_payload:
        restore_buffer_state(buf, resume_payload["replay_buffer"])
        print(f"  Restored replay buffer. Buffer={buf.total_size()}", flush=True)
    if resume_payload and "rng_np_state" in resume_payload:
        rng_np.bit_generator.state = resume_payload["rng_np_state"]
    if resume_payload and "np_random_state" in resume_payload:
        np.random.set_state(resume_payload["np_random_state"])

    # ── Vectorised env reset/step
    if _is_ogbench:
        def batch_step(state, acts):
            return env.step(state, np.asarray(acts))
    else:
        @jax.jit
        def batch_step(state, acts):
            return env.step(state, acts)

    # Path 5 / Phase-t — knee penalty fn. Computes per-env penalty based on
    # how far below threshold any non-foot geom z drops. Geom IDs (HopperHop):
    # 0=floor, 1=torso, 2=nose, 3=pelvis, 4=thigh, 5=calf, 6=foot.
    # Penalty target: sum over geoms 1..5 of max(0, threshold - z).
    # Returns shape (N_ENVS,) — subtracted from training reward only.
    _knee_pen_thr = float(knee_penalty_threshold)
    _knee_pen_coef = float(knee_penalty_coef)
    @jax.jit
    def knee_penalty_fn(state):
        # state.data.geom_xpos shape: (batch, num_geoms, 3)
        non_foot_z = state.data.geom_xpos[..., 1:6, 2]  # (batch, 5)
        per_geom = jnp.maximum(_knee_pen_thr - non_foot_z, 0.0)
        return jnp.sum(per_geom, axis=-1)  # (batch,)
    if _knee_pen_coef > 0:
        print(f"  Knee penalty active: coef={_knee_pen_coef} threshold={_knee_pen_thr}", flush=True)

    # iter-6 §7.C — Phase-r2 gait penalty + iter-6 §7.B — Phase-r1 soft-reward bundle.
    # Both shape the training reward only; eval reward stays the original task reward.
    # Height = torso_z - foot_z, computed off the inner Hopper env's body ids
    # (wrappers forward attribute access to the inner env).
    _gait_fall_coef = float(gait_fall_penalty)
    _gait_fall_h = float(gait_fall_height)
    _gait_smooth_coef = float(gait_action_smooth)
    _soft_bonus = float(soft_stand_bonus)
    _soft_floor = float(soft_stand_floor)
    _soft_anneal = int(soft_anneal_steps)
    _need_height = (_gait_fall_coef > 0 or _soft_bonus > 0)
    _torso_id = getattr(env, "_torso_id", None)
    _foot_id = getattr(env, "_foot_id", None)
    if _need_height and (_torso_id is None or _foot_id is None):
        print(f"  [warn] gait/soft-reward needs _torso_id/_foot_id from env; got "
              f"torso={_torso_id} foot={_foot_id}, disabling", flush=True)
        _gait_fall_coef = 0.0
        _soft_bonus = 0.0
        _need_height = False
    @jax.jit
    def _height_per_env(state):
        if _torso_id is None or _foot_id is None:
            return jnp.zeros(state.data.xipos.shape[0])
        return state.data.xipos[..., _torso_id, 2] - state.data.xipos[..., _foot_id, 2]
    if _gait_fall_coef > 0 or _gait_smooth_coef > 0:
        print(f"  Phase-r2 gait penalty active: fall_coef={_gait_fall_coef} h<{_gait_fall_h} "
              f"action_smooth={_gait_smooth_coef}", flush=True)
    if _soft_bonus > 0:
        print(f"  Phase-r1 soft-reward bundle: stand_bonus={_soft_bonus} floor={_soft_floor} "
              f"anneal_steps={_soft_anneal} (linear fade 1->0)", flush=True)
    _prev_acts = None  # populated on first step

    # Path P / Phase-P — cluster-entropy intrinsic reward (benchmark-fair).
    # Compute current Glass cluster id per env, maintain ring buffer of last W,
    # add coef * entropy(window) to training reward. Encourages gait diversity
    # via Glass partition without modifying the env.
    _cluster_coef_init = float(cluster_intrinsic_coef)
    _cluster_window = int(cluster_intrinsic_window)
    _cluster_decay_steps = int(cluster_intrinsic_decay_steps)
    _cluster_decay_start = int(expl_until) if expl_until is not None else 0
    _cluster_active = use_glass and _cluster_coef_init > 0
    if _cluster_active:
        if _cluster_decay_steps > 0:
            print(f"  Cluster-entropy intrinsic reward active: coef={_cluster_coef_init} window={_cluster_window} "
                  f"linear-decay [{_cluster_decay_start:,} -> {_cluster_decay_steps:,}] env-steps", flush=True)
        else:
            print(f"  Cluster-entropy intrinsic reward active: coef={_cluster_coef_init} window={_cluster_window} (static)", flush=True)
        _glass_K = int(glass_cfg.get("num_clusters", 8))
        # per-env ring buffer of cluster ids (np for cheap host-side updates)
        _cluster_history = np.zeros((N_ENVS, _cluster_window), dtype=np.int32)
        _cluster_history_ptr = 0  # ring buffer write index, shared across envs

        @jax.jit
        def cluster_id_batch(params, obs_batch):
            """Compute argmax(S[argmax(z·μᵀ)]) per env."""
            z = enc_net.apply(params["enc"], obs_batch)  # (N_ENVS, latent_dim)
            mu = params["glass"]["prototypes"]
            zn = z / (jnp.linalg.norm(z, axis=-1, keepdims=True) + 1e-8)
            mn = mu / (jnp.linalg.norm(mu, axis=-1, keepdims=True) + 1e-8)
            sim = (zn @ mn.T) / glass_cfg.get("proto_temperature", 1.0)   # (N_ENVS, N_proto)
            n_star = jnp.argmax(sim, axis=-1)                              # (N_ENVS,)
            S = jax.nn.softmax(params["glass"]["assign_logits"], axis=-1)
            return jnp.argmax(S[n_star], axis=-1)                          # (N_ENVS,)

        def cluster_entropy_per_env(history):
            """Shannon entropy of cluster-id distribution per env. history: (N_ENVS, W)."""
            ent = np.zeros(history.shape[0], dtype=np.float32)
            for env_i in range(history.shape[0]):
                _, counts = np.unique(history[env_i], return_counts=True)
                p = counts / history.shape[1]
                ent[env_i] = -np.sum(p * np.log(np.clip(p, 1e-8, 1.0)))
            return ent

    # iter-17 — prototype-visit-count novelty bonus (exploration THROUGH the
    # abstraction). Distinct from falsified Path P/Pa (within-window cluster
    # entropy on HopperHop): count-based novelty, targeted at exploration-bound
    # sparse tasks where iter-14 §4.4 located the 0-vs-solved bimodality.
    # Training reward only; eval untouched. bonus_i = coef * N[proto_i]^-1/2.
    _pnov_coef_init = float(proto_novelty_coef)
    _pnov_decay_steps = int(proto_novelty_decay_steps)
    _pnov_active = use_glass and _pnov_coef_init > 0
    if _pnov_active:
        _P_protos = int(glass_cfg.get("num_prototypes", 32))
        _pnov_counts = np.ones(_P_protos, dtype=np.float64)  # start at 1: bounded bonus, no div0
        print(
            f"  iter-17 prototype-novelty bonus: coef={_pnov_coef_init} "
            f"decay_steps={_pnov_decay_steps:,} P={_P_protos}",
            flush=True,
        )

        @jax.jit
        def proto_id_batch(p, obs_batch):
            z = enc_net.apply(p["enc"], obs_batch)
            mu = p["glass"]["prototypes"]
            zn = z / (jnp.linalg.norm(z, axis=-1, keepdims=True) + 1e-8)
            mn = mu / (jnp.linalg.norm(mu, axis=-1, keepdims=True) + 1e-8)
            return jnp.argmax(zn @ mn.T, axis=-1)  # (N_ENVS,)

    # iter-21 — abstraction-grounded exploration intrinsic reward (sparse-task rescue).
    _intr = str(intrinsic or "none").lower()
    _intr_coef = float(intrinsic_coef)
    _intr_state = None
    _ss_state = None
    if _intr != "none" and _intr_coef > 0:
        from helios.algorithms.intrinsic import (
            make_rnd, make_laplacian, make_se_explore, make_random_encoder)
        if _intr == "rnd":
            _intr_state = make_rnd(obs_dim, seed=seed)
        elif _intr == "laplacian":
            _intr_state = make_laplacian(obs_dim, seed=seed)
        elif _intr in ("vcse", "si2e"):
            # random-encoder feature; vcse = value-conditional kNN entropy only; si2e adds cluster term
            _re_D = 32
            _intr_state = make_se_explore(_re_D, use_cluster=(_intr == "si2e"), seed=seed)
            _intr_state["rand_enc"] = make_random_encoder(obs_dim, D=_re_D, seed=seed)
        elif _intr == "wmsi2e":
            # NOVEL: SI2E over the WORLD-MODEL latent (enc) + critic value (cluster term over WM latent)
            _intr_state = make_se_explore(latent_dim, use_cluster=True, seed=seed)
            _intr_state["rand_enc"] = None
        elif _intr == "se_subgoal":
            # Thread E / A3: SE COMMUNITY-DISCOVERY subgoal HL. selib min-2D structural
            # entropy partitions replay latents into communities; the HL steers each env
            # toward an under-visited community via potential-based goal-distance shaping
            # (LL = the existing TD-MPC2 policy/planner; optimizer + budget IDENTICAL to
            # flat). Not routed through _intr_state; applied in its own loop block below.
            from helios.algorithms.se_subgoal import SESubgoalHL
            _ss_state = SESubgoalHL(
                n_envs=N_ENVS, latent_dim=latent_dim, coef=_intr_coef,
                knn=int(os.environ.get("SS_KNN", "10")),
                max_comm=int(os.environ.get("SS_MAXC", "32")),
                rebuild_every=int(os.environ.get("SS_REBUILD", "50000")),
                reassign_every_env=int(os.environ.get("SS_REASSIGN", "64")),
                reach_frac=float(os.environ.get("SS_REACHF", "0.5")),
                top_m=int(os.environ.get("SS_TOPM", "8")), seed=seed)
            print(f"  [SE-subgoal] HL enabled coef={_intr_coef} knn={_ss_state.knn} "
                  f"max_comm={_ss_state.max_comm} rebuild_every={_ss_state.rebuild_every} "
                  f"reassign_every={_ss_state.reassign_every} (training-reward only)", flush=True)
        else:
            raise ValueError(f"unknown --intrinsic {intrinsic}")
        print(f"  iter-21 intrinsic exploration: {_intr} coef={_intr_coef} (training-reward only, "
              f"normalized; sparse-task rescue probe)", flush=True)

    key, ek2 = jax.random.split(key)
    if resume_payload and "env_state" in resume_payload and "obs_np" in resume_payload:
        env_state = resume_payload["env_state"]
        obs_np = resume_payload["obs_np"]
        print("  Restored vectorized environment state", flush=True)
    else:
        env_state = env.reset(jax.random.split(ek2, N_ENVS))
        obs_np    = np.array(env_state.obs)
    env_steps = resume_env_steps

    # ── Pi-based eval (deterministic, single episode at a time)
    @jax.jit
    def enc_apply(p, obs):
        return enc_net.apply(p["enc"], obs[None])

    @jax.jit
    def pi_apply(p, z):
        from helios.algorithms.tdmpc_glass import augment_z_with_cluster as _aug
        z_in = _aug(z, p["glass"], _proto_T) if _use_cluster_obs else z
        mu, _ = pi_net.apply(p["pi"], z_in)
        return jnp.tanh(mu[0])

    @jax.jit
    def lat_apply(p, obs):                 # iter-24: batched encoder (N,obs)->(N,latent) for wmsi2e feature
        return enc_net.apply(p["enc"], obs)

    @jax.jit
    def val_apply(p, obs):                 # iter-24: batched value V(s)=min-head two_hot_inv(Q(z,pi(z)))
        from helios.algorithms.tdmpc2 import two_hot_inv as _thi
        z = enc_net.apply(p["enc"], obs)
        mu, _ = pi_net.apply(p["pi"], z)
        q = q_net.apply(p["q"], z, jnp.tanh(mu))       # (N, 2, num_bins)
        return jnp.min(_thi(q, num_bins=num_bins), axis=-1)

    if _is_ogbench:
        # CPU gym env cannot be jit-traced; use a 1-env adapter for single-env eval.
        from ogbench_adapter import make_ogbench_env as _mk_og
        _eval_env = _mk_og(_ogbench_src.split("ogbench:", 1)[1], 1, seed=seed + 777)
        def single_env_step(state, act):
            return _eval_env.step(state, np.asarray(act)[None])
        def single_env_reset(key):
            return _eval_env.reset()
    else:
        @jax.jit
        def single_env_step(state, act):
            return env.step(state, act[None])

        @jax.jit
        def single_env_reset(key):
            return env.reset(jax.random.split(key, 1))

    # Iter 6 §7.1 — episode diagnostics from per-step reward signal.
    # full_reward (>0.5)   = standing AND fast (~target speed met)
    # standing_proxy(>0.01) = at least upright
    # fall_count            = transitions standing → fallen (proxy via reward crossing 0.01)
    # time_to_first_full    = first step where reward > 0.5 (or episode_length if never)
    # No internal env state access — env-agnostic, no extra device syncs.
    def _episode_diag(rewards_list):
        if not rewards_list:
            return {"full": 0.0, "stand": 0.0, "falls": 0, "ttf": episode_length}
        r = np.asarray(rewards_list, dtype=np.float32)
        full = (r > 0.5)
        stand = (r > 0.01)
        falls = int(np.sum(stand[:-1] & (~stand[1:]))) if len(stand) > 1 else 0
        ttf = int(np.argmax(full)) if full.any() else episode_length
        return {
            "full": float(full.mean()),
            "stand": float(stand.mean()),
            "falls": falls,
            "ttf": ttf,
        }

    def eval_pi(n_eps: int = 5):
        nonlocal key
        rets, diags = [], []
        _ph_codes = []   # PHASE-ENTROPY mechcheck: SimNorm argmax-codes of visited states
        _zs, _rtgs = [], []   # VALUE-SUFFICIENCY SIEVE: raw latents + return-to-go for linear value-decode R²
        _G, _V = 8, latent_dim // 8
        _disc = 0.99
        for _ in range(n_eps):
            key, rk2 = jax.random.split(key)
            state = single_env_reset(rk2)
            obs   = jnp.asarray(state.obs[0])
            er = 0.0
            ep_succ = 0.0
            ep_reached = 0.0
            ep_rew = []; _ep_z = []
            for _ in range(episode_length):
                z   = enc_apply(params, obs)
                _zn = np.asarray(z).reshape(-1)
                _ph_codes.append(_zn.reshape(_G, _V).argmax(-1)); _ep_z.append(_zn)
                act = pi_apply(params, z)
                state = single_env_step(state, act)
                r = float(state.reward[0])
                er += r
                if _is_ogbench:
                    ep_succ = max(ep_succ, float(np.asarray(state.info.get("success", 0.0)).reshape(-1)[0]))
                if _is_pickcube:
                    ep_succ = max(ep_succ, float(np.asarray(state.metrics["box_target"]).reshape(-1)[0]))
                    ep_reached = max(ep_reached, float(np.asarray(state.info["reached_box"]).reshape(-1)[0]))
                ep_rew.append(r)
                if bool(state.done[0] > 0.5):
                    break
                obs = jnp.asarray(state.obs[0])
            rets.append(er)
            _d = _episode_diag(ep_rew)
            if _is_ogbench:
                _d["success"] = ep_succ
            if _is_pickcube:
                _d["success"] = float(ep_succ >= _SUCC_THRESH)
                _d["box_target_max"] = ep_succ
                _d["reached"] = ep_reached
            diags.append(_d)
            # return-to-go per step (discounted), aligned with _ep_z
            _g = 0.0; _rtg = [0.0] * len(ep_rew)
            for _t in range(len(ep_rew) - 1, -1, -1):
                _g = ep_rew[_t] + _disc * _g; _rtg[_t] = _g
            n = min(len(_ep_z), len(_rtg)); _zs.extend(_ep_z[:n]); _rtgs.extend(_rtg[:n])
        # mean across episodes
        agg = {k: float(np.mean([d[k] for d in diags])) for k in diags[0]}
        # PHASE-ENTROPY: mean over the 8 SimNorm groups of the entropy of visited argmax-codes.
        _C = np.array(_ph_codes)
        _ents = []
        for _gi in range(_G):
            _, _cnt = np.unique(_C[:, _gi], return_counts=True); _p = _cnt / _cnt.sum()
            _ents.append(float(-(_p * np.log(_p)).sum()))
        agg["phase_entropy"] = float(np.mean(_ents))
        # unif_dmc: effective rank of the eval-visited latents (anti-collapse health).
        # eff_rank = exp(Shannon entropy of normalized covariance eigenvalues). Low => collapse.
        try:
            _Zr = np.asarray(_zs, np.float64)
            if _Zr.shape[0] >= 10:
                _Zc = _Zr - _Zr.mean(0, keepdims=True)
                _cov = (_Zc.T @ _Zc) / (_Zc.shape[0] - 1)
                _ev = np.linalg.eigvalsh(_cov)
                _ev = np.clip(_ev, 0.0, None)
                _tot = _ev.sum()
                if _tot > 1e-12:
                    _pp = _ev / _tot
                    _pp = _pp[_pp > 1e-12]
                    agg["eff_rank"] = float(np.exp(-(_pp * np.log(_pp)).sum()))
                else:
                    agg["eff_rank"] = float("nan")
            else:
                agg["eff_rank"] = float("nan")
        except Exception:
            agg["eff_rank"] = float("nan")
        # VALUE-SUFFICIENCY SIEVE: R² of a LINEAR probe latent -> return-to-go (does the latent linearly
        # encode value?). The redundancy criterion's core metric — track it over training and across tasks.
        # HELD-OUT test R² of a RIDGE linear probe latent -> return-to-go (does the latent
        # linearly encode value?). Ridge + per-dim standardization is essential: a plain lstsq
        # on the 512-d, highly-collinear SimNorm latent is ill-conditioned and gives wild/negative
        # held-out R² (the weights blow up). This is the redundancy criterion's core metric.
        try:
            _Z = np.asarray(_zs, np.float64); _y = np.asarray(_rtgs, np.float64)
            _n = len(_Z)
            if _n >= 100:
                _rng = np.random.default_rng(0)
                _idx = _rng.permutation(_n); _cut = int(_n * 0.8)
                _tr, _te = _idx[:_cut], _idx[_cut:]
                _Xtr, _Xte = _Z[_tr], _Z[_te]
                _ytr, _yte = _y[_tr], _y[_te]
                # standardize features on train
                _mu = _Xtr.mean(0); _sd = _Xtr.std(0) + 1e-6
                _Xtr = (_Xtr - _mu) / _sd; _Xte = (_Xte - _mu) / _sd
                _ym = _ytr.mean()
                _d = _Xtr.shape[1]
                _lam = 10.0  # ridge; stabilizes the collinear-latent solve
                _A = _Xtr.T @ _Xtr + _lam * np.eye(_d)
                _b = _Xtr.T @ (_ytr - _ym)
                _w = np.linalg.solve(_A, _b)
                _pred = _Xte @ _w + _ym
                _sr = float(((_yte - _pred) ** 2).sum()); _st = float(((_yte - _yte.mean()) ** 2).sum())
                agg["value_r2"] = float(1.0 - _sr / _st) if _st > 1e-8 else float("nan")
            else:
                agg["value_r2"] = float("nan")
        except Exception:
            agg["value_r2"] = float("nan")
        return float(np.mean(rets)), agg

    def eval_mppi(n_eps: int = 3):
        nonlocal key
        rets, diags = [], []
        for _ in range(n_eps):
            key, rk2 = jax.random.split(key)
            state = single_env_reset(rk2)
            obs = jnp.asarray(state.obs[0])
            mu = jnp.zeros((H, act_dim))
            std = jnp.full((H, act_dim), MAX_STD)
            er = 0.0
            ep_rew = []
            t0_mppi = jnp.bool_(True)
            ep_succ = 0.0
            ep_reached = 0.0
            key, pk2 = jax.random.split(key)
            for _ in range(episode_length):
                act, mu, std = plan(params, obs, mu, std, pk2, t0_mppi)
                t0_mppi = jnp.bool_(False)
                key, pk2 = jax.random.split(key)
                state = single_env_step(state, act)
                r = float(state.reward[0])
                er += r
                if _is_ogbench:
                    ep_succ = max(ep_succ, float(np.asarray(state.info.get("success", 0.0)).reshape(-1)[0]))
                if _is_pickcube:
                    ep_succ = max(ep_succ, float(np.asarray(state.metrics["box_target"]).reshape(-1)[0]))
                    ep_reached = max(ep_reached, float(np.asarray(state.info["reached_box"]).reshape(-1)[0]))
                ep_rew.append(r)
                if bool(state.done[0] > 0.5):
                    break
                obs = jnp.asarray(state.obs[0])
            rets.append(er)
            _d = _episode_diag(ep_rew)
            if _is_ogbench:
                _d["success"] = ep_succ
            if _is_pickcube:
                _d["success"] = float(ep_succ >= _SUCC_THRESH)
                _d["box_target_max"] = ep_succ
                _d["reached"] = ep_reached
            diags.append(_d)
        agg = {k: float(np.mean([d[k] for d in diags])) for k in diags[0]}
        return float(np.mean(rets)), agg

    def eval_jumpy(n_eps: int = 3):
        # iter-22: eval with jumpy-MPPI (plan n_macro macro-steps over the k-step jumpy model).
        nonlocal key
        rets, diags = [], []
        for _ in range(n_eps):
            key, rk2 = jax.random.split(key)
            state = single_env_reset(rk2)
            obs = jnp.asarray(state.obs[0])
            mu = jnp.zeros((_jumpy_n_macro, _jumpy_k, act_dim))
            std = jnp.full((_jumpy_n_macro, _jumpy_k, act_dim), MAX_STD)
            er = 0.0; ep_rew = []; t0_j = jnp.bool_(True)
            ep_succ = 0.0; ep_reached = 0.0
            key, pk2 = jax.random.split(key)
            for _ in range(episode_length):
                act, mu, std = plan_jumpy(params, obs, mu, std, pk2, t0_j)
                t0_j = jnp.bool_(False)
                key, pk2 = jax.random.split(key)
                state = single_env_step(state, act)
                r = float(state.reward[0]); er += r; ep_rew.append(r)
                if _is_pickcube:
                    ep_succ = max(ep_succ, float(np.asarray(state.metrics["box_target"]).reshape(-1)[0]))
                    ep_reached = max(ep_reached, float(np.asarray(state.info["reached_box"]).reshape(-1)[0]))
                if bool(state.done[0] > 0.5):
                    break
                obs = jnp.asarray(state.obs[0])
            rets.append(er)
            _dj = _episode_diag(ep_rew)
            if _is_pickcube:
                _dj["success"] = float(ep_succ >= _SUCC_THRESH)
                _dj["box_target_max"] = ep_succ
                _dj["reached"] = ep_reached
            diags.append(_dj)
        agg = {k: float(np.mean([d[k] for d in diags])) for k in diags[0]}
        return float(np.mean(rets)), agg

    def eval_protomppi(n_eps: int = 8):
        # iter-15: identical loop to eval_mppi but planning in prototype space.
        nonlocal key
        rets, diags = [], []
        for _ in range(n_eps):
            key, rk2 = jax.random.split(key)
            state = single_env_reset(rk2)
            obs = jnp.asarray(state.obs[0])
            mu = jnp.zeros((H, act_dim))
            std = jnp.full((H, act_dim), MAX_STD)
            er = 0.0
            ep_rew = []
            t0_mppi = jnp.bool_(True)
            key, pk2 = jax.random.split(key)
            for _ in range(episode_length):
                act, mu, std = plan_proto(params, obs, mu, std, pk2, t0_mppi)
                t0_mppi = jnp.bool_(False)
                key, pk2 = jax.random.split(key)
                state = single_env_step(state, act)
                r = float(state.reward[0])
                er += r
                ep_rew.append(r)
                if bool(state.done[0] > 0.5):
                    break
                obs = jnp.asarray(state.obs[0])
            rets.append(er)
            diags.append(_episode_diag(ep_rew))
        agg = {k: float(np.mean([d[k] for d in diags])) for k in diags[0]}
        return float(np.mean(rets)), agg

    eval_type_csv = None
    ckpt_dir = None
    best_mppi = resume_best_mppi
    best_mppi_step = resume_best_mppi_step
    # iter-8 §2.0 — Phase-eval: best-pi + best-any tracking. MPPI < pi in
    # ~17% of runs (mppi_vs_pi_analysis.md); preserve both.
    best_pi = -float("inf")
    best_pi_step = 0
    best_any = -float("inf")
    best_any_step = 0
    best_any_selector = ""  # "pi" or "mppi" — which evaluator picked best_any

    # iter-7 §2.1 — Phase-ar auto-restart on plateau tracker
    # The plateau check fires every restart_check_at env steps. If best_mppi is
    # still below restart_threshold at the check, re-init pi+q (keep encoder,
    # dynamics, reward, replay buffer, env state). Up to restart_max_attempts.
    _restart_count = 0
    _restart_next_check = int(restart_check_at) if restart_on_plateau else 0
    if restart_on_plateau:
        print(
            f"  Phase-ar plateau detector: check every {restart_check_at:,} env-steps; "
            f"reset pi+q if best MPPI < {restart_threshold:.0f}; max {restart_max_attempts} attempts.",
            flush=True,
        )
    _mpc_gap_allows_distill = True
    early_stop_triggered = False
    _patience = max(int(early_stop_patience), 0)
    if _patience > 0:
        print(f"  Early-stop: will halt after {_patience:,} env-steps with no new best MPPI", flush=True)
    _controller_arbitration = str(controller_arbitration or "none").lower()
    _arbitration_margin = float(arbitration_margin)
    if _controller_arbitration not in {"none", "eval_only"}:
        raise ValueError(f"Unknown controller_arbitration={controller_arbitration!r}")
    if _controller_arbitration == "eval_only":
        print(
            f"  Controller arbitration: eval_only, selecting MPPI only when "
            f"MPPI > pi + {_arbitration_margin:.1f}. Replay collection is unchanged.",
            flush=True,
        )
    # Optional output-tag suffix so we can run multiple experiment phases
    # (e.g. phase1 / phase2) against the same env_id without clobbering files.
    _tag = os.environ.get("TDMPC_GLASS_OUTPUT_TAG", "").strip()
    _env_dir = f"{env_id}{('_' + _tag) if _tag else ''}"
    if use_glass:
        eval_type_csv = (
            EXP_DIR.parent
            / "tdmpc_glass"
            / _env_dir
            / f"seed_{seed}.csv"
        )
        eval_type_csv.parent.mkdir(parents=True, exist_ok=True)
        if not eval_type_csv.exists():
            with open(eval_type_csv, "w") as cf:
                cf.write("step,reward,eval_type,seed\n")
    else:
        # iter 6 fix — vanilla tdmpc2 uses the same per-seed, tag-aware layout as Glass.
        # iter-14 fix (2026-06-05): was `elif env_id == "HopperHop"`, which meant vanilla
        # runs on ANY non-HopperHop DMC task (HumanoidWalk/WalkerRun/CheetahRun…) never
        # created an eval CSV → no learning curves on the dashboard. Now applies to all tasks.
        eval_type_csv = (
            EXP_DIR.parent
            / "tdmpc_glass"
            / _env_dir
            / f"seed_{seed}.csv"
        )
        eval_type_csv.parent.mkdir(parents=True, exist_ok=True)
        if not eval_type_csv.exists():
            with open(eval_type_csv, "w") as cf:
                cf.write("step,reward,eval_type,seed\n")

    if eval_type_csv is not None:
        ckpt_dir = eval_type_csv.parent / f"seed_{seed}" / "checkpoints"

    # ── Warmup JIT — compile multi_step with dummy data
    print("  Warming up JIT (may take 30-90s)...", flush=True)
    t_jit = time.time()
    _dummy_obs = np.zeros((K_UPDATE, BS, seq_len, obs_dim), np.float32)
    _dummy_act = np.zeros((K_UPDATE, BS, seq_len, act_dim), np.float32)
    _dummy_rew = np.zeros((K_UPDATE, BS, seq_len), np.float32)
    _dummy_don = np.zeros((K_UPDATE, BS, seq_len), np.float32)
    _dummy_mpc_obs = np.zeros((_mpc_distill_batch_size, obs_dim), np.float32)
    _dummy_mpc_act = np.zeros((_mpc_distill_batch_size, act_dim), np.float32)
    _dummy_mpc_coef = jnp.array(0.0, dtype=jnp.float32)
    if use_glass:
        params, tp, opt, key, scale, glass_step, _, _ = multi_step(
            params, tp, opt,
            jnp.asarray(_dummy_obs), jnp.asarray(_dummy_act),
            jnp.asarray(_dummy_rew), jnp.asarray(_dummy_don),
            key, scale, glass_step, False,
        )
    else:
        params, tp, opt, key, scale, _, _ = multi_step(
            params, tp, opt,
            jnp.asarray(_dummy_obs), jnp.asarray(_dummy_act),
            jnp.asarray(_dummy_rew), jnp.asarray(_dummy_don),
            key, scale,
            jnp.asarray(_dummy_mpc_obs), jnp.asarray(_dummy_mpc_act), _dummy_mpc_coef,
        )
    jax.block_until_ready(scale)
    print(f"  JIT compiled in {time.time()-t_jit:.1f}s", flush=True)
    if resume_checkpoint:
        with open(resume_checkpoint, "rb") as rf:
            ckpt = pickle.load(rf)
        params = ckpt["params"]
        tp = ckpt.get("target_params", params)
        opt = ckpt.get("opt_state", opt)
        scale = jnp.asarray(ckpt.get("scale", scale))
        glass_step = jnp.asarray(ckpt.get("glass_step", glass_step))
        key = jnp.asarray(ckpt.get("key", key))
        print("  Restored checkpoint state after JIT warmup", flush=True)

    # ── Training loop (Phase 4: vectorised buffer sample + lax.scan update)
    next_eval     = (
        ((env_steps // eval_interval) + 1) * eval_interval
        if env_steps
        else eval_interval
    )
    log_interval  = N_ENVS * 20   # log every 20 * N_ENVS steps
    t0 = time.time()
    loss_val = 0.0

    # iter-23 SE pre-check tier-2: dump real rollout latents for offline structural-entropy
    # analysis, then EXIT (no training). Gated by SE_DUMP=1; needs --resume_checkpoint. Uses the
    # pi policy (exists in every ckpt) — the SE structure question is about the ENCODER latent
    # geometry + transition graph, NOT the jumpy planner. Saves z_t / z_{t+k} pairs (k=SE_DUMP_K).
    if os.environ.get("SE_DUMP", "") == "1":
        import sys as _sys
        n_ep = int(os.environ.get("SE_DUMP_EPS", "12"))
        # mechcheck mode: if the jumpy model is built (--jumpy_k k matching the ckpt), also record
        # the per-step TRUE k-step prediction error e_t = ||jdyn(z_t, a_{t:t+k}) - z_{t+k}||, so we
        # can test offline whether SE community-boundary score b(z_t) correlates with e_t (the SE-k
        # kill-test). kk is then forced to the model's k. Else fall back to latent-only dump.
        _mech = (jumpy_net is not None and _jumpy_k > 0)
        kk = int(_jumpy_k) if _mech else int(os.environ.get("SE_DUMP_K", "4"))
        # F salvage-test: also measure (1) TRUE k-step error on pi action, (2) ensemble-free
        # disagreement = ||jumpy_pred - iterated_1step_pred|| at the pi action (validate vs true err),
        # (3) the same disagreement under M MPPI-perturbed action seqs (mean/max per state) -> does
        # OOD perturbation create high-variance "hard" regions an adaptive horizon could gate on?
        _M = int(os.environ.get("SE_DUMP_PERTURB", "6")); _pstd = float(os.environ.get("SE_DUMP_PSTD", "0.5"))
        _rng = np.random.default_rng(0)
        Zall, Zt, Ztk, Err, Disc, DiscPmean, DiscPmax = [], [], [], [], [], [], []
        def _iter1(zb, a_seq_b):           # zb (B,latent), a_seq_b (B,kk,adim) -> (B,latent)
            z = zb
            for _j in range(kk):
                z = dyn_net.apply(params["dyn"], z, a_seq_b[:, _j, :])
            return z
        for _ep in range(n_ep):
            key, rk2 = jax.random.split(key)
            state = single_env_reset(rk2)
            obs = jnp.asarray(state.obs[0])
            zseq, aseq = [], []
            for _t in range(episode_length):
                z = enc_apply(params, obs)
                zseq.append(np.asarray(z).reshape(-1))
                act = pi_apply(params, z)
                aseq.append(np.asarray(act).reshape(-1))
                state = single_env_step(state, act)
                if bool(state.done[0] > 0.5):
                    break
                obs = jnp.asarray(state.obs[0])
            zseq = np.stack(zseq); aseq = np.stack(aseq)   # (T,latent),(T,adim)
            Zall.append(zseq)
            if len(zseq) > kk:
                Zt.append(zseq[:-kk]); Ztk.append(zseq[kk:])
                if _mech:
                    for t in range(len(zseq) - kk):
                        zt = jnp.asarray(zseq[t].reshape(1, -1))
                        a_pi = aseq[t:t + kk]                                  # (kk,adim)
                        jp = jumpy_net.apply(params["jdyn"], zt, jnp.asarray(a_pi.reshape(1, -1)))
                        Err.append(float(np.sqrt(((np.asarray(jp).reshape(-1) - zseq[t + kk]) ** 2).sum())))
                        ip = _iter1(zt, jnp.asarray(a_pi[None]))
                        Disc.append(float(np.sqrt(((np.asarray(jp - ip).reshape(-1)) ** 2).sum())))
                        noise = (_rng.normal(size=(_M, kk, act_dim)).astype("float32") * _pstd)
                        a_m = np.clip(a_pi[None] + noise, -1.0, 1.0)           # (M,kk,adim)
                        zt_m = jnp.repeat(zt, _M, axis=0)
                        jp_m = jumpy_net.apply(params["jdyn"], zt_m, jnp.asarray(a_m.reshape(_M, -1)))
                        ip_m = _iter1(zt_m, jnp.asarray(a_m))
                        dm = np.sqrt(((np.asarray(jp_m - ip_m)) ** 2).sum(-1))  # (M,)
                        DiscPmean.append(float(dm.mean())); DiscPmax.append(float(dm.max()))
        Zall = np.concatenate(Zall, 0); Zt = np.concatenate(Zt, 0); Ztk = np.concatenate(Ztk, 0)
        arr = lambda L: np.array(L, np.float32) if L else np.zeros(0, np.float32)
        _tag = os.environ.get("TDMPC_GLASS_OUTPUT_TAG", "se_dump")
        outdir = Path(__file__).resolve().parents[1] / "exp" / "tdmpc_glass" / "se_dump"
        outdir.mkdir(parents=True, exist_ok=True)
        outp = outdir / f"{_tag}_seed{seed}_k{kk}{'_mech' if _mech else ''}.npz"
        np.savez_compressed(outp, Z=Zall.astype(np.float16), Zt=Zt.astype(np.float16),
                            Ztk=Ztk.astype(np.float16), err=arr(Err), disc=arr(Disc),
                            discp_mean=arr(DiscPmean), discp_max=arr(DiscPmax), k=kk, env=str(env_id))
        print(f"  [SE_DUMP] saved {Zall.shape[0]} latents ({n_ep} eps, k={kk}, mech={_mech}, "
              f"errs={len(Err)}, perturb M={_M} pstd={_pstd}) -> {outp}", flush=True)
        _sys.exit(0)

    # iter-25 Hermite-spline mechanism-check (env-gated HERMITE_CHECK=1; needs --resume_checkpoint).
    # KILL-TEST: can a few-control-point cubic-Hermite spline express the policy's action trajectory
    # without losing return? Records pi-rollout actions, fits K-knot Hermite, replays smoothed actions
    # open-loop from the SAME init, reports R^2 + return-preservation. Then EXIT (no training).
    if os.environ.get("HERMITE_CHECK", "") == "1":
        import sys as _sys
        n_ep = int(os.environ.get("HC_EPS", "6")); Ks = [2, 3, 4, 6]

        def _hermite_smooth(A, K):           # A (T,adim) -> (T,adim) from K cubic-Hermite control points
            T = len(A)
            if T <= K:
                return A.copy()
            knots = np.unique(np.linspace(0, T - 1, K).round().astype(int))
            out = np.zeros_like(A)
            kf = knots.astype(float)
            for d in range(A.shape[1]):
                v = A[knots, d]; m = np.gradient(v, kf)
                for s in range(len(knots) - 1):
                    i0, i1 = knots[s], knots[s + 1]
                    L = i1 - i0
                    tt = (np.arange(i0, i1 + 1) - i0) / L
                    h00 = 2 * tt**3 - 3 * tt**2 + 1; h10 = tt**3 - 2 * tt**2 + tt
                    h01 = -2 * tt**3 + 3 * tt**2; h11 = tt**3 - tt**2
                    out[i0:i1 + 1, d] = h00 * v[s] + h10 * L * m[s] + h01 * v[s + 1] + h11 * L * m[s + 1]
            return out

        Hwin = int(os.environ.get("HC_HWIN", "8"))   # spline-MPPI granularity = the planning horizon

        def _r2(A, As):
            return 1.0 - ((A - As) ** 2).sum() / (((A - A.mean(0)) ** 2).sum() + 1e-9)

        def _hwin_r2(A, K):                  # avg R^2 of fitting K control pts per non-overlapping H-window
            r2s = []
            for i in range(0, len(A) - 1, Hwin):
                W = A[i:i + Hwin]
                if len(W) >= 4:
                    r2s.append(_r2(W, _hermite_smooth(W, K)))
            return float(np.mean(r2s)) if r2s else float("nan")

        free_rets = []; ctrl_rets = []; res = {K: [] for K in Ks}
        for _ep in range(n_ep):
            key, rk = jax.random.split(key)
            state = single_env_reset(rk); obs = jnp.asarray(state.obs[0])
            acts = []; er = 0.0
            for _ in range(episode_length):
                a = pi_apply(params, enc_apply(params, obs))
                acts.append(np.asarray(a).reshape(-1))
                state = single_env_step(state, a); er += float(state.reward[0])
                if bool(state.done[0] > 0.5):
                    break
                obs = jnp.asarray(state.obs[0])
            A = np.stack(acts); free_rets.append(er)
            # CONTROL: replay the ORIGINAL (unsmoothed) actions open-loop -> isolates open-loop fragility
            stc = single_env_reset(rk); erc = 0.0
            for t in range(len(A)):
                stc = single_env_step(stc, jnp.asarray(A[t], jnp.float32)); erc += float(stc.reward[0])
                if bool(stc.done[0] > 0.5):
                    break
            ctrl_rets.append(erc)
            for K in Ks:
                As = _hermite_smooth(A, K)
                st2 = single_env_reset(rk); er2 = 0.0
                for t in range(len(As)):
                    st2 = single_env_step(st2, jnp.asarray(As[t], jnp.float32)); er2 += float(st2.reward[0])
                    if bool(st2.done[0] > 0.5):
                        break
                res[K].append((_r2(A, As), _hwin_r2(A, K), er2))
        fm = float(np.mean(free_rets)); cm = float(np.mean(ctrl_rets))
        print(f"  [HERMITE_CHECK] {env_id} free pi-return={fm:.1f} | open-loop CONTROL (orig actions)={cm:.1f} "
              f"({100*cm/(fm+1e-9):.0f}% — isolates open-loop fragility) | Hwin={Hwin} n={n_ep}", flush=True)
        for K in Ks:
            er2 = np.mean([x[2] for x in res[K]])
            print(f"    K={K}: full_R2={np.mean([x[0] for x in res[K]]):.3f}  Hwin_R2={np.nanmean([x[1] for x in res[K]]):.3f}"
                  f"  spline_replay={er2:.1f} ({100*er2/(cm+1e-9):.0f}% of CONTROL)", flush=True)
        print("    -> the lever-relevant number is Hwin_R2 (spline-MPPI plans over H-windows) AND "
              "spline_replay vs CONTROL (not vs free).", flush=True)
        _sys.exit(0)

    # Q-reset (REDQ-style): re-init online Q params + optimizer state when env_steps
    # crosses any threshold in q_reset_steps. Target Q (tp["q"]) is preserved so the
    # critic restarts from the EMA of past good critics rather than from scratch.
    q_reset_pending = sorted(int(s) for s in (q_reset_steps or []))
    if q_reset_pending:
        print(f"  Q-reset scheduled at env_steps: {q_reset_pending}", flush=True)

    with open_csv(csv_path, env_id, seed) as fh:
        while env_steps < total_steps:
            # Collect N_ENVS steps
            if EXPL_MIX_DECAY_STEPS > 0:
                rand_prob = max(0.0, 1.0 - env_steps / EXPL_MIX_DECAY_STEPS)
                rand_acts = rng_np.uniform(al, ah, (N_ENVS, act_dim)).astype(np.float32)
                acts_jax = act_fn_batch(params, jnp.asarray(obs_np))
                _sigma = _current_noise(env_steps)
                noise = rng_np.normal(0, _sigma, (N_ENVS, act_dim))
                policy_acts = np.clip(np.array(acts_jax) + noise, al, ah).astype(np.float32)
                rand_mask = rng_np.random((N_ENVS, 1)) < rand_prob
                acts_np = np.where(rand_mask, rand_acts, policy_acts).astype(np.float32)
            elif env_steps < EXPL_UNTIL:
                acts_np = rng_np.uniform(al, ah, (N_ENVS, act_dim)).astype(np.float32)
            else:
                acts_jax = act_fn_batch(params, jnp.asarray(obs_np))
                _sigma   = _current_noise(env_steps)
                noise    = rng_np.normal(0, _sigma, (N_ENVS, act_dim))
                acts_np  = np.clip(np.array(acts_jax) + noise, al, ah).astype(np.float32)

            env_state = batch_step(env_state, jnp.asarray(acts_np))
            new_obs  = np.array(env_state.obs)
            rews_np  = np.array(env_state.reward)
            done_np  = np.array(env_state.done > 0.5, np.float32)
            # Path 5 / Phase-t — knee penalty (training reward only). Eval
            # reward is unmodified so we measure against the original task.
            if _knee_pen_coef > 0:
                pen_np = np.array(knee_penalty_fn(env_state))
                rews_np = rews_np - _knee_pen_coef * pen_np
            # iter-6 §7.C — Phase-r2 gait penalty (training reward only)
            #     fall_penalty: -coef when height < gait_fall_height
            #     action_smooth: -coef * mean((a_t - a_{t-1})**2) per env
            # iter-6 §7.B — Phase-r1 soft-reward bundle (training reward only)
            #     stand_bonus: +coef * clip((h - floor)/(STAND_H - floor), 0, 1)
            #     weight linearly anneals 1.0 -> 0.0 over [0, soft_anneal_steps]
            _h_np_cache = None
            if _gait_fall_coef > 0:
                _h_np_cache = np.array(_height_per_env(env_state))
                rews_np = rews_np - _gait_fall_coef * (_h_np_cache < _gait_fall_h).astype(np.float32)
            if _gait_smooth_coef > 0:
                if _prev_acts is None:
                    _prev_acts = np.zeros_like(acts_np)
                da_sq = np.mean((acts_np - _prev_acts) ** 2, axis=-1)
                rews_np = rews_np - _gait_smooth_coef * da_sq
            if _soft_bonus > 0:
                _soft_weight = 1.0
                if _soft_anneal > 0:
                    _soft_weight = max(0.0, 1.0 - env_steps / _soft_anneal)
                if _soft_weight > 0:
                    if _h_np_cache is None:
                        _h_np_cache = np.array(_height_per_env(env_state))
                    _STAND_H = 0.6
                    bonus = np.clip((_h_np_cache - _soft_floor) / max(_STAND_H - _soft_floor, 1e-6), 0.0, 1.0)
                    rews_np = rews_np + _soft_bonus * _soft_weight * bonus
            if _gait_smooth_coef > 0:
                _prev_acts = acts_np.copy()
            # Path P / Phase-P — cluster-entropy intrinsic reward (training only).
            # Phase-Pa: linearly decay coef to 0 over [_cluster_decay_start, _cluster_decay_steps]
            # so intrinsic is an exploration curriculum, not a permanent reward distortion.
            if _cluster_active:
                if _cluster_decay_steps > 0:
                    frac = max(
                        0.0,
                        min(
                            1.0,
                            (env_steps - _cluster_decay_start)
                            / max(1, _cluster_decay_steps - _cluster_decay_start),
                        ),
                    )
                    _cluster_coef = _cluster_coef_init * (1.0 - frac)
                else:
                    _cluster_coef = _cluster_coef_init
                if _cluster_coef > 1e-6:
                    cluster_ids = np.array(cluster_id_batch(params, jnp.asarray(new_obs)))  # (N_ENVS,)
                    _cluster_history[:, _cluster_history_ptr] = cluster_ids
                    _cluster_history_ptr = (_cluster_history_ptr + 1) % _cluster_window
                    ent_np = cluster_entropy_per_env(_cluster_history)
                    rews_np = rews_np + _cluster_coef * ent_np
            # iter-17 — prototype-visit-count novelty bonus (training only).
            if _pnov_active:
                if _pnov_decay_steps > 0:
                    _pnov_coef = _pnov_coef_init * max(0.0, 1.0 - env_steps / _pnov_decay_steps)
                else:
                    _pnov_coef = _pnov_coef_init
                if _pnov_coef > 1e-6:
                    pids = np.array(proto_id_batch(params, jnp.asarray(new_obs)))
                    np.add.at(_pnov_counts, pids, 1.0)
                    rews_np = rews_np + _pnov_coef / np.sqrt(_pnov_counts[pids])
            # iter-21 — RND / Laplacian-eigenpurpose intrinsic exploration (training reward only).
            if _intr_state is not None:
                st = _intr_state
                if _intr in ("rnd", "laplacian"):
                    # raw-obs normalization (RND/Laplacian operate on normalized obs)
                    st["onorm"].update(np.asarray(obs_np)); st["onorm"].update(np.asarray(new_obs))
                    o_n = jnp.asarray(st["onorm"].norm(np.asarray(obs_np)), jnp.float32)
                    on_n = jnp.asarray(st["onorm"].norm(np.asarray(new_obs)), jnp.float32)
                if _intr == "rnd":
                    bonus = np.asarray(st["reward"](st["pp"], on_n))
                    st["pp"], st["opt"] = st["update"](st["pp"], st["opt"], on_n)
                elif _intr in ("vcse", "si2e", "wmsi2e"):
                    # feature phi(s'): WORLD-MODEL latent (wmsi2e, novel) or random encoder (vcse/si2e)
                    if _intr == "wmsi2e":
                        feat = np.asarray(lat_apply(params, jnp.asarray(new_obs)))   # (N, latent_dim)
                    else:
                        feat = st["rand_enc"](new_obs)                               # (N, 32)
                    val = np.asarray(val_apply(params, jnp.asarray(new_obs)))        # (N,) critic value
                    bonus = st["reward"](feat, val)              # VCSE r0 (vcse) or r0-r1 (si2e/wmsi2e)
                    st["push"](feat, val)
                    st["maybe_rebuild"]()
                else:  # laplacian
                    bonus = np.asarray(st["reward"](st["pp"], o_n, on_n))
                    st["pp"], st["opt"] = st["update"](st["pp"], st["opt"], o_n, on_n)
                st["rnorm"].update(bonus)
                rews_np = rews_np + _intr_coef * (bonus / (np.sqrt(st["rnorm"].var) + 1e-8))
            # Thread E / A3 — SE-community subgoal HL shaping (training reward only; eval
            # reward is untouched, so we measure against the true task).
            if _ss_state is not None:
                _z_ss = np.asarray(lat_apply(params, jnp.asarray(new_obs)))
                rews_np = rews_np + _ss_state.step(_z_ss, env_steps)
            buf.add_batch(obs_np, acts_np, rews_np, done_np)
            obs_np    = new_obs
            env_steps += N_ENVS

            # Curriculum smoothing: turn on smoothing at the warmup boundary.
            # Rebuilds multi_step with the new coef (one-time ~3 min JIT recompile).
            if _curriculum_active and env_steps >= _smooth_warmup and _smooth_curr != _smooth_target:
                print(
                    f"  [curriculum] env_steps={env_steps:,} crossed warmup={_smooth_warmup:,} — "
                    f"raising latent_action_smooth_coef {_smooth_curr} -> {_smooth_target} "
                    f"(JIT recompile cost ~3 min)", flush=True
                )
                _smooth_curr = _smooth_target
                multi_step = _build_multi_step(_smooth_curr)

            # Q-reset check (must happen before the gradient update so the freshly
            # initialised Q sees the next batch with a clean opt state).
            while q_reset_pending and env_steps >= q_reset_pending[0]:
                threshold = q_reset_pending.pop(0)
                key, qreset_k = jax.random.split(key)
                fresh_q = q_net.init(qreset_k, dummy_z, dummy_act)
                params = {**params, "q": fresh_q}
                opt = tx.init(params)  # opt state shape changes with q tree; safest to re-init
                print(
                    f"  [Q-reset] env_steps={env_steps:,} crossed threshold={threshold:,}"
                    f" — online Q + opt state re-initialised (target Q preserved)",
                    flush=True,
                )

            # Gradient updates (one vectorised sample + one H2D + lax.scan)
            # aux/loss_val may be read by the log line below before the first
            # update fires (resume with a fresh replay buffer) — safe defaults.
            try:
                aux
            except NameError:
                aux, loss_val = {}, 0.0
            samp_k = buf.sample_k(K_UPDATE, BS, rng_np)
            # DEMO-SEED mix: replace n_demo of the K blocks with demo blocks so each
            # gradient batch trains the model/value on successful pick trajectories.
            if samp_k is not None and demo_buf is not None and _demo_frac > 0.0:
                n_demo = int(round(_demo_frac * K_UPDATE))
                if n_demo > 0:
                    demo_k = demo_buf.sample_k(n_demo, BS, rng_np)
                    if demo_k is not None:
                        n_online = K_UPDATE - n_demo
                        ob_o, ab_o, rb_o, db_o = samp_k
                        ob_d, ab_d, rb_d, db_d = demo_k
                        samp_k = (
                            np.concatenate([ob_o[:n_online], ob_d], axis=0),
                            np.concatenate([ab_o[:n_online], ab_d], axis=0),
                            np.concatenate([rb_o[:n_online], rb_d], axis=0),
                            np.concatenate([db_o[:n_online], db_d], axis=0),
                        )
            if samp_k is not None:
                ob_k, ab_k, rb_k, db_k = [jnp.asarray(x) for x in samp_k]
                if use_glass:
                    _glass_warmup = glass_cfg.get("warmup_env_steps", 100_000)
                    _glass_decay = int(glass_decay_steps) if glass_decay_steps > 0 else None
                    # glass active in window [warmup, decay): turn ON after warmup, OFF after decay if set
                    glass_active = (env_steps >= _glass_warmup) and (_glass_decay is None or env_steps < _glass_decay)
                    params, tp, opt, key, scale, glass_step, loss_val, aux = multi_step(
                        params, tp, opt, ob_k, ab_k, rb_k, db_k, key, scale,
                        glass_step, glass_active,
                    )
                else:
                    mpc_obs_anchor = jnp.asarray(_dummy_mpc_obs)
                    mpc_action_target = jnp.asarray(_dummy_mpc_act)
                    mpc_coef_step = jnp.array(0.0, dtype=jnp.float32)
                    if _mpc_distill_enabled and env_steps >= EXPL_UNTIL and _mpc_gap_allows_distill:
                        anneal_frac = min(max((env_steps - EXPL_UNTIL) / _mpc_distill_anneal_steps, 0.0), 1.0)
                        curr_coef = _mpc_distill_target_coef * (1.0 - anneal_frac)
                        if curr_coef > 1e-6:
                            anchor = buf.sample(_mpc_distill_batch_size, rng_np)
                            if anchor is not None:
                                anchor_obs = np.asarray(anchor[0][:, 0, :], dtype=np.float32)
                                mpc_obs_anchor = jnp.asarray(anchor_obs)
                                key, mpc_k = jax.random.split(key)
                                mpc_action_target = batch_mppi_targets(params, mpc_obs_anchor, mpc_k)
                                mpc_coef_step = jnp.array(curr_coef, dtype=jnp.float32)
                    params, tp, opt, key, scale, loss_val, aux = multi_step(
                        params, tp, opt, ob_k, ab_k, rb_k, db_k, key, scale,
                        mpc_obs_anchor, mpc_action_target, mpc_coef_step,
                    )

            if env_steps % log_interval < N_ENVS:
                elapsed = time.time() - t0
                _mpc_log = "" if use_glass else f"  mpc={float(aux.get('mpc', 0.0)):.4f}"
                _jmp_log = ""
                if _jumpy_k > 0:
                    _je = float(aux.get('jumpy_err', 0.0)); _ie = float(aux.get('iter1_err', 0.0))
                    _ratio = _je / max(_ie, 1e-8)
                    _jmp_log = (f"  JUMPY k{_jumpy_k}: jumpy_err={_je:.3f} iter1_err={_ie:.3f} "
                                f"ratio={_ratio:.3f}{' <1=WIN' if _ratio<1 else ''}")
                    if float(calib_coef) > 0.0:
                        _jmp_log += f"  calib={float(aux.get('calib', 0.0)):.4f}"
                _abl_cmp = (f"  ABL={os.environ.get('ABLATE','none')}"
                            f"  comp[c={float(aux.get('c',0)):.3f} r={float(aux.get('r',0)):.3f} "
                            f"v={float(aux.get('v',0)):.3f} p={float(aux.get('p',0)):.3f}] "
                            f"mask[c={float(aux.get('abl_mc',1)):.0f} r={float(aux.get('abl_mr',1)):.0f} "
                            f"v={float(aux.get('abl_mv',1)):.0f} p={float(aux.get('abl_mp',1)):.0f}]")
                print(f"  es={env_steps:>9,}  sps={env_steps/max(elapsed,1):.0f}"
                      f"  loss={float(loss_val):.4f}  scale={float(scale):.2f}{_mpc_log}{_jmp_log}{_abl_cmp}", flush=True)

            if env_steps >= next_eval:
                _eval_neps = int(os.environ.get("EVAL_NEPS", "0"))  # 0 = defaults; raise to cut eval variance
                ret, pi_diag = eval_pi(n_eps=_eval_neps or 5)
                _t_mppi = time.time()
                mppi_ret, mppi_diag = eval_mppi(n_eps=_eval_neps or (8 if use_glass else 3))
                _t_mppi = time.time() - _t_mppi
                jumpy_ret = None
                jumpy_diag = {}
                if _jumpy_plan:
                    jumpy_ret, jumpy_diag = eval_jumpy(n_eps=3)
                    print(f"    JUMPY-MPPI={jumpy_ret:7.1f} (vs MPPI={mppi_ret:7.1f}, k={_jumpy_k} n_macro={_jumpy_n_macro} "
                          f"eff_H={_jumpy_k*_jumpy_n_macro})", flush=True)
                proto_ret = None
                if _proto_plan:
                    # iter-15 paired probe: same params, same step, proto-space planner.
                    _t_proto = time.time()
                    proto_ret, proto_diag = eval_protomppi(n_eps=8)
                    _t_proto = time.time() - _t_proto
                    _n_mppi_eps = 8 if use_glass else 3
                    print(
                        f"    protoMPPI={proto_ret:7.1f} (vs MPPI={mppi_ret:7.1f}, "
                        f"ratio={proto_ret / max(mppi_ret, 1e-6):.2f})  "
                        f"t/ep: proto={_t_proto / 8:.1f}s mppi={_t_mppi / _n_mppi_eps:.1f}s",
                        flush=True,
                    )
                arb_ret = None
                arb_selector = ""
                arb_gap = float(mppi_ret) - float(ret)
                if _controller_arbitration == "eval_only":
                    if mppi_ret > ret + _arbitration_margin:
                        arb_selector = "mppi"
                        arb_ret = float(mppi_ret)
                    else:
                        arb_selector = "pi"
                        arb_ret = float(ret)
                elapsed = time.time() - t0
                _pi_minus_mppi = float(ret) - float(mppi_ret)
                _gap_marker = "  pi>>MPPI" if _pi_minus_mppi >= 100 else ("  MPPI>>pi" if _pi_minus_mppi <= -100 else "")
                print(f"  step={env_steps:>9,}  pi_reward={ret:7.1f}"
                      f"  MPPI={mppi_ret:7.1f}"
                      f"  sps={env_steps/max(elapsed,1):.0f}{_gap_marker}", flush=True)
                if arb_ret is not None:
                    print(
                        f"    arb eval: selected={arb_selector} reward={arb_ret:.1f} "
                        f"mppi_minus_pi={arb_gap:.1f} margin={_arbitration_margin:.1f}",
                        flush=True,
                    )
                if _mpc_distill_enabled:
                    _prev_gate = _mpc_gap_allows_distill
                    _mpc_gap_allows_distill = (_pi_minus_mppi < _mpc_distill_disable_gap)
                    if _prev_gate != _mpc_gap_allows_distill:
                        state = "ENABLED" if _mpc_gap_allows_distill else "DISABLED"
                        print(
                            f"    [Phase-mpc-lite] planner distill {state}: "
                            f"pi-mppi gap={_pi_minus_mppi:.1f} vs disable_gap={_mpc_distill_disable_gap:.1f}",
                            flush=True,
                        )
                # §7.1 diagnostics — per-step reward signal proxies.
                # full=fraction with reward>0.5 (standing+fast); stand=fraction>0.01 (upright);
                # falls=transitions from stand→fallen; ttf=first step at full reward (or episode_length if never).
                print(f"    diag pi:   full={pi_diag['full']:.2f} stand={pi_diag['stand']:.2f}"
                      f"  falls={pi_diag['falls']}  ttf={pi_diag['ttf']}", flush=True)
                print(f"    diag mppi: full={mppi_diag['full']:.2f} stand={mppi_diag['stand']:.2f}"
                      f"  falls={mppi_diag['falls']}  ttf={mppi_diag['ttf']}", flush=True)
                if use_glass:
                    diag_sample = buf.sample(128, rng_np)
                    if diag_sample is not None:
                        ob_d, ab_d, _, _ = [jnp.asarray(x) for x in diag_sample]
                        gd = jax.device_get(glass_diag(params, ob_d, ab_d))
                        print(
                            "    glass"
                            f" se={float(gd['glass_se']):.4f}"
                            f" ent={float(gd['glass_entropy']):.3f}"
                            f" active={float(gd['glass_active_clusters']):.0f}"
                            f" max_mass={float(gd['glass_max_cluster_mass']):.3f}"
                            f" cut={float(gd['glass_transition_cut_mass']):.3f}",
                            flush=True,
                        )
                        if glass_cfg.get("diag_dump_matrices", True):
                            diag_dir.mkdir(parents=True, exist_ok=True)
                            np.savez_compressed(
                                diag_dir / f"step_{env_steps}.npz",
                                P=np.asarray(gd["P"]),
                                A=np.asarray(gd["A"]),
                                S=np.asarray(gd["S"]),
                            )
                write_csv(fh, env_id, seed, env_steps, ret)
                _a2j = os.environ.get("A2_JSONL", "").strip()
                if _a2j:
                    import json as _a2json
                    with open(_a2j, "a") as _a2f:
                        _a2f.write(_a2json.dumps({"step": int(env_steps), "pi_return": float(ret),
                                   "mppi_return": float(mppi_ret), "beta": _nov_beta,
                                   "novelty_type": (_nov_type if _novelty_active else "vanilla")}) + "\n")
                if _is_ogbench:
                    _pi_succ = float(pi_diag.get("success", float("nan")))
                    _mppi_succ = float(mppi_diag.get("success", float("nan")))
                    print(f"    [ogbench] success pi={_pi_succ:.3f} mppi={_mppi_succ:.3f}", flush=True)
                    _sc = csv_path.with_name(csv_path.name.replace(".csv", "_success.csv"))
                    if not _sc.exists():
                        with open(_sc, "w") as sf:
                            sf.write("step,seed,pi_return,mppi_return,pi_success,mppi_success\n")
                    with open(_sc, "a") as sf:
                        sf.write(f"{env_steps},{seed},{ret:.1f},{mppi_ret:.1f},{_pi_succ:.4f},{_mppi_succ:.4f}\n")
                if _is_pickcube:
                    # REAL TASK SUCCESS sidecar (box_target>=0.9). pi_diag/mppi_diag
                    # carry success (0/1 rate over eval eps), box_target_max, reached.
                    _pi_succ = float(pi_diag.get("success", float("nan")))
                    _mppi_succ = float(mppi_diag.get("success", float("nan")))
                    _pi_reach = float(pi_diag.get("reached", float("nan")))
                    _mppi_reach = float(mppi_diag.get("reached", float("nan")))
                    _pi_bt = float(pi_diag.get("box_target_max", float("nan")))
                    _mppi_bt = float(mppi_diag.get("box_target_max", float("nan")))
                    _ju_succ = float(jumpy_diag.get("success", float("nan")))
                    _ju_reach = float(jumpy_diag.get("reached", float("nan")))
                    _ju_bt = float(jumpy_diag.get("box_target_max", float("nan")))
                    print(f"    [REAL-SUCCESS PandaPickCube] pi: succ={_pi_succ:.3f} reached={_pi_reach:.3f} box_target_max={_pi_bt:.3f}"
                          f"  | mppi: succ={_mppi_succ:.3f} reached={_mppi_reach:.3f} box_target_max={_mppi_bt:.3f}"
                          + (f"  | jumpy: succ={_ju_succ:.3f} reached={_ju_reach:.3f} box_target_max={_ju_bt:.3f}" if jumpy_ret is not None else ""), flush=True)
                    _rsc = csv_path.with_name(csv_path.name.replace(".csv", "_realsuccess.csv"))
                    if not _rsc.exists():
                        with open(_rsc, "w") as rf:
                            rf.write("step,seed,pi_return,mppi_return,jumpy_return,"
                                     "pi_success,mppi_success,jumpy_success,"
                                     "pi_reached,mppi_reached,jumpy_reached,"
                                     "pi_box_target_max,mppi_box_target_max,jumpy_box_target_max\n")
                    _jr = jumpy_ret if jumpy_ret is not None else float("nan")
                    with open(_rsc, "a") as rf:
                        rf.write(f"{env_steps},{seed},{ret:.1f},{mppi_ret:.1f},{_jr:.1f},"
                                 f"{_pi_succ:.4f},{_mppi_succ:.4f},{_ju_succ:.4f},"
                                 f"{_pi_reach:.4f},{_mppi_reach:.4f},{_ju_reach:.4f},"
                                 f"{_pi_bt:.4f},{_mppi_bt:.4f},{_ju_bt:.4f}\n")
                if eval_type_csv is not None:
                    with open(eval_type_csv, "a") as cf:
                        cf.write(f"{env_steps},{ret:.1f},pi,{seed}\n")
                        cf.write(f"{env_steps},{mppi_ret:.1f},mppi,{seed}\n")
                        if jumpy_ret is not None:
                            cf.write(f"{env_steps},{jumpy_ret:.1f},jumpy,{seed}\n")
                        if proto_ret is not None:
                            cf.write(f"{env_steps},{proto_ret:.1f},protomppi,{seed}\n")
                        if arb_ret is not None:
                            cf.write(f"{env_steps},{arb_ret:.1f},arb,{seed}\n")
                    # PHASE-ENTROPY mechcheck: log visited-state phase-entropy vs return over training.
                    _phc = eval_type_csv.with_name(eval_type_csv.name.replace(".csv", "_phase.csv"))
                    if not _phc.exists():
                        with open(_phc, "w") as pf:
                            pf.write("step,seed,pi_return,mppi_return,phase_entropy,value_r2,eff_rank\n")
                    with open(_phc, "a") as pf:
                        pf.write(f"{env_steps},{seed},{ret:.1f},{mppi_ret:.1f},{pi_diag.get('phase_entropy', float('nan')):.4f},{pi_diag.get('value_r2', float('nan')):.4f},{pi_diag.get('eff_rank', float('nan')):.4f}\n")
                    # §7.1 diagnostics CSV — sibling file, doesn't affect main eval CSV.
                    _diag_csv = eval_type_csv.with_name(eval_type_csv.name.replace(".csv", "_diag.csv"))
                    if not _diag_csv.exists():
                        with open(_diag_csv, "w") as df:
                            df.write("step,eval_type,seed,full_reward_rate,standing_rate,fall_count,time_to_first_full\n")
                    with open(_diag_csv, "a") as df:
                        df.write(f"{env_steps},pi,{seed},{pi_diag['full']:.4f},{pi_diag['stand']:.4f},{pi_diag['falls']},{pi_diag['ttf']}\n")
                        df.write(f"{env_steps},mppi,{seed},{mppi_diag['full']:.4f},{mppi_diag['stand']:.4f},{mppi_diag['falls']},{mppi_diag['ttf']}\n")
                    if arb_ret is not None:
                        _arb_csv = eval_type_csv.with_name(eval_type_csv.name.replace(".csv", "_arbitration.csv"))
                        if not _arb_csv.exists():
                            with open(_arb_csv, "w") as af:
                                af.write("step,seed,pi_reward,mppi_reward,mppi_minus_pi,selected,reward,margin\n")
                        with open(_arb_csv, "a") as af:
                            af.write(
                                f"{env_steps},{seed},{ret:.1f},{mppi_ret:.1f},{arb_gap:.1f},"
                                f"{arb_selector},{arb_ret:.1f},{_arbitration_margin:.1f}\n"
                            )
                if ckpt_dir is not None:
                    ckpt_payload = {
                        "algo": "tdmpc-glass" if use_glass else "tdmpc2",
                        "env_id": env_id,
                        "seed": seed,
                        "env_steps": env_steps,
                        "pi_reward": ret,
                        "mppi_reward": mppi_ret,
                        "params": jax.device_get(params),
                        "target_params": jax.device_get(tp),
                        "opt_state": jax.device_get(opt),
                        "scale": jax.device_get(scale),
                        "glass_step": jax.device_get(glass_step),
                        "key": jax.device_get(key),
                        "glass_config": dict(glass_cfg) if use_glass else {},
                        "best_mppi": best_mppi,
                        "best_mppi_step": best_mppi_step,
                    }
                    if arb_ret is not None:
                        ckpt_payload.update(
                            {
                                "arbitration_reward": arb_ret,
                                "arbitration_selector": arb_selector,
                                "arbitration_margin": _arbitration_margin,
                            }
                        )
                    if mppi_ret > best_mppi:
                        best_mppi = mppi_ret
                        best_mppi_step = env_steps
                        ckpt_payload["best_mppi"] = best_mppi
                        ckpt_payload["best_mppi_step"] = best_mppi_step
                        save_pickle_atomic(ckpt_dir / "best_mppi.pkl", ckpt_payload)
                    # iter-8 §2.0 — Phase-eval: track best-pi and best-any.
                    # MPPI is empirically worse than pi in a large minority of
                    # runs; preserving best-pi avoids discarding good actors.
                    if ret > best_pi:
                        best_pi = ret
                        best_pi_step = env_steps
                        ckpt_payload["best_pi"] = best_pi
                        ckpt_payload["best_pi_step"] = best_pi_step
                        save_pickle_atomic(ckpt_dir / "best_pi.pkl", ckpt_payload)
                    _curr_best_pair = max(ret, mppi_ret)
                    _curr_selector = "pi" if ret >= mppi_ret else "mppi"
                    if _curr_best_pair > best_any:
                        best_any = _curr_best_pair
                        best_any_step = env_steps
                        best_any_selector = _curr_selector
                        ckpt_payload["best_any"] = best_any
                        ckpt_payload["best_any_step"] = best_any_step
                        ckpt_payload["best_any_selector"] = best_any_selector
                        save_pickle_atomic(ckpt_dir / "best_any.pkl", ckpt_payload)
                    save_pickle_atomic(ckpt_dir / "latest_eval.pkl", ckpt_payload)
                    if save_full_state:
                        full_payload = {
                            **ckpt_payload,
                            "replay_buffer": buffer_state(buf),
                            "env_state": jax.device_get(env_state),
                            "obs_np": obs_np,
                            "rng_np_state": rng_np.bit_generator.state,
                            "np_random_state": np.random.get_state(),
                        }
                        save_pickle_atomic(ckpt_dir / "latest_full.pkl", full_payload)
                next_eval += eval_interval

                # iter-7 §2.1 — Phase-ar auto-restart on plateau.
                # Check fires once env_steps crosses each restart_check_at boundary.
                # If best_mppi is still below threshold, the seed is basin-locked;
                # re-init pi+q (keep enc/dyn/rew/glass + replay buffer + env state).
                if (restart_on_plateau
                        and env_steps >= _restart_next_check
                        and _restart_count < restart_max_attempts):
                    if best_mppi < restart_threshold:
                        _restart_count += 1
                        pre_restart_best = best_mppi
                        key, pikey, qkey = jax.random.split(key, 3)
                        fresh_pi = pi_net.init(pikey, dummy_z_aug)
                        fresh_q = q_net.init(qkey, dummy_z_aug, dummy_act)
                        params = {**params, "pi": fresh_pi, "q": fresh_q}
                        tp = {**tp, "pi": fresh_pi, "q": fresh_q}  # target Q resync
                        opt = tx.init(params)
                        # Clear best tracking so early-stop patience resets and a future
                        # check fires only if the *next* restart_check_at window also
                        # plateaus.
                        best_mppi = -float("inf")
                        best_mppi_step = env_steps
                        _restart_next_check = env_steps + int(restart_check_at)
                        print(
                            f"  [Phase-ar restart {_restart_count}/{restart_max_attempts}] "
                            f"env_steps={env_steps:,}: pre-restart best MPPI={pre_restart_best:.1f} "
                            f"< threshold={restart_threshold:.1f}. "
                            f"Re-init pi+q+target_q+opt (keep enc/dyn/rew/glass/replay/env).",
                            flush=True,
                        )
                        # Log restart marker row to eval CSV so dashboard / analysis can
                        # see where attempts began.
                        if eval_type_csv is not None:
                            with open(eval_type_csv, "a") as cf:
                                cf.write(f"{env_steps},-1.0,restart_{_restart_count},{seed}\n")
                    else:
                        # Crossed the boundary but already above threshold — schedule
                        # next check without restarting.
                        _restart_next_check = env_steps + int(restart_check_at)
                        print(
                            f"  [Phase-ar] env_steps={env_steps:,} above threshold "
                            f"(best={best_mppi:.1f} >= {restart_threshold:.1f}); no restart.",
                            flush=True,
                        )

                # Early stop: halt if no new best MPPI in the last `_patience` env-steps.
                if _patience > 0 and best_mppi_step > 0 and (env_steps - best_mppi_step) >= _patience:
                    print(
                        f"  Early-stop fired at env_steps={env_steps:,}: "
                        f"no new best MPPI since step={best_mppi_step:,} "
                        f"(best={best_mppi:.1f}, patience={_patience:,} env-steps).",
                        flush=True,
                    )
                    early_stop_triggered = True
                    break

        # Outer while-loop also exits if early-stop fired during the eval block above.
        if early_stop_triggered:
            pass  # fall through to checkpoint code below

    if ckpt_dir is not None:
        final_payload = {
            "algo": "tdmpc-glass" if use_glass else "tdmpc2",
            "env_id": env_id,
            "seed": seed,
            "env_steps": env_steps,
            "params": jax.device_get(params),
            "target_params": jax.device_get(tp),
            "opt_state": jax.device_get(opt),
            "scale": jax.device_get(scale),
            "glass_step": jax.device_get(glass_step),
            "key": jax.device_get(key),
            "glass_config": dict(glass_cfg) if use_glass else {},
            "best_mppi": best_mppi,
            "best_mppi_step": best_mppi_step,
            # iter-8 §2.0 — Phase-eval: persist best-pi + best-any with final
            "best_pi": best_pi,
            "best_pi_step": best_pi_step,
            "best_any": best_any,
            "best_any_step": best_any_step,
            "best_any_selector": best_any_selector,
        }
        save_pickle_atomic(ckpt_dir / "final.pkl", final_payload)
        if save_full_state:
            save_pickle_atomic(
                ckpt_dir / "final_full.pkl",
                {
                    **final_payload,
                    "replay_buffer": buffer_state(buf),
                    "env_state": jax.device_get(env_state),
                    "obs_np": obs_np,
                    "rng_np_state": rng_np.bit_generator.state,
                    "np_random_state": np.random.get_state(),
                },
            )
    print(f"  {algo_name} {env_id} done in {time.time()-t0:.0f}s", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--total_steps", type=int, default=3_000_000)
    ap.add_argument("--seed",        type=int, default=1)
    ap.add_argument("--tasks",       nargs="+", default=TASKS,
                    help=f"Tasks to benchmark (default: {TASKS})")
    ap.add_argument("--algos",       nargs="+", default=["ppo", "sac", "tdmpc2"],
                    help="Algorithms to run (default: ppo sac tdmpc2; also supports tdmpc-glass)")
    ap.add_argument("--no_plot",     action="store_true",
                    help="Skip plotting after training")
    ap.add_argument("--resume_checkpoint", type=str, default=None,
                    help="Resume TD-MPC2/TD-MPC-Glass model/optimizer state from a pickle checkpoint")
    ap.add_argument("--save_full_state", action="store_true",
                    help="Save replay buffer, vectorized env state, and RNG state for exact TD-MPC2/TD-MPC-Glass resume")
    ap.add_argument("--glass_warmup_env_steps", type=int, default=None,
                    help="Override TD-MPC-Glass warmup_env_steps")
    ap.add_argument("--glass_every_k_updates", type=int, default=None,
                    help="Override TD-MPC-Glass every_k_updates")
    ap.add_argument("--glass_proto_temperature", type=float, default=None,
                    help="Override TD-MPC-Glass proto_temperature")
    ap.add_argument("--glass_assignment_temperature", type=float, default=None,
                    help="Override TD-MPC-Glass assignment_temperature")
    ap.add_argument("--glass_lambda_se", type=float, default=None,
                    help="Override TD-MPC-Glass lambda_se")
    ap.add_argument("--glass_lambda_balance", type=float, default=None,
                    help="Override TD-MPC-Glass lambda_balance")
    ap.add_argument("--glass_lambda_temporal", type=float, default=None,
                    help="Override TD-MPC-Glass lambda_temporal")
    ap.add_argument("--glass_lambda_temp_stability", type=float, default=None,
                    help="Phase-g2: weight on the per-pair cosine-similarity penalty between consecutive "
                         "soft-cluster distributions. Penalises cluster oscillation within a single gait "
                         "phase (per blog §3). Default 0 = off; try 0.05.")
    ap.add_argument("--glass_stopgrad_graph", choices=["true", "false"], default=None,
                    help="Override TD-MPC-Glass stopgrad_graph")
    ap.add_argument("--glass_num_prototypes", type=int, default=None,
                    help="Override TD-MPC-Glass num_prototypes")
    ap.add_argument("--glass_num_clusters", type=int, default=None,
                    help="Override TD-MPC-Glass num_clusters")
    ap.add_argument("--glass_assign_logits_init_scale", type=float, default=None,
                    help="Override TD-MPC-Glass assign_logits_init_scale")
    ap.add_argument("--act_noise_start", type=float, default=None,
                    help="Initial exploration-noise std (default: 0.3, the EXPL_NOISE constant)")
    ap.add_argument("--act_noise_end", type=float, default=None,
                    help="Final exploration-noise std after annealing (default: same as --act_noise_start, i.e. no anneal)")
    ap.add_argument("--act_noise_anneal_steps", type=int, default=1_000_000,
                    help="Env-steps over which to linearly anneal noise from start to end (default: 1M)")
    ap.add_argument("--mppi_n_samples", type=int, default=None,
                    help="Path 9 / Phase-x: override MPPI sample count NS. Default 512. Try 2048 to test "
                         "whether stuck seeds are search-failure (limited samples) vs learning-failure.")
    ap.add_argument("--mppi_horizon", type=int, default=None,
                    help="Override MPPI horizon H (and training seq_len=H+1). Default: DEFAULTS['H']=3")
    ap.add_argument("--k_update", type=int, default=None,
                    help="Override TD-MPC2 K_UPDATE, the number of gradient updates per env batch. "
                         "Default: DEFAULTS['K_UPDATE']=64. Iteration 7 fair sweep tests 128 and 256.")
    ap.add_argument("--q_reset_steps", type=str, default=None,
                    help="Comma-separated env-step thresholds at which to re-init online Q + optimizer (REDQ-style). "
                         "Target Q (tp['q']) and other params are preserved. Example: '1000000,2000000,3000000'.")
    ap.add_argument("--latent_action_smooth_coef", type=float, default=0.0,
                    help="Latent action smoothing weight (Phase-f). Penalises ||pi(z_t)-pi(z_{t-1})||^2 in the policy "
                         "loss, computed over the dynamics rollout. 0 = off (default). Try 1e-3 for HopperHop.")
    ap.add_argument("--consistency_coef", type=float, default=None,
                    help="Override TD-MPC consistency-loss weight (Phase-g). Default: 2.0 (v13 stable). Try 1.0 to "
                         "let the model focus on TD instead of dynamics regularisation.")
    ap.add_argument("--bisim_coef", type=float, default=0.0,
                    help="iter-14 BS-MPC-style pairwise bisimulation auxiliary on the encoder "
                         "(0=off=vanilla TD-MPC2; reference arm. Try 0.1-1.0). Non-glass path only.")
    ap.add_argument("--distractor_dims", type=int, default=0,
                    help="iter-14 Stage-2a: append N temporally-correlated OU nuisance dims to obs "
                         "(0=off). Tests distractor-robustness of the encoder. Try 64.")
    ap.add_argument("--early_stop_patience", type=int, default=0,
                    help="If > 0, halt training when no new best MPPI has been recorded in the last N env-steps. "
                         "Combine with a generous --total_steps cap (e.g. 10_000_000) to auto-stop on convergence.")
    ap.add_argument("--latent_smooth_warmup_env_steps", type=int, default=0,
                    help="Curriculum schedule for --latent_action_smooth_coef. While env_steps < N, smoothing "
                         "coef is forced to 0 (lets Glass basin lock undisturbed). At env_steps >= N, coef is "
                         "raised to --latent_action_smooth_coef and the JIT is rebuilt (~3 min compile cost, once).")
    ap.add_argument("--glass_decay_steps", type=int, default=0,
                    help="If > 0, turn Glass loss OFF after env_steps >= N (hybrid Phase-o). Glass active "
                         "during the basin-discovery + representation-learning window [warmup, N], then OFF "
                         "so encoder/dynamics can refine without the partition acting as inductive bias.")
    ap.add_argument("--expl_until", type=int, default=None,
                    help="Override the env_steps duration of initial random exploration (Phase-p, path 1). "
                         "Default: DEFAULTS['EXPL_UNTIL']=25000. Try 500000 to fill replay with diverse "
                         "random rollouts (foot-strike data) before policy takes over.")
    ap.add_argument("--expl_mix_decay_steps", type=int, default=0,
                    help="Benchmark-fair exploration schedule: use a per-env random-policy action mixture "
                         "whose random-action probability decays linearly from 1.0 to 0.0 over N env-steps. "
                         "When >0, this replaces the hard --expl_until random-action phase.")
    # Hierarchical Glass (iteration-4 §7.4 / Path 10).
    ap.add_argument("--glass_num_super_clusters", type=int, default=None,
                    help="If > 0, enable hierarchical Glass: a second-level partition over the K=8 clusters "
                         "into K_super super-clusters. 0 (default) = flat partition (current behaviour).")
    ap.add_argument("--glass_lambda_super_se", type=float, default=None,
                    help="Weight on the super-cluster 2D-SE loss. Try 5e-3 (same as λ_se) when hierarchical "
                         "is on. Has no effect if --glass_num_super_clusters is 0.")
    ap.add_argument("--glass_lambda_super_balance", type=float, default=None,
                    help="Weight on the super-cluster balance hinge loss. Try 1e-2 (same as λ_balance).")
    ap.add_argument("--glass_lambda_behav", type=float, default=None,
                    help="iter-14 behavior-aware Glass: weight on the per-prototype reward-prediction "
                         "loss (groups reward-equivalent states; 0/None=off=geometric Glass). Try 0.1-1.0.")
    ap.add_argument("--proto_plan", action="store_true",
                    help="iter-15: train distilled prototype-space planner heads (pdyn MLP + proto_value; "
                         "stop-grad inputs, representation untouched) and evaluate prototype-space MPPI "
                         "alongside latent MPPI each eval (CSV eval_type 'protomppi'). Paired planning-quality "
                         "probe. Requires --glass_lambda_behav > 0.")
    ap.add_argument("--latent_norm", choices=["simnorm", "fsq"], default="simnorm",
                    help="iter-16: latent bound for vanilla tdmpc2. 'fsq' replaces SimNorm with Finite "
                         "Scalar Quantization (5 levels/dim, straight-through; DC-MPC-style discrete codes). "
                         "Representation swap — single-variable vs vanilla. tdmpc2 path only.")
    ap.add_argument("--dyn_arch", choices=["mlp", "attn", "resmlp"], default="mlp",
                    help="iter-27: backbone for enc/dyn/jumpy pre-norm latent. 'attn' = group-wise "
                         "self-attention over SimNorm's V groups; 'resmlp' = deeper gated-residual MLP. "
                         "SimNorm geometry unchanged — single-variable arch swap vs 'mlp'. tdmpc2 path only.")
    ap.add_argument("--fsq_levels", type=int, default=5,
                    help="iter-16: quantization levels per dim for --latent_norm fsq (default 5; "
                         "retune band uses 8 = finer codes).")
    ap.add_argument("--rho", type=float, default=None,
                    help="iter-20: consistency-loss horizon-decay rho (default 0.5). Higher (0.75-0.9) "
                         "weights long-horizon prediction more -> dynamics accurate at depth -> stable "
                         "deep planning (the H9-without-collapse lever).")
    ap.add_argument("--intrinsic", choices=["none", "rnd", "laplacian", "vcse", "si2e", "wmsi2e", "se_subgoal"], default="none",
                    help="iter-21: abstraction-grounded exploration intrinsic reward (training only). "
                         "rnd=Random Network Distillation (baseline); laplacian=DCEO-style eigenpurpose "
                         "(||phi(s')-phi(s)||, graph-Laplacian rep — the abstraction bet). Sparse-task rescue.")
    ap.add_argument("--intrinsic_coef", type=float, default=0.0,
                    help="iter-21: weight on the (normalized) intrinsic exploration reward. Try 0.5-2.0.")
    ap.add_argument("--jumpy_k", type=int, default=0,
                    help="iter-22: k-step jumpy latent model (0=off). Trains JumpyDynamics + horizon-"
                         "consistency; logs mechanism check (jumpy_err vs iter1_err). Needs mppi_horizon>=2k. "
                         "vanilla tdmpc2 path only.")
    ap.add_argument("--jumpy_ve_coef", type=float, default=0.0,
                    help="iter-25 probe#2: value-equivalent macro head weight (0=off)")
    ap.add_argument("--jumpy_coef", type=float, default=1.0,
                    help="iter-22: weight on the jumpy consistency + horizon-consistency loss.")
    ap.add_argument("--jumpy_plan", action="store_true",
                    help="iter-22: eval with jumpy-MPPI (plan n_macro macro-steps over the k-step model; "
                         "writes 'jumpy' CSV rows). Requires --jumpy_k>0.")
    ap.add_argument("--jumpy_n_macro", type=int, default=3,
                    help="iter-22: number of macro-steps for jumpy-MPPI (effective horizon = k*n_macro).")
    ap.add_argument("--calib_coef", type=float, default=0.0,
                    help="iter-30: calibration-shaped jumpy disagreement weight (0=off). Pinball loss on "
                         "(e-d) where e=||jdyn-sg(enc target)||, d=||jdyn-sg(iterated 1-step)|| per sample, "
                         "so d learns to upper-bound e at quantile --calib_q (self-reported untrust). "
                         "Requires --jumpy_k>0; vanilla tdmpc2 path only.")
    ap.add_argument("--calib_q", type=float, default=0.9,
                    help="iter-30: pinball quantile for the calib loss (default 0.9 = disc sits at the "
                         "0.9-quantile of true k-step err).")
    ap.add_argument("--proto_novelty_coef", type=float, default=0.0,
                    help="iter-17: prototype-visit-count novelty bonus, training reward only: "
                         "coef * 1/sqrt(visits[argmax-prototype]). Exploration THROUGH the abstraction, "
                         "for exploration-bound sparse tasks. Glass arm only. 0 = off.")
    ap.add_argument("--proto_novelty_decay_steps", type=int, default=0,
                    help="iter-17: linearly decay --proto_novelty_coef to 0 by this env-step "
                         "(exploration curriculum, not permanent reward distortion). 0 = no decay.")
    # Path 5 / Phase-t — reward shaping: penalise knee/torso/thigh contact with floor.
    ap.add_argument("--knee_penalty_coef", type=float, default=0.0,
                    help="Per-step training-only reward penalty when non-foot geoms (torso, nose, pelvis, "
                         "thigh, calf) are within penalty_threshold of the floor. Forces foot-hop technique. "
                         "Eval reward is unmodified. Try 0.1 for HopperHop.")
    ap.add_argument("--knee_penalty_threshold", type=float, default=0.15,
                    help="Z-coordinate threshold (m) below which non-foot geoms incur penalty. Default 0.15.")
    # iter-6 §7.C — Phase-r2 gait penalty bundle
    ap.add_argument("--gait_fall_penalty", type=float, default=0.0,
                    help="Phase-r2: subtract this from training reward each step when torso-foot "
                         "height < --gait_fall_height. Try 0.1.")
    ap.add_argument("--gait_fall_height", type=float, default=0.45,
                    help="Phase-r2: height threshold (m) below which fall penalty fires. Default 0.45.")
    ap.add_argument("--gait_action_smooth", type=float, default=0.0,
                    help="Phase-r2: subtract coef * mean((a_t - a_{t-1})**2) per env from training reward. "
                         "Encourages smooth env-space actions. Try 0.005.")
    # iter-6 §7.B — Phase-r1 soft-reward bundle (v1 = stand_bonus + linear anneal only;
    # speed curriculum + early bonus deferred to v2)
    ap.add_argument("--soft_stand_bonus", type=float, default=0.0,
                    help="Phase-r1: add coef * clip((h - floor)/(0.6 - floor), 0, 1) to training reward. "
                         "Smooth standing bonus that ramps in below the binary 0.6 m cutoff. Try 0.1.")
    ap.add_argument("--soft_stand_floor", type=float, default=0.4,
                    help="Phase-r1: height (m) at which stand_bonus begins to ramp up. Default 0.4.")
    ap.add_argument("--soft_anneal_steps", type=int, default=0,
                    help="Phase-r1: linearly fade --soft_stand_bonus weight from 1.0 -> 0.0 over [0, N] "
                         "env steps so the shaping disappears mid-training. 0 = no fade (full bonus all run).")
    # iter-7 §2.1 — Phase-ar auto-restart on plateau (basin-lottery escape)
    ap.add_argument("--restart_on_plateau", action="store_true",
                    help="Phase-ar: enable plateau-triggered restart of pi+q. At each "
                         "--restart_check_at boundary, if best MPPI is still below "
                         "--restart_threshold, re-init pi+q+target_q+opt (encoder, "
                         "dynamics, reward, replay buffer, env state preserved). "
                         "Up to --restart_max_attempts attempts per seed. Benchmark-fair.")
    ap.add_argument("--restart_check_at", type=int, default=1_000_000,
                    help="Phase-ar: plateau check fires every N env steps (default 1M). "
                         "First check at env_steps>=N; subsequent checks every additional N.")
    ap.add_argument("--restart_threshold", type=float, default=100.0,
                    help="Phase-ar: best MPPI floor below which restart fires (default 100). "
                         "100 is a sensible HopperHop dividing line between 'climbing' and 'basin-locked'.")
    ap.add_argument("--restart_max_attempts", type=int, default=3,
                    help="Phase-ar: max restarts per seed (default 3). Each attempt is a fresh pi+q.")
    ap.add_argument("--mpc_distill_coef", type=float, default=0.0,
                    help="Phase-mpc-lite: coefficient for MPPI-gated actor distillation. "
                         "Uses a small replay anchor batch and planner targets from the current model. 0 = off.")
    ap.add_argument("--mpc_distill_anneal_steps", type=int, default=3_000_000,
                    help="Phase-mpc-lite: linearly anneal distillation coef from its initial value to 0 "
                         "over N env-steps after --expl_until. Default 3M.")
    ap.add_argument("--mpc_distill_disable_gap", type=float, default=100.0,
                    help="Phase-mpc-lite: disable distillation after an eval when pi - mppi >= gap. "
                         "Re-enable automatically on a later eval if the gap drops back below this threshold.")
    ap.add_argument("--mpc_distill_batch_size", type=int, default=16,
                    help="Phase-mpc-lite: replay anchor batch size for planner targets per update cycle. "
                         "Small on purpose to keep MPPI target generation bounded.")
    ap.add_argument("--controller_arbitration", choices=["none", "eval_only"], default="none",
                    help="Iteration 10 i10-a1: log an eval-only arb series that chooses between pi and MPPI "
                         "at each eval. This does not change data collection or replay. Default: none.")
    ap.add_argument("--arbitration_margin", type=float, default=0.0,
                    help="Iteration 10 i10-a1: with --controller_arbitration=eval_only, select MPPI only "
                         "when MPPI reward exceeds pi reward by this margin. Default 0.")
    # Path P / Phase-P — cluster-entropy intrinsic reward (benchmark-fair, no env modification).
    ap.add_argument("--cluster_intrinsic_coef", type=float, default=0.0,
                    help="Path P: add coef * entropy(last W cluster ids) to training reward. Encourages "
                         "policy toward gaits visiting multiple distinct Glass clusters (= proper hopping "
                         "with multiple phases). Pure self-supervised; uses existing Glass partition. "
                         "Try 0.05-0.2 for HopperHop. 0 = off (default).")
    ap.add_argument("--cluster_intrinsic_window", type=int, default=20,
                    help="Window size W for the cluster-entropy intrinsic reward (Path P). Default 20 frames "
                         "(~0.4s at 50Hz). Larger window = longer-horizon diversity prior.")
    ap.add_argument("--cluster_intrinsic_decay_steps", type=int, default=0,
                    help="Phase-Pa: linearly decay --cluster_intrinsic_coef to 0 between --expl_until and "
                         "this env-step. 0 disables decay (static intrinsic, Phase-P behaviour). Recommended "
                         "3,000,000 so by 3M the policy trains on pure extrinsic reward.")
    ap.add_argument("--use_cluster_obs", action="store_true",
                    help="Path 7 / Phase-v: concat the soft Glass cluster distribution S[n_star(z)] "
                         "(K-dim) to z before pi/q lookups. Architectural change, fully benchmark-fair "
                         "(no reward modification). Policy can condition on which gait phase it's in. "
                         "stop_gradient on the cluster computation so Glass keeps its own structural loss.")
    return ap.parse_args()


def main():
    args = parse_args()
    EXP_DIR.mkdir(parents=True, exist_ok=True)

    print(f"\nBenchmark: {args.algos} × {args.tasks}")
    print(f"Steps: {args.total_steps:,}  Seed: {args.seed}")
    print(f"Output: {EXP_DIR}\n")

    t_total = time.time()
    glass_overrides = {
        "warmup_env_steps": args.glass_warmup_env_steps,
        "every_k_updates": args.glass_every_k_updates,
        "proto_temperature": args.glass_proto_temperature,
        "assignment_temperature": args.glass_assignment_temperature,
        "lambda_se": args.glass_lambda_se,
        "lambda_balance": args.glass_lambda_balance,
        "lambda_temporal": args.glass_lambda_temporal,
        "lambda_temp_stability": args.glass_lambda_temp_stability,
        "num_prototypes": args.glass_num_prototypes,
        "num_clusters": args.glass_num_clusters,
        "num_super_clusters": args.glass_num_super_clusters,
        "lambda_super_se": args.glass_lambda_super_se,
        "lambda_super_balance": args.glass_lambda_super_balance,
        "lambda_behav": args.glass_lambda_behav,
        "assign_logits_init_scale": args.glass_assign_logits_init_scale,
        "use_cluster_obs": args.use_cluster_obs,
        # iter-15: store_true flag — None when off so glass_cfg.update() skips it.
        "proto_plan": True if args.proto_plan else None,
    }
    if args.glass_stopgrad_graph is not None:
        glass_overrides["stopgrad_graph"] = args.glass_stopgrad_graph == "true"

    # Per-phase benchmark CSV: include TDMPC_GLASS_OUTPUT_TAG in the filename so
    # rows from different phases (phase-f, phase-j, etc.) end up in separate
    # files instead of all interleaving into one rollup.
    _tag = os.environ.get("TDMPC_GLASS_OUTPUT_TAG", "").strip()
    _suffix = f"_{_tag}" if _tag else ""
    failed = False
    for algo in args.algos:
        for task in args.tasks:
            csv_path = EXP_DIR / f"{algo}_{task}{_suffix}.csv"
            try:
                if algo == "ppo":
                    train_ppo(task, args.total_steps, args.seed, csv_path)
                elif algo == "sac":
                    train_sac(task, args.total_steps, args.seed, csv_path)
                elif algo == "tdmpc2":
                    # tdmpc2 path (no Glass). Iter 6 expanded to support the same
                    # config space as tdmpc-glass for direct ablation: NS, knee penalty,
                    # expl_until, latent smoothing, curriculum warmup.
                    train_tdmpc2(
                        task,
                        args.total_steps,
                        args.seed,
                        csv_path,
                        use_glass=False,
                        resume_checkpoint=args.resume_checkpoint,
                        save_full_state=args.save_full_state,
                        mppi_n_samples=args.mppi_n_samples,
                        mppi_horizon=args.mppi_horizon,
                        k_update=args.k_update,
                        latent_action_smooth_coef=args.latent_action_smooth_coef,
                        consistency_coef=args.consistency_coef,
                        bisim_coef=args.bisim_coef,
                        distractor_dims=args.distractor_dims,
                        early_stop_patience=args.early_stop_patience,
                        latent_smooth_warmup_env_steps=args.latent_smooth_warmup_env_steps,
                        expl_until=args.expl_until,
                        expl_mix_decay_steps=args.expl_mix_decay_steps,
                        knee_penalty_coef=args.knee_penalty_coef,
                        knee_penalty_threshold=args.knee_penalty_threshold,
                        gait_fall_penalty=args.gait_fall_penalty,
                        gait_fall_height=args.gait_fall_height,
                        gait_action_smooth=args.gait_action_smooth,
                        soft_stand_bonus=args.soft_stand_bonus,
                        soft_stand_floor=args.soft_stand_floor,
                        soft_anneal_steps=args.soft_anneal_steps,
                        restart_on_plateau=args.restart_on_plateau,
                        restart_check_at=args.restart_check_at,
                        restart_threshold=args.restart_threshold,
                        restart_max_attempts=args.restart_max_attempts,
                        mpc_distill_coef=args.mpc_distill_coef,
                        mpc_distill_anneal_steps=args.mpc_distill_anneal_steps,
                        mpc_distill_disable_gap=args.mpc_distill_disable_gap,
                        mpc_distill_batch_size=args.mpc_distill_batch_size,
                        controller_arbitration=args.controller_arbitration,
                        arbitration_margin=args.arbitration_margin,
                        latent_norm=args.latent_norm,
                        fsq_levels=args.fsq_levels,
                        dyn_arch=args.dyn_arch,
                        rho_override=args.rho,
                        intrinsic=args.intrinsic,
                        intrinsic_coef=args.intrinsic_coef,
                        jumpy_k=args.jumpy_k,
                        jumpy_coef=args.jumpy_coef,
                        jumpy_ve_coef=args.jumpy_ve_coef,
                        jumpy_plan=args.jumpy_plan,
                        jumpy_n_macro=args.jumpy_n_macro,
                        calib_coef=args.calib_coef,
                        calib_q=args.calib_q,
                    )
                elif algo in ("tdmpc-glass", "tdmpc_glass"):
                    q_reset = None
                    if args.q_reset_steps:
                        q_reset = sorted({int(s.strip()) for s in args.q_reset_steps.split(",") if s.strip()})
                    train_tdmpc2(
                        task,
                        args.total_steps,
                        args.seed,
                        csv_path,
                        use_glass=True,
                        resume_checkpoint=args.resume_checkpoint,
                        save_full_state=args.save_full_state,
                        glass_overrides=glass_overrides,
                        act_noise_start=args.act_noise_start,
                        act_noise_end=args.act_noise_end,
                        act_noise_anneal_steps=args.act_noise_anneal_steps,
                        mppi_horizon=args.mppi_horizon,
                        mppi_n_samples=args.mppi_n_samples,
                        k_update=args.k_update,
                        q_reset_steps=q_reset,
                        latent_action_smooth_coef=args.latent_action_smooth_coef,
                        consistency_coef=args.consistency_coef,
                        bisim_coef=args.bisim_coef,
                        distractor_dims=args.distractor_dims,
                        early_stop_patience=args.early_stop_patience,
                        latent_smooth_warmup_env_steps=args.latent_smooth_warmup_env_steps,
                        glass_decay_steps=args.glass_decay_steps,
                        expl_until=args.expl_until,
                        expl_mix_decay_steps=args.expl_mix_decay_steps,
                        knee_penalty_coef=args.knee_penalty_coef,
                        knee_penalty_threshold=args.knee_penalty_threshold,
                        cluster_intrinsic_coef=args.cluster_intrinsic_coef,
                        cluster_intrinsic_window=args.cluster_intrinsic_window,
                        cluster_intrinsic_decay_steps=args.cluster_intrinsic_decay_steps,
                        proto_novelty_coef=args.proto_novelty_coef,
                        proto_novelty_decay_steps=args.proto_novelty_decay_steps,
                        gait_fall_penalty=args.gait_fall_penalty,
                        gait_fall_height=args.gait_fall_height,
                        gait_action_smooth=args.gait_action_smooth,
                        soft_stand_bonus=args.soft_stand_bonus,
                        soft_stand_floor=args.soft_stand_floor,
                        soft_anneal_steps=args.soft_anneal_steps,
                        restart_on_plateau=args.restart_on_plateau,
                        restart_check_at=args.restart_check_at,
                        restart_threshold=args.restart_threshold,
                        restart_max_attempts=args.restart_max_attempts,
                        mpc_distill_coef=args.mpc_distill_coef,
                        mpc_distill_anneal_steps=args.mpc_distill_anneal_steps,
                        mpc_distill_disable_gap=args.mpc_distill_disable_gap,
                        mpc_distill_batch_size=args.mpc_distill_batch_size,
                        controller_arbitration=args.controller_arbitration,
                        arbitration_margin=args.arbitration_margin,
                    )
                else:
                    print(f"Unknown algo: {algo}", flush=True)
            except Exception as e:
                failed = True
                print(f"\nERROR in {algo}/{task}: {e}", flush=True)
                import traceback; traceback.print_exc()
            # Encourage GC between runs
            import gc; gc.collect()

    elapsed = time.time() - t_total
    print(f"\n{'='*60}")
    print(f"All runs completed in {elapsed/60:.1f} min")
    print(f"CSVs saved to: {EXP_DIR}")

    if not args.no_plot:
        plot_script = Path(__file__).parent / "plot_comparison.py"
        if plot_script.exists():
            import subprocess
            out_dir = EXP_DIR / "plots"
            cmd = [sys.executable, str(plot_script),
                   "--exp_dir", str(EXP_DIR),
                   "--out_dir", str(out_dir)]
            print(f"\nGenerating comparison plot → {out_dir}")
            subprocess.run(cmd, check=True)
        else:
            print(f"\nNo plot script found at {plot_script}. Run manually.")

    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
