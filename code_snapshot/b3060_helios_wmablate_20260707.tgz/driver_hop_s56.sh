#!/usr/bin/env bash
# HopperHop headline-arm ablation seeds 5/6 (none + value only): firms the wall-reproduction
# cell from n=4 to n=6 on the two arms that carry the Part-9 claim. GPU2=seed5, GPU3=seed6.
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/wm_head_ablation_hop
mkdir -p "$OUT/logs" "$OUT/jsonl"
DLOG=$OUT/driver_s56.log
echo "[driver_hop_s56] START $(date -u +%FT%TZ)" | tee -a "$DLOG"
run_chain() {
  local gpu=$1 seed=$2
  for a in none value; do
    echo "[driver_hop_s56] gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=1000000 bash $REPO/run_arm_hop.sh
    echo "[driver_hop_s56] gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
}
run_chain 2 5 &
run_chain 3 6 &
wait
touch "$OUT/WM_ABLATION_HOP_S56_DONE"
echo "[driver_hop_s56] DONE $(date -u +%FT%TZ)" | tee -a "$DLOG"
