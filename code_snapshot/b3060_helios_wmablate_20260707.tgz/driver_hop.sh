#!/usr/bin/env bash
# WM-head ablation on HOPPERHOP (the flagship task) — mechanism evidence for the
# exploration-wall paper. seed1->GPU0, seed2->GPU1, 5 arms each sequential.
# Arm order: none first (baseline), then expected-impactful, so partial harvest informs.
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/wm_head_ablation_hop
STEPS=${STEPS:-1000000}
ARMS="none value consistency reward policy"
mkdir -p "$OUT"
DLOG=$OUT/driver.log
echo "[driver_hop] START $(date -u +%FT%TZ) steps=$STEPS task=HopperHop arms=[$ARMS]" | tee -a "$DLOG"

run_seed_on_gpu() {
  local gpu=$1 seed=$2
  for a in $ARMS; do
    echo "[driver_hop] gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=$STEPS bash $REPO/run_arm_hop.sh
    echo "[driver_hop] gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
  touch "$OUT/gpu${gpu}_seed${seed}.done"
}

run_seed_on_gpu 0 1 &
P0=$!
run_seed_on_gpu 1 2 &
P1=$!
wait $P0 $P1
echo "[driver_hop] all arms done $(date -u +%FT%TZ)" | tee -a "$DLOG"
touch "$OUT/WM_ABLATION_HOP_DONE"
echo "[driver_hop] DONE marker written $(date -u +%FT%TZ)" | tee -a "$DLOG"
