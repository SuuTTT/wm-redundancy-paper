#!/usr/bin/env bash
# WM-head ablation ONE-SHOT driver. seed1->GPU2, seed2->GPU3, 5 arms each sequential.
# Order: full first, then expected-impactful, so partial harvest is still informative.
set -u
REPO=/root/helios_wmablate
OUT=$REPO/exp/wm_head_ablation
STEPS=${STEPS:-1000000}
TASK=${TASK:-CheetahRun}
ARMS="none consistency value reward policy"
mkdir -p "$OUT"
DLOG=$OUT/driver.log
echo "[driver] START $(date -u +%FT%TZ) steps=$STEPS task=$TASK arms=[$ARMS]" | tee -a "$DLOG"

run_seed_on_gpu() {
  local gpu=$1 seed=$2
  for a in $ARMS; do
    echo "[driver] gpu$gpu seed$seed arm=$a start $(date -u +%FT%TZ)" >> "$DLOG"
    GPU=$gpu ABLATE=$a SEED=$seed TOTAL_STEPS=$STEPS TASK=$TASK bash $REPO/run_arm.sh
    echo "[driver] gpu$gpu seed$seed arm=$a done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
  done
  touch "$OUT/gpu${gpu}_seed${seed}.done"
}

run_seed_on_gpu 2 1 &
P2=$!
run_seed_on_gpu 3 2 &
P3=$!
wait $P2 $P3
echo "[driver] all arms done $(date -u +%FT%TZ), running analysis" | tee -a "$DLOG"
/root/helios-rl/.venv/bin/python $REPO/analyze.py >> "$DLOG" 2>&1
echo "[driver] ANALYSIS done rc=$? $(date -u +%FT%TZ)" | tee -a "$DLOG"
touch "$OUT/WM_ABLATION_DONE"
echo "[driver] DONE marker written $(date -u +%FT%TZ)" | tee -a "$DLOG"
