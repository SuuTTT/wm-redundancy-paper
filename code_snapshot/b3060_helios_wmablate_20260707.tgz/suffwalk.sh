#!/usr/bin/env bash
set -u
cd /root/helios_wmablate || exit 1
for i in 0 1 2 3; do
  s=$((25+i))
  GPU=$i ABLATE=consistency TASK=WalkerRun SEED=$s TOTAL_STEPS=5000000 bash run_arm.sh &
done
wait
echo DONE > /root/helios_wmablate/exp/SUFFWALK_DONE
