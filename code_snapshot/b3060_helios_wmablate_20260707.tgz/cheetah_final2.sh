#!/usr/bin/env bash
# Final table completion: CheetahRun reward + consistency arms seeds 3/4 (the last n=2 cells).
# One arm per GPU: GPU0 reward s3, GPU1 reward s4, GPU2 consistency s3, GPU3 consistency s4.
set -u
REPO=/root/helios_wmablate
DLOG=$REPO/exp/cheetah_final2_driver.log
echo "[cf2] START $(date -u +%FT%TZ)" | tee -a "$DLOG"
run_one() {
  local gpu=$1 arm=$2 seed=$3
  echo "[cf2] gpu$gpu arm=$arm seed=$seed start $(date -u +%FT%TZ)" >> "$DLOG"
  GPU=$gpu ABLATE=$arm SEED=$seed TOTAL_STEPS=1000000 bash $REPO/run_arm.sh
  echo "[cf2] gpu$gpu arm=$arm seed=$seed done rc=$? $(date -u +%FT%TZ)" >> "$DLOG"
}
run_one 0 reward 3 &
run_one 1 reward 4 &
run_one 2 consistency 3 &
run_one 3 consistency 4 &
wait
touch "$REPO/exp/CHEETAH_FINAL2_DONE"
echo "[cf2] DONE $(date -u +%FT%TZ)" | tee -a "$DLOG"
